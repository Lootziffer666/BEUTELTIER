package com.example

import com.example.math.RegistrationMath
import com.example.model.AnchorPointPair
import com.example.model.Lod2FeatureClass
import com.example.parser.CityGmlParser
import com.example.repository.MesseRepository
import com.example.sample.SampleDzNrwData
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun testCityGmlParser_preservesFeaturesWithoutGroundSurface() {
        val parser = CityGmlParser()
        val xml = SampleDzNrwData.getKoelnmesseCityGml()
        val (summary, features) = parser.parseCityGml(xml, "Koelnmesse")

        assertTrue("Feature list should not be empty", features.isNotEmpty())
        assertTrue("Total feature count should be >= 4", summary.totalFeatures >= 4)
        
        // Verify overhead canopy and skywalk bridge exist and were NOT discarded due to missing GroundSurface
        val bridge = features.find { it.featureClass == Lod2FeatureClass.ELEVATED_BRIDGE }
        assertNotNull("Skywalk bridge feature should exist", bridge)
        assertTrue("Bridge should be marked elevated", bridge!!.isElevated)
    }

    @Test
    fun testRegistrationMath_leastSquaresFitting() {
        val anchors = listOf(
            AnchorPointPair("A1", "P1", 0.0, 0.0, 100.0, 200.0),
            AnchorPointPair("A2", "P2", 10.0, 0.0, 110.0, 200.0),
            AnchorPointPair("A3", "P3", 0.0, 10.0, 100.0, 210.0)
        )

        val result = RegistrationMath.computeRegistrationMatrix("HALL_TEST", anchors)

        assertTrue("Result should be valid", result.isValid)
        assertTrue("Result should use Least Squares", result.isLeastSquaresFit)
        assertEquals(100.0, result.tx, 0.01)
        assertEquals(200.0, result.ty, 0.01)
        assertEquals(0.0, result.meanResidualError, 0.001)
    }

    @Test
    fun testSemanticRoutingEngine() {
        val repo = MesseRepository()
        val route = repo.calculateSemanticRoute("A010", "B005")

        assertNotNull(route)
        assertTrue("Route should have path nodes", route.pathNodes.size >= 3)
        assertTrue("Total distance should be positive", route.totalDistanceMeters > 0)
    }
}
