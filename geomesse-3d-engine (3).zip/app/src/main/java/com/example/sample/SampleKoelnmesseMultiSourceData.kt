package com.example.sample

import com.example.model.AlkisParcel
import com.example.model.IndoorElevator
import com.example.model.IndoorEscalator
import com.example.model.IndoorLevelPlan
import com.example.model.LayerVisibilityState
import com.example.model.Lod2Point3D
import com.example.model.Mesh3dTilesetConfig
import com.example.model.MesseEntranceGate
import com.example.model.OrthofotoWmsLayer
import com.example.model.OsmTransitStation
import com.example.model.OsmTransportLine
import com.example.model.TransportType

object SampleKoelnmesseMultiSourceData {

    fun getAlkisParcels(): List<AlkisParcel> {
        val baseOriginX = 357400.0
        val baseOriginY = 5645000.0

        return listOf(
            AlkisParcel(
                id = "05315000_12_408_12",
                flur = 12,
                flurstueckNummer = "408/12",
                flaecheQm = 145200.0,
                polygonRing = listOf(
                    Lod2Point3D(baseOriginX - 100, baseOriginY - 100, 0.0),
                    Lod2Point3D(baseOriginX + 600, baseOriginY - 100, 0.0),
                    Lod2Point3D(baseOriginX + 600, baseOriginY + 400, 0.0),
                    Lod2Point3D(baseOriginX - 100, baseOriginY + 400, 0.0),
                    Lod2Point3D(baseOriginX - 100, baseOriginY - 100, 0.0)
                )
            ),
            AlkisParcel(
                id = "05315000_12_409_1",
                flur = 12,
                flurstueckNummer = "409/1",
                flaecheQm = 98400.0,
                polygonRing = listOf(
                    Lod2Point3D(baseOriginX + 600, baseOriginY - 100, 0.0),
                    Lod2Point3D(baseOriginX + 1100, baseOriginY - 100, 0.0),
                    Lod2Point3D(baseOriginX + 1100, baseOriginY + 400, 0.0),
                    Lod2Point3D(baseOriginX + 600, baseOriginY + 400, 0.0),
                    Lod2Point3D(baseOriginX + 600, baseOriginY - 100, 0.0)
                )
            ),
            AlkisParcel(
                id = "05315000_13_112_4",
                flur = 13,
                flurstueckNummer = "112/4",
                eigentuemer = "Stadt Köln (Öffentlicher Straßenraum)",
                nutzungsart = "Straßen- und Gleisverkehr",
                flaecheQm = 36200.0,
                polygonRing = listOf(
                    Lod2Point3D(baseOriginX - 250, baseOriginY - 200, 0.0),
                    Lod2Point3D(baseOriginX - 100, baseOriginY - 200, 0.0),
                    Lod2Point3D(baseOriginX - 100, baseOriginY + 600, 0.0),
                    Lod2Point3D(baseOriginX - 250, baseOriginY + 600, 0.0),
                    Lod2Point3D(baseOriginX - 250, baseOriginY - 200, 0.0)
                )
            )
        )
    }

    fun getOrthofotoWmsConfig() = OrthofotoWmsLayer()

    fun getMesh3dConfig() = Mesh3dTilesetConfig()

    fun getIndoorLevelPlans(): List<IndoorLevelPlan> {
        return listOf(
            IndoorLevelPlan("EBENE_0", "Ebene 0 (Erdgeschoss)", "Halle 1 - 11", "Koelnmesse_Hallenplan_Ebene_0.pdf", 300, 24, true),
            IndoorLevelPlan("EBENE_1", "Ebene 1 (Obergeschoss)", "Halle 2, 4, 10, 11", "Koelnmesse_Hallenplan_Ebene_1.pdf", 300, 18, false),
            IndoorLevelPlan("EBENE_2", "Ebene 2 (Confex / VIP Lounge)", "Confex Center & Messeturm", "Koelnmesse_Confex_Ebene_2.pdf", 300, 8, false)
        )
    }

    fun getIndoorElevators(): List<IndoorElevator> {
        return listOf(
            IndoorElevator("ELEV_H1", "Aufzug Halle 1 West", "Halle 1", listOf("EBENE_0", "EBENE_1"), 357380.0, 5645420.0, 3000),
            IndoorElevator("ELEV_H3", "Lastenaufzug Halle 3 Nord", "Halle 3", listOf("EBENE_0", "EBENE_1", "EBENE_2"), 357520.0, 5645580.0, 5000),
            IndoorElevator("ELEV_CONFEX", "Panorama-Aufzug Confex", "Confex Center", listOf("EBENE_0", "EBENE_1", "EBENE_2"), 357800.0, 5645350.0, 2000)
        )
    }

    fun getIndoorEscalators(): List<IndoorEscalator> {
        return listOf(
            IndoorEscalator("ESCAL_BOULEVARD_1", "Fahrtreppe Boulevard Süd", "Boulevard", "EBENE_0", "EBENE_1", 357450.0, 5645450.0),
            IndoorEscalator("ESCAL_H4", "Fahrtreppe Halle 4 Passage", "Halle 4", "EBENE_0", "EBENE_1", 357600.0, 5645500.0),
            IndoorEscalator("ESCAL_NORTH", "Express-Fahrtreppe Eingang Nord", "Eingang Nord", "EBENE_0", "EBENE_2", 357900.0, 5645600.0)
        )
    }

    fun getOsmTransportLines(): List<OsmTransportLine> {
        val baseOriginX = 357400.0
        val baseOriginY = 5645000.0

        return listOf(
            OsmTransportLine(
                id = "WAY_DEUTZ_MUELHEIMER_STR",
                name = "Deutz-Mülheimer Straße (B55)",
                type = TransportType.ROAD,
                coordinates = listOf(
                    Lod2Point3D(baseOriginX - 200, baseOriginY - 200, 0.0),
                    Lod2Point3D(baseOriginX - 200, baseOriginY + 700, 0.0)
                )
            ),
            OsmTransportLine(
                id = "WAY_MESSEPLATZ",
                name = "Messeplatz Boulevard",
                type = TransportType.PEDESTRIAN_BOULEVARD,
                coordinates = listOf(
                    Lod2Point3D(baseOriginX - 100, baseOriginY + 200, 0.0),
                    Lod2Point3D(baseOriginX + 1000, baseOriginY + 200, 0.0)
                )
            ),
            OsmTransportLine(
                id = "WAY_ICE_RAIL",
                name = "DB Fernverkehr ICE-Trasse Köln Messe/Deutz",
                type = TransportType.RAIL_ICE,
                coordinates = listOf(
                    Lod2Point3D(baseOriginX - 350, baseOriginY - 150, 4.0),
                    Lod2Point3D(baseOriginX + 1100, baseOriginY - 150, 4.0)
                )
            ),
            OsmTransportLine(
                id = "WAY_TRAM_1_9",
                name = "KVB Stadtbahn Linie 1 & 9",
                type = TransportType.TRAM_SUBWAY,
                coordinates = listOf(
                    Lod2Point3D(baseOriginX - 220, baseOriginY - 250, 0.0),
                    Lod2Point3D(baseOriginX + 500, baseOriginY - 250, 0.0)
                )
            )
        )
    }

    fun getOsmTransitStations(): List<OsmTransitStation> {
        return listOf(
            OsmTransitStation(
                id = "STATION_DEUTZ_MAIN",
                name = "Bahnhof Köln Messe/Deutz (Fern- & S-Bahn)",
                lines = listOf("ICE 10", "ICE 41", "ICE 78", "RE 1", "S6", "S11", "S19"),
                position = Lod2Point3D(357150.0, 5644880.0, 4.0),
                distanceToMesseMeters = 180
            ),
            OsmTransitStation(
                id = "STATION_MESSE_DEUTZ_TRAM",
                name = "Haltestelle Koelnmesse (KVB Tram 1 & 9)",
                lines = listOf("Tram 1", "Tram 9"),
                position = Lod2Point3D(357280.0, 5644780.0, 0.0),
                distanceToMesseMeters = 80
            ),
            OsmTransitStation(
                id = "STATION_MESSE_SUBWAY_3_4",
                name = "U-Bahnhof Stegerwaldsiedlung (KVB U3 & U4)",
                lines = listOf("U-Bahn 3", "U-Bahn 4"),
                position = Lod2Point3D(358300.0, 5645800.0, -8.0),
                distanceToMesseMeters = 320
            )
        )
    }

    fun getMesseEntranceGates(): List<MesseEntranceGate> {
        return listOf(
            MesseEntranceGate(
                gateId = "GATE_SOUTH",
                gateName = "Eingang Süd (Hauptbahnhof Deutz / Confex)",
                associatedHall = "Confex Center & Halle 1 / 2",
                position = Lod2Point3D(357350.0, 5645050.0, 0.0),
                isMainEntrance = true,
                securityCheckpoints = 24
            ),
            MesseEntranceGate(
                gateId = "GATE_NORTH",
                gateName = "Eingang Nord (Halle 6, 7, 8 & Congress-Centrum)",
                associatedHall = "Halle 6, 7, 8, 9",
                position = Lod2Point3D(357850.0, 5645650.0, 0.0),
                isMainEntrance = true,
                securityCheckpoints = 20
            ),
            MesseEntranceGate(
                gateId = "GATE_EAST",
                gateName = "Eingang Ost (Parkhaus & Halle 10 / 11)",
                associatedHall = "Halle 10, 11",
                position = Lod2Point3D(358250.0, 5645250.0, 0.0),
                isMainEntrance = false,
                securityCheckpoints = 14
            ),
            MesseEntranceGate(
                gateId = "GATE_WEST",
                gateName = "Eingang West (Rhein-Boulevard / Tanzbrunnen)",
                associatedHall = "Halle 3, 4, 5",
                position = Lod2Point3D(357180.0, 5645300.0, 0.0),
                isMainEntrance = false,
                securityCheckpoints = 12
            )
        )
    }
}
