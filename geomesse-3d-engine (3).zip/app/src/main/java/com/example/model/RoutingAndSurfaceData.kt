package com.example.model

enum class WalkableRole(val displayName: String) {
    WALKABLE("Begehbar"),
    BLOCKED("Gesperrt / Hindernis"),
    UNKNOWN("Nicht annotiert")
}

enum class RoutingLevel(val label: String) {
    EG("Erdgeschoss (EG)"),
    OG1("1. Obergeschoss (OG1)"),
    OG2("2. Obergeschoss (OG2)"),
    FREIGELANDE("Freigelände / Piazza")
}

enum class EdgeType(val label: String, val icon: String) {
    CORRIDOR("Gang / Corridor", "directions_walk"),
    PORTAL("Halle Portal / Tor", "door_sliding"),
    STAIRS("Treppe", "stairs"),
    ESCALATOR("Rolltreppe", "escalator"),
    RAMP("Rampe", "ramps"),
    ELEVATOR("Aufzug / Lift", "elevator")
}

data class WalkableSurface(
    val surfaceId: String,
    val featureId: String,
    val label: String,
    val role: WalkableRole,
    val level: RoutingLevel,
    val polygon3D: List<Lod2Point3D>,
    val areaSqMeters: Double = 0.0
)

data class PortalAnnotation(
    val portalId: String,
    val featureId: String,
    val hallId: String,
    val name: String,
    val level: RoutingLevel,
    val position3D: Lod2Point3D,
    val physicallyPresent: Boolean = true,
    val eventStatusOpen: Boolean = true, // Event status: e.g. "Gamescom: Offen" vs "Geschlossen"
    val edgeType: EdgeType = EdgeType.PORTAL
)

data class RouteNode(
    val id: String,
    val position: Lod2Point3D,
    val label: String,
    val level: RoutingLevel
)

data class RouteEdge(
    val fromNodeId: String,
    val toNodeId: String,
    val edgeType: EdgeType,
    val distance: Double,
    val isPassable: Boolean = true
)

data class RouteResult(
    val startStandId: String,
    val endStandId: String,
    val pathNodes: List<RouteNode>,
    val totalDistanceMeters: Double,
    val levelsTraversed: List<RoutingLevel>,
    val edgeBreakdown: Map<EdgeType, Int>,
    val instructions: List<String>
)
