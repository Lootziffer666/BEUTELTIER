package com.example.model

enum class Lod2FeatureClass(val displayName: String, val code: String) {
    BUILDING("Building", "bldg:Building"),
    BUILDING_PART("Building Part", "bldg:BuildingPart"),
    OVERHEAD_ROOF("Überdachung", "bldg:RoofSurface/Canopy"),
    ELEVATED_BRIDGE("Brücke / Verbindung", "bldg:Bridge"),
    ELEVATED_STRUCTURE("Aufgeständertes Bauwerk", "bldg:Elevated"),
    OTHER_STRUCTURE("Sonstiges Bauwerk", "bldg:Other"),
    UNKNOWN("Unbekannt", "bldg:Unknown")
}

enum class Lod2SurfaceType(val displayName: String) {
    GROUND("GroundSurface"),
    WALL("WallSurface"),
    ROOF("RoofSurface"),
    OUTER_FLOOR("OuterFloorSurface"),
    CLOSURE("ClosureSurface"),
    UNKNOWN("Sonstiges")
}

data class Lod2Point3D(
    val x: Double,
    val y: Double,
    val z: Double
)

data class TextureUv(val u: Float, val v: Float)

data class CityGmlTexture(
    val imageUri: String,
    val mimeType: String = "",
    val base64Data: String? = null
)

data class Lod2Polygon(
    val id: String,
    val surfaceType: Lod2SurfaceType,
    val exteriorRing: List<Lod2Point3D>,
    val interiorRings: List<List<Lod2Point3D>> = emptyList(),
    val textureCoordinates: List<TextureUv> = emptyList(),
    val textureUri: String? = null
)

data class Lod2Feature(
    val id: String,
    val gmlId: String,
    val featureClass: Lod2FeatureClass,
    val functionCode: String,
    val functionDescription: String,
    val rellage: Int?, // 0 = ground level, 1 = elevated/aufgeständert, -1 = underground
    val minZ: Double,
    val maxZ: Double,
    val surfaces: List<Lod2Polygon>,
    val hasGroundSurface: Boolean,
    val hasHoles: Boolean,
    val rawXmlSnippet: String = "",
    val name: String = ""
) {
    val height: Double
        get() = maxZ - minZ

    val isElevated: Boolean
        get() = featureClass == Lod2FeatureClass.ELEVATED_BRIDGE ||
                featureClass == Lod2FeatureClass.ELEVATED_STRUCTURE ||
                (rellage != null && rellage > 0) ||
                (!hasGroundSurface && minZ > 2.0)
}

data class Lod2InventorySummary(
    val totalFeatures: Int,
    val buildingCount: Int,
    val buildingPartCount: Int,
    val roofCount: Int,
    val bridgeCount: Int,
    val elevatedStructureCount: Int,
    val surfaceCounts: Map<Lod2SurfaceType, Int>,
    val featuresWithoutGroundSurfaceCount: Int,
    val rellageDistribution: Map<Int, Int>,
    val topLevelTags: Map<String, Int>,
    val namespaces: List<String>,
    val timestamp: String
)
