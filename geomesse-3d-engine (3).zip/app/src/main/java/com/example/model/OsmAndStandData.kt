package com.example.model

data class OsmHallBoundary(
    val hallId: String,
    val hallName: String,
    val osmWayId: String,
    val localPolygon2D: List<Pair<Double, Double>>, // Local coordinate system
    val elevationMin: Double = 0.0,
    val elevationMax: Double = 18.0
)

data class ExhibitionStand(
    val standId: String,
    val exhibitorName: String,
    val hallId: String,
    val localX: Double,
    val localY: Double,
    val width: Double,
    val depth: Double,
    val category: String,
    var worldX: Double = 0.0,
    var worldY: Double = 0.0,
    var worldZ: Double = 0.0,
    var isOutsideLod2Bounds: Boolean = false
)

data class AnchorPointPair(
    val id: String,
    val name: String,
    val localX: Double,
    val localY: Double,
    val worldX: Double,
    val worldY: Double,
    val worldZ: Double = 0.0
)

data class RegistrationResult(
    val hallId: String,
    val tx: Double,
    val ty: Double,
    val rotationRad: Double,
    val scale: Double = 1.0,
    val residuals: List<Double> = emptyList(), // Mean squared error per anchor point
    val meanResidualError: Double = 0.0,
    val isLeastSquaresFit: Boolean = false,
    val isValid: Boolean = true
)
