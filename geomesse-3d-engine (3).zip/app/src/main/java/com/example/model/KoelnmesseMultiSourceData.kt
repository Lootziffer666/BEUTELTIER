package com.example.model

/**
 * Multi-Source Data Models for Koelnmesse Fusion Engine:
 * 1. LoD2 CityGML (3D Official Solids & Roofs)
 * 2. 3D-Mesh (b3dm / SLPK / I3S Photorealistic Textures)
 * 3. ALKIS NAS (2D Cadastre Flurstücke & Property Lines)
 * 4. Orthofotos (Georeferenced Aerial Imagery WMS DOP20)
 * 5. PDF-Hallenpläne (Indoor Levels, Escalators, Elevators)
 * 6. OpenStreetMap (Roads, Rail, ÖPNV Stations & Entrance Gates)
 */

data class AlkisParcel(
    val id: String, // e.g. "05315000_12_408_12"
    val flur: Int, // e.g. 12
    val flurstueckNummer: String, // e.g. "408/12"
    val gemarkung: String = "Deutz",
    val eigentuemer: String = "Koelnmesse GmbH",
    val nutzungsart: String = "Messe- und Ausstellungsgelände",
    val flaecheQm: Double,
    val polygonRing: List<Lod2Point3D>
)

data class OrthofotoWmsLayer(
    val layerId: String = "nw_dop_rgb",
    val title: String = "Geobasis NRW DOP20 Orthofoto",
    val wmsUrl: String = "https://www.wms.nrw.de/geobasis/wms_nw_dop?SERVICE=WMS&VERSION=1.3.0&REQUEST=GetMap",
    val resolutionCm: Int = 20,
    val bboxEpsg25832: String = "356800,5644800,358200,5646200",
    val isVisible: Boolean = true,
    val opacity: Float = 0.85f
)

data class Mesh3dTilesetConfig(
    val tilesetId: String = "nrw_mesh_koelnmesse_i3s",
    val title: String = "NRW 3D-Mesh Photorealistic Mesh",
    val serviceUrl: String = "https://www.gis.nrw.de/geobasis/3D_mesh/SceneServer",
    val format: String = "b3dm / I3S 1.7",
    val isMeshVisible: Boolean = true,
    val meshOpacity: Float = 0.9f,
    val detailLevel: String = "LOD 0-4 Dynamic Stream"
)

data class IndoorLevelPlan(
    val levelId: String, // e.g. "EBENE_0", "EBENE_1", "EBENE_2"
    val levelName: String, // "Ebene 0 (Erdgeschoss)", "Ebene 1 (Obergeschoss)"
    val hallId: String, // "Halle 1", "Halle 3", etc.
    val pdfPlanTitle: String,
    val pdfResolutionDpi: Int = 300,
    val totalStands: Int,
    val isCurrentLevel: Boolean = false
)

data class IndoorElevator(
    val id: String,
    val name: String,
    val hallId: String,
    val servicedLevels: List<String>,
    val x: Double,
    val y: Double,
    val capacityKg: Int = 2000
)

data class IndoorEscalator(
    val id: String,
    val name: String,
    val hallId: String,
    val fromLevel: String,
    val toLevel: String,
    val x: Double,
    val y: Double
)

data class OsmTransportLine(
    val id: String,
    val name: String,
    val type: TransportType,
    val coordinates: List<Lod2Point3D>
)

enum class TransportType {
    ROAD, RAIL_ICE, TRAM_SUBWAY, PEDESTRIAN_BOULEVARD
}

data class OsmTransitStation(
    val id: String,
    val name: String, // e.g. "Bahnhof Köln Messe/Deutz"
    val lines: List<String>, // e.g. ["ICE", "S6", "S11", "Tram 1", "Tram 9", "U3", "U4"]
    val position: Lod2Point3D,
    val distanceToMesseMeters: Int
)

data class MesseEntranceGate(
    val gateId: String, // "GATE_SOUTH", "GATE_NORTH", etc.
    val gateName: String, // "Eingang Süd", "Eingang Nord", "Eingang Ost", "Eingang West"
    val associatedHall: String,
    val position: Lod2Point3D,
    val isMainEntrance: Boolean = true,
    val securityCheckpoints: Int = 12
)

data class LayerVisibilityState(
    val showCityGmlLod2: Boolean = true,
    val show3dMeshPhotoreal: Boolean = true,
    val showAlkisCadastre: Boolean = true,
    val showOrthofotoWms: Boolean = true,
    val showIndoorLevelsPdf: Boolean = true,
    val showOsmInfrastructure: Boolean = true
)
