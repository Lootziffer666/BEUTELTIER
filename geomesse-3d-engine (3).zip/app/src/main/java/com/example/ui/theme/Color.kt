package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val TealPrimary = Color(0xFF006A6A)
val TealOnPrimary = Color(0xFFFFFFFF)
val TealPrimaryContainer = Color(0xFFCCE8E8)
val TealOnPrimaryContainer = Color(0xFF002020)

val TealSecondary = Color(0xFF4A6363)
val TealOnSecondary = Color(0xFFFFFFFF)

val DarkViewportBg = Color(0xFF0B0F10)
val DarkViewportCard = Color(0xFF161C1E)

val LightBg = Color(0xFFF8FAF9)
val LightSurface = Color(0xFFFFFFFF)
val LightOnSurface = Color(0xFF191C1C)
val LightSurfaceVariant = Color(0xFFF0F5F4)
val LightOutline = Color(0xFFDAE5E3)

val HighlightGold = Color(0xFFFFD700)
val PortalRed = Color(0xFFFF5252)
val WalkableGreen = Color(0xFF00C853)
