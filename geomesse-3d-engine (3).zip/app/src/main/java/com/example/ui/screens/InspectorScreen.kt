package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Lod2FeatureClass
import com.example.repository.MesseRepository
import com.example.ui.components.Viewport3D

@Composable
fun InspectorScreen(
    repository: MesseRepository,
    onNavigateToRegistration: () -> Unit,
    onNavigateToRouting: () -> Unit
) {
    val features by repository.lod2Features.collectAsState()
    val selectedFeature by repository.selectedFeature.collectAsState()
    val osmHalls by repository.osmHalls.collectAsState()
    val stands by repository.stands.collectAsState()
    val portals by repository.portals.collectAsState()
    val walkableSurfaces by repository.walkableSurfaces.collectAsState()

    // Multi-Source States
    val alkisParcels by repository.alkisParcels.collectAsState()
    val orthofotoWms by repository.orthofotoWms.collectAsState()
    val mesh3dConfig by repository.mesh3dConfig.collectAsState()
    val indoorLevels by repository.indoorLevels.collectAsState()
    val indoorElevators by repository.indoorElevators.collectAsState()
    val indoorEscalators by repository.indoorEscalators.collectAsState()
    val osmTransportLines by repository.osmTransportLines.collectAsState()
    val osmTransitStations by repository.osmTransitStations.collectAsState()
    val entranceGates by repository.entranceGates.collectAsState()
    val layerVisibility by repository.layerVisibility.collectAsState()

    var selectedFilterClass by remember { mutableStateOf<Lod2FeatureClass?>(null) }
    var showRawXmlDialog by remember { mutableStateOf(false) }

    val tealPrimary = Color(0xFF006A6A)

    Column(modifier = Modifier.fillMaxSize()) {
        // Multi-Source Data Fusion Layer Toggle Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF0F172A))
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 12.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Dorf/Messe-Fusion:",
                style = MaterialTheme.typography.labelSmall,
                color = Color(0xFF94A3B8),
                fontWeight = FontWeight.Bold,
                fontSize = 10.sp,
                modifier = Modifier.padding(end = 4.dp)
            )

            // 1. LoD2 CityGML
            FilterChip(
                selected = layerVisibility.showCityGmlLod2,
                onClick = { repository.updateLayerVisibility(cityGml = !layerVisibility.showCityGmlLod2) },
                label = { Text("🏢 LoD2 CityGML") },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = Color(0xFF0284C7),
                    selectedLabelColor = Color.White,
                    containerColor = Color(0xFF1E293B),
                    labelColor = Color(0xFFCBD5E1)
                )
            )

            // 2. 3D-Mesh
            FilterChip(
                selected = layerVisibility.show3dMeshPhotoreal,
                onClick = { repository.updateLayerVisibility(mesh3d = !layerVisibility.show3dMeshPhotoreal) },
                label = { Text("📸 3D-Mesh") },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = Color(0xFF0D9488),
                    selectedLabelColor = Color.White,
                    containerColor = Color(0xFF1E293B),
                    labelColor = Color(0xFFCBD5E1)
                )
            )

            // 3. ALKIS NAS
            FilterChip(
                selected = layerVisibility.showAlkisCadastre,
                onClick = { repository.updateLayerVisibility(alkis = !layerVisibility.showAlkisCadastre) },
                label = { Text("📐 ALKIS NAS (${alkisParcels.size})") },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = Color(0xFFD97706),
                    selectedLabelColor = Color.White,
                    containerColor = Color(0xFF1E293B),
                    labelColor = Color(0xFFCBD5E1)
                )
            )

            // 4. Orthofoto WMS
            FilterChip(
                selected = layerVisibility.showOrthofotoWms,
                onClick = { repository.updateLayerVisibility(orthofoto = !layerVisibility.showOrthofotoWms) },
                label = { Text("🗺️ Orthofoto WMS") },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = Color(0xFF16A34A),
                    selectedLabelColor = Color.White,
                    containerColor = Color(0xFF1E293B),
                    labelColor = Color(0xFFCBD5E1)
                )
            )

            // 5. PDF-Hallenpläne
            FilterChip(
                selected = layerVisibility.showIndoorLevelsPdf,
                onClick = { repository.updateLayerVisibility(indoorPdf = !layerVisibility.showIndoorLevelsPdf) },
                label = { Text("📄 PDF-Hallenpläne (${indoorLevels.size} Ebenen)") },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = Color(0xFF9333EA),
                    selectedLabelColor = Color.White,
                    containerColor = Color(0xFF1E293B),
                    labelColor = Color(0xFFCBD5E1)
                )
            )

            // 6. OpenStreetMap
            FilterChip(
                selected = layerVisibility.showOsmInfrastructure,
                onClick = { repository.updateLayerVisibility(osm = !layerVisibility.showOsmInfrastructure) },
                label = { Text("🧭 OSM & Eingänge (${entranceGates.size})") },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = Color(0xFFE11D48),
                    selectedLabelColor = Color.White,
                    containerColor = Color(0xFF1E293B),
                    labelColor = Color(0xFFCBD5E1)
                )
            )
        }

        // Filter Chips Row for Feature Classes
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.surface)
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 12.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            FilterChip(
                selected = selectedFilterClass == null,
                onClick = { selectedFilterClass = null },
                label = { Text("Alle Baukörper (${features.size})") },
                colors = FilterChipDefaults.filterChipColors(selectedContainerColor = tealPrimary, selectedLabelColor = Color.White)
            )

            Lod2FeatureClass.entries.forEach { fc ->
                val count = features.count { it.featureClass == fc }
                if (count > 0) {
                    FilterChip(
                        selected = selectedFilterClass == fc,
                        onClick = { selectedFilterClass = fc },
                        label = { Text("${fc.displayName} ($count)") },
                        colors = FilterChipDefaults.filterChipColors(selectedContainerColor = tealPrimary, selectedLabelColor = Color.White)
                    )
                }
            }
        }

        // 3D Viewport Box
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
            Viewport3D(
                features = features,
                selectedFeature = selectedFeature,
                osmHalls = osmHalls,
                stands = stands,
                portals = portals,
                walkableSurfaces = walkableSurfaces,
                routeResult = null,
                showOsmWireframe = false,
                showWalkableHighlights = false,
                showStands = true,
                filterClass = selectedFilterClass,
                onSelectFeature = { repository.selectFeature(it) },
                modifier = Modifier.fillMaxSize(),
                alkisParcels = alkisParcels,
                orthofotoWms = orthofotoWms,
                mesh3dConfig = mesh3dConfig,
                indoorLevels = indoorLevels,
                indoorElevators = indoorElevators,
                indoorEscalators = indoorEscalators,
                osmTransportLines = osmTransportLines,
                osmTransitStations = osmTransitStations,
                entranceGates = entranceGates,
                layerVisibility = layerVisibility,
                onToggleLayer = { c, m, a, o, i, s -> repository.updateLayerVisibility(c, m, a, o, i, s) }
            )
        }

        // Bottom Inspector Sheet
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
            shadowElevation = 12.dp,
            color = MaterialTheme.colorScheme.surface
        ) {
            Column(
                modifier = Modifier
                    .padding(16.dp)
                    .fillMaxWidth()
            ) {
                // Drag Handle
                Box(
                    modifier = Modifier
                        .width(32.dp)
                        .height(4.dp)
                        .background(Color.LightGray, shape = RoundedCornerShape(2.dp))
                        .align(Alignment.CenterHorizontally)
                )

                Spacer(modifier = Modifier.height(12.dp))

                selectedFeature?.let { f ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Top
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = f.featureClass.code.uppercase(),
                                style = MaterialTheme.typography.labelSmall,
                                color = tealPrimary,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "ID: ${f.id}",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Funktion: ${f.functionCode} (${f.functionDescription})",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color.Gray
                            )
                        }

                        Box(
                            modifier = Modifier
                                .background(MaterialTheme.colorScheme.surfaceVariant, shape = RoundedCornerShape(8.dp))
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = "Z: %.2fm - %.2fm".format(f.minZ, f.maxZ),
                                style = MaterialTheme.typography.labelSmall,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Card(
                            modifier = Modifier.weight(1f),
                            colors = CardDefaults.cardColors(
                                containerColor = MaterialTheme.colorScheme.surfaceVariant,
                                contentColor = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Text(
                                    "Rellage / Status",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                                )
                                Text(
                                    text = if (f.isElevated) "Aufgeständert (Rellage 1)" else "Boden eben (Rellage 0)",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        Card(
                            modifier = Modifier.weight(1f),
                            colors = CardDefaults.cardColors(
                                containerColor = MaterialTheme.colorScheme.surfaceVariant,
                                contentColor = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Text(
                                    "Oberflächen",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                                )
                                Text(
                                    text = "${f.surfaces.size} (${if (f.hasGroundSurface) "mit Ground" else "OHNE Ground"})",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = onNavigateToRouting,
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = tealPrimary),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("Begehbarkeit Annotieren")
                        }

                        OutlinedButton(
                            onClick = onNavigateToRegistration,
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("Registrierungs-Math")
                        }
                    }
                } ?: run {
                    Text(
                        text = "Wähle ein LoD2-Objekt in der 3D-Ansicht aus",
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color.Gray,
                        modifier = Modifier.align(Alignment.CenterHorizontally)
                    )
                }
            }
        }
    }
}
