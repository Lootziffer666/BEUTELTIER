package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.ImageShader
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.ShaderBrush
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.res.imageResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.AlkisParcel
import com.example.model.ExhibitionStand
import com.example.model.IndoorElevator
import com.example.model.IndoorEscalator
import com.example.model.IndoorLevelPlan
import com.example.model.LayerVisibilityState
import com.example.model.Lod2Feature
import com.example.model.Lod2FeatureClass
import com.example.model.Lod2Polygon
import com.example.model.Lod2SurfaceType
import com.example.model.Mesh3dTilesetConfig
import com.example.model.MesseEntranceGate
import com.example.model.OrthofotoWmsLayer
import com.example.model.OsmHallBoundary
import com.example.model.OsmTransitStation
import com.example.model.OsmTransportLine
import com.example.model.PortalAnnotation
import com.example.model.RouteResult
import com.example.model.TransportType
import com.example.model.WalkableSurface
import kotlin.math.cos
import kotlin.math.sin

enum class RenderMode(
    val displayName: String,
    val connectionLabel: String,
    val serviceSource: String
) {
    REALITY_MESH(
        displayName = "Reality Mesh",
        connectionLabel = "NRW 3D-Mesh · I3S Live",
        serviceSource = "https://www.gis.nrw.de/geobasis/3D_mesh/SceneServer (Layer 0)"
    ),
    LOD2_DIAGNOSE(
        displayName = "LoD2 Diagnose",
        connectionLabel = "dz.nrw LoD2 Live Connection",
        serviceSource = "dz.nrw Vektor 3D-Stadtmodell (LOD 2.2)"
    ),
    HYBRID(
        displayName = "Hybrid",
        connectionLabel = "NRW 3D-Mesh · I3S Live",
        serviceSource = "I3S SceneServer + LoD2 Vektorüberlagerung"
    )
}

data class DrawablePolygon(
    val poly: Lod2Polygon,
    val feature: Lod2Feature,
    val isSelected: Boolean,
    val depth: Double
)

@Composable
fun Viewport3D(
    features: List<Lod2Feature>,
    selectedFeature: Lod2Feature?,
    osmHalls: List<OsmHallBoundary>,
    stands: List<ExhibitionStand>,
    portals: List<PortalAnnotation>,
    walkableSurfaces: List<WalkableSurface>,
    routeResult: RouteResult?,
    showOsmWireframe: Boolean,
    showWalkableHighlights: Boolean,
    showStands: Boolean,
    filterClass: Lod2FeatureClass?,
    onSelectFeature: (Lod2Feature) -> Unit,
    modifier: Modifier = Modifier,
    initialRenderMode: RenderMode = RenderMode.REALITY_MESH,
    alkisParcels: List<AlkisParcel> = emptyList(),
    orthofotoWms: OrthofotoWmsLayer? = null,
    mesh3dConfig: Mesh3dTilesetConfig? = null,
    indoorLevels: List<IndoorLevelPlan> = emptyList(),
    indoorElevators: List<IndoorElevator> = emptyList(),
    indoorEscalators: List<IndoorEscalator> = emptyList(),
    osmTransportLines: List<OsmTransportLine> = emptyList(),
    osmTransitStations: List<OsmTransitStation> = emptyList(),
    entranceGates: List<MesseEntranceGate> = emptyList(),
    layerVisibility: LayerVisibilityState = LayerVisibilityState(),
    onToggleLayer: ((cityGml: Boolean, mesh3d: Boolean, alkis: Boolean, orthofoto: Boolean, indoorPdf: Boolean, osm: Boolean) -> Unit)? = null
) {
    var scale by remember { mutableFloatStateOf(1.0f) }
    var offsetX by remember { mutableFloatStateOf(0f) }
    var offsetY by remember { mutableFloatStateOf(0f) }
    var currentRenderMode by remember { mutableStateOf(initialRenderMode) }

    val darkBg = Color(0xFF0D1216)
    val daylightBg = Color(0xFFDFE9F2)
    val highlightGold = Color(0xFFFFD700)

    val filteredFeatures = remember(features, filterClass) {
        if (filterClass != null) {
            features.filter { it.featureClass == filterClass }
        } else {
            features
        }
    }

    val (siteOriginX, siteOriginY, siteOriginZ) = remember(filteredFeatures) {
        var sumX = 0.0
        var sumY = 0.0
        var sumZ = 0.0
        var count = 0
        filteredFeatures.forEach { feature ->
            feature.surfaces.forEach { poly ->
                poly.exteriorRing.forEach { p ->
                    sumX += p.x
                    sumY += p.y
                    sumZ += p.z
                    count++
                }
            }
        }
        if (count > 0) {
            Triple(sumX / count, sumY / count, sumZ / count)
        } else {
            Triple(357750.0, 5645500.0, 45.0)
        }
    }

    val isDaylight = currentRenderMode != RenderMode.LOD2_DIAGNOSE

    Box(
        modifier = modifier
            .background(if (isDaylight) daylightBg else darkBg)
            .pointerInput(Unit) {
                detectTransformGestures { _, pan, zoom, _ ->
                    scale = (scale * zoom).coerceIn(0.3f, 4.0f)
                    offsetX += pan.x
                    offsetY += pan.y
                }
            }
            .pointerInput(filteredFeatures, siteOriginX, siteOriginY, siteOriginZ) {
                detectTapGestures { tapOffset ->
                    val centerX = size.width / 2f + offsetX
                    val centerY = size.height / 2f + offsetY

                    var closestFeature: Lod2Feature? = null
                    var minDistance = Float.MAX_VALUE

                    filteredFeatures.forEach { feature ->
                        feature.surfaces.forEach { poly ->
                            poly.exteriorRing.forEach { p ->
                                val projected = project3D(p.x, p.y, p.z, siteOriginX, siteOriginY, siteOriginZ, centerX, centerY, scale)
                                val dist = (projected - tapOffset).getDistance()
                                if (dist < minDistance && dist < 120f) {
                                    minDistance = dist
                                    closestFeature = feature
                                }
                            }
                        }
                    }

                    closestFeature?.let { onSelectFeature(it) }
                }
            }
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val centerX = size.width / 2f + offsetX
            val centerY = size.height / 2f + offsetY

            // 1. Draw Ground Surface Layer
            if (isDaylight) {
                // Realistic Daylight Terrain Surface (Asphalt, Paving, Rhine Lawn & Boulevard)
                drawRealisticDaylightGround(siteOriginX, siteOriginY, siteOriginZ, centerX, centerY, scale)
            } else {
                // Dark Neon 3D Grid
                drawIsometricGrid(siteOriginX, siteOriginY, siteOriginZ, centerX, centerY, scale, Color(0xFF1D282C))
            }

            // 2. Render ALKIS Cadastral Parcels Layer
            if (layerVisibility.showAlkisCadastre) {
                drawAlkisParcels(alkisParcels, siteOriginX, siteOriginY, siteOriginZ, centerX, centerY, scale)
            }

            // 3. Render OSM Transport Infrastructure, Transit Stations & Entrance Gates
            if (layerVisibility.showOsmInfrastructure) {
                drawOsmTransportLines(osmTransportLines, siteOriginX, siteOriginY, siteOriginZ, centerX, centerY, scale)
                drawOsmTransitStations(osmTransitStations, siteOriginX, siteOriginY, siteOriginZ, centerX, centerY, scale)
                drawMesseEntranceGates(entranceGates, siteOriginX, siteOriginY, siteOriginZ, centerX, centerY, scale)
            }

            // 4. Render PDF Indoor GIS Facilities (Elevators & Escalators)
            if (layerVisibility.showIndoorLevelsPdf) {
                drawIndoorFacilities(indoorElevators, indoorEscalators, siteOriginX, siteOriginY, siteOriginZ, centerX, centerY, scale)
            }

            // 5. Prepare & Depth-Sort All 3D Polygons
            if (layerVisibility.showCityGmlLod2) {
                val drawableList = mutableListOf<DrawablePolygon>()

                filteredFeatures.forEach { feature ->
                    val isSelected = feature.id == selectedFeature?.id
                    feature.surfaces.forEach { poly ->
                        var sumX = 0.0
                        var sumY = 0.0
                        var sumZ = 0.0
                        poly.exteriorRing.forEach { p ->
                            sumX += (p.x - siteOriginX)
                            sumY += (p.y - siteOriginY)
                            sumZ += (p.z - siteOriginZ)
                        }
                        val n = poly.exteriorRing.size.coerceAtLeast(1)
                        val avgX = sumX / n
                        val avgY = sumY / n
                        val avgZ = sumZ / n

                        val depth = avgX + avgY - avgZ * 0.4

                        drawableList.add(
                            DrawablePolygon(
                                poly = poly,
                                feature = feature,
                                isSelected = isSelected,
                                depth = depth
                            )
                        )
                    }
                }

                drawableList.sortBy { it.depth }

                drawableList.forEach { item ->
                    draw3DPolygon(
                        item = item,
                        originX = siteOriginX,
                        originY = siteOriginY,
                        originZ = siteOriginZ,
                        centerX = centerX,
                        centerY = centerY,
                        scale = scale,
                        renderMode = if (layerVisibility.show3dMeshPhotoreal) currentRenderMode else RenderMode.LOD2_DIAGNOSE,
                        highlightGold = highlightGold
                    )
                }
            }

            // 4. Render OSM Wireframes (Debug Overlay)
            if (showOsmWireframe) {
                osmHalls.forEach { hall ->
                    drawOsmWireframe(hall, siteOriginX, siteOriginY, siteOriginZ, centerX, centerY, scale)
                }
            }

            // 5. Render Walkable Surfaces Highlight
            if (showWalkableHighlights) {
                walkableSurfaces.forEach { surface ->
                    drawWalkableHighlight(surface, siteOriginX, siteOriginY, siteOriginZ, centerX, centerY, scale)
                }
            }

            // 6. Render 3D Exhibition Stands
            if (showStands) {
                stands.forEach { stand ->
                    draw3DStandBox(stand, siteOriginX, siteOriginY, siteOriginZ, centerX, centerY, scale)
                }
            }

            // 7. Render Portal Markers
            portals.forEach { portal ->
                drawPortalMarker(portal, siteOriginX, siteOriginY, siteOriginZ, centerX, centerY, scale)
            }

            // 8. Render 3D Route Path
            routeResult?.let { route ->
                drawRoute3D(route, siteOriginX, siteOriginY, siteOriginZ, centerX, centerY, scale)
            }
        }

        // Integrated Responsive Top Controls Panel (Status Badge & Layer Selector stacked vertically to eliminate overlaps!)
        Column(
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(10.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            // Connection Status Card
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = if (isDaylight) Color(0xFFFFFFFF).copy(alpha = 0.94f) else Color(0xFF121B1D).copy(alpha = 0.92f),
                shadowElevation = 6.dp
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .background(
                                if (currentRenderMode == RenderMode.LOD2_DIAGNOSE) Color(0xFF00E676) else Color(0xFF29B6F6),
                                shape = CircleShape
                            )
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = currentRenderMode.connectionLabel.uppercase(),
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = if (isDaylight) Color(0xFF0D47A1) else Color(0xFF00E676)
                        )
                        Text(
                            text = if (currentRenderMode == RenderMode.LOD2_DIAGNOSE)
                                "${filteredFeatures.size} Objekte • ${filteredFeatures.sumOf { it.surfaces.size }} Vektor-Flächen"
                            else
                                "IntegratedMeshLayer 0 • Texturiert",
                            style = MaterialTheme.typography.bodySmall,
                            fontSize = 11.sp,
                            color = if (isDaylight) Color(0xFF37474F) else Color.LightGray
                        )
                    }
                }
            }

            // Layer Selector Bar Card
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = if (isDaylight) Color(0xFFFFFFFF).copy(alpha = 0.95f) else Color(0xFF141F23).copy(alpha = 0.95f),
                shadowElevation = 6.dp
            ) {
                Row(
                    modifier = Modifier.padding(3.dp),
                    horizontalArrangement = Arrangement.spacedBy(3.dp)
                ) {
                    RenderMode.entries.forEach { mode ->
                        val isSelected = currentRenderMode == mode
                        Box(
                            modifier = Modifier
                                .background(
                                    color = if (isSelected) {
                                        if (isDaylight) Color(0xFF0277BD) else Color(0xFF00897B)
                                    } else Color.Transparent,
                                    shape = RoundedCornerShape(8.dp)
                                )
                                .clickable { currentRenderMode = mode }
                                .padding(horizontal = 9.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = mode.displayName,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                fontSize = 11.sp,
                                color = if (isSelected) Color.White else (if (isDaylight) Color(0xFF37474F) else Color.LightGray)
                            )
                        }
                    }
                }
            }
        }

        // Camera Control Buttons Floating Right
        Column(
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .padding(end = 10.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            IconButton(
                onClick = { scale = (scale * 1.25f).coerceAtMost(4.0f) },
                colors = IconButtonDefaults.iconButtonColors(
                    containerColor = if (isDaylight) Color.White.copy(alpha = 0.9f) else Color(0xFF121B1D).copy(alpha = 0.9f),
                    contentColor = if (isDaylight) Color.Black else Color.White
                )
            ) {
                Icon(Icons.Default.Add, contentDescription = "Zoom In")
            }

            IconButton(
                onClick = { scale = (scale / 1.25f).coerceAtLeast(0.3f) },
                colors = IconButtonDefaults.iconButtonColors(
                    containerColor = if (isDaylight) Color.White.copy(alpha = 0.9f) else Color(0xFF121B1D).copy(alpha = 0.9f),
                    contentColor = if (isDaylight) Color.Black else Color.White
                )
            ) {
                Icon(Icons.Default.Remove, contentDescription = "Zoom Out")
            }

            IconButton(
                onClick = {
                    scale = 1.0f
                    offsetX = 0f
                    offsetY = 0f
                },
                colors = IconButtonDefaults.iconButtonColors(
                    containerColor = if (isDaylight) Color.White.copy(alpha = 0.9f) else Color(0xFF121B1D).copy(alpha = 0.9f),
                    contentColor = if (isDaylight) Color.Black else Color.White
                )
            ) {
                Icon(Icons.Default.Refresh, contentDescription = "Reset View")
            }
        }

        // Selected Feature Bottom Card Overlay
        selectedFeature?.let { feat ->
            Card(
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(12.dp),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (isDaylight) Color.White.copy(alpha = 0.95f) else Color(0xFF121B1D).copy(alpha = 0.95f)
                ),
                elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .background(highlightGold, shape = CircleShape)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = feat.name,
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = if (isDaylight) Color(0xFF1A237E) else Color.White
                        )
                        Text(
                            text = "Klasse: ${feat.featureClass.displayName} • H: %.1fm • Mesh-Sync".format(feat.maxZ - feat.minZ),
                            style = MaterialTheme.typography.bodySmall,
                            color = if (isDaylight) Color(0xFF455A64) else Color.LightGray
                        )
                    }
                }
            }
        }
    }
}

private fun DrawScope.drawRealisticDaylightGround(
    originX: Double, originY: Double, originZ: Double,
    centerX: Float, centerY: Float, scale: Float
) {
    // 1. Overall Base Paving (Koelnmesse outdoor grounds / Plaza)
    val baseP1 = project3D(originX - 350.0, originY - 350.0, originZ - 0.1, originX, originY, originZ, centerX, centerY, scale)
    val baseP2 = project3D(originX + 350.0, originY - 350.0, originZ - 0.1, originX, originY, originZ, centerX, centerY, scale)
    val baseP3 = project3D(originX + 350.0, originY + 350.0, originZ - 0.1, originX, originY, originZ, centerX, centerY, scale)
    val baseP4 = project3D(originX - 350.0, originY + 350.0, originZ - 0.1, originX, originY, originZ, centerX, centerY, scale)

    val basePath = Path().apply {
        moveTo(baseP1.x, baseP1.y)
        lineTo(baseP2.x, baseP2.y)
        lineTo(baseP3.x, baseP3.y)
        lineTo(baseP4.x, baseP4.y)
        close()
    }
    drawPath(basePath, Color(0xFFCBD5E1)) // Interlocking concrete pavement grey

    // Paving pattern grid lines
    for (i in -6..6) {
        val lineP1 = project3D(originX + i * 50.0, originY - 350.0, originZ - 0.08, originX, originY, originZ, centerX, centerY, scale)
        val lineP2 = project3D(originX + i * 50.0, originY + 350.0, originZ - 0.08, originX, originY, originZ, centerX, centerY, scale)
        drawLine(Color(0xFFB0BEC5), lineP1, lineP2, strokeWidth = 1f)
    }

    // 2. Rhine Riverside Green Lawns & Landscaping (West Side)
    val lawnP1 = project3D(originX - 350.0, originY - 350.0, originZ, originX, originY, originZ, centerX, centerY, scale)
    val lawnP2 = project3D(originX - 180.0, originY - 350.0, originZ, originX, originY, originZ, centerX, centerY, scale)
    val lawnP3 = project3D(originX - 180.0, originY + 350.0, originZ, originX, originY, originZ, centerX, centerY, scale)
    val lawnP4 = project3D(originX - 350.0, originY + 350.0, originZ, originX, originY, originZ, centerX, centerY, scale)

    val lawnPath = Path().apply {
        moveTo(lawnP1.x, lawnP1.y)
        lineTo(lawnP2.x, lawnP2.y)
        lineTo(lawnP3.x, lawnP3.y)
        lineTo(lawnP4.x, lawnP4.y)
        close()
    }
    drawPath(lawnPath, Color(0xFF6B8E23).copy(alpha = 0.85f)) // Rhine lawn green

    // 3. Rhine River Water Strip
    val riverP1 = project3D(originX - 350.0, originY - 350.0, originZ - 0.2, originX, originY, originZ, centerX, centerY, scale)
    val riverP2 = project3D(originX - 260.0, originY - 350.0, originZ - 0.2, originX, originY, originZ, centerX, centerY, scale)
    val riverP3 = project3D(originX - 260.0, originY + 350.0, originZ - 0.2, originX, originY, originZ, centerX, centerY, scale)
    val riverP4 = project3D(originX - 350.0, originY + 350.0, originZ - 0.2, originX, originY, originZ, centerX, centerY, scale)

    val riverPath = Path().apply {
        moveTo(riverP1.x, riverP1.y)
        lineTo(riverP2.x, riverP2.y)
        lineTo(riverP3.x, riverP3.y)
        lineTo(riverP4.x, riverP4.y)
        close()
    }
    drawPath(riverPath, Color(0xFF1E88E5).copy(alpha = 0.80f)) // River water

    // 4. Asphalt Logistics Roads & Parking Zones
    val roadP1 = project3D(originX - 170.0, originY - 200.0, originZ + 0.05, originX, originY, originZ, centerX, centerY, scale)
    val roadP2 = project3D(originX + 280.0, originY - 200.0, originZ + 0.05, originX, originY, originZ, centerX, centerY, scale)
    val roadP3 = project3D(originX + 280.0, originY - 160.0, originZ + 0.05, originX, originY, originZ, centerX, centerY, scale)
    val roadP4 = project3D(originX - 170.0, originY - 160.0, originZ + 0.05, originX, originY, originZ, centerX, centerY, scale)

    val roadPath = Path().apply {
        moveTo(roadP1.x, roadP1.y)
        lineTo(roadP2.x, roadP2.y)
        lineTo(roadP3.x, roadP3.y)
        lineTo(roadP4.x, roadP4.y)
        close()
    }
    drawPath(roadPath, Color(0xFF475569)) // Dark asphalt road

    // 5. Messe Boulevard Pedestrian Concourse
    val blvdP1 = project3D(originX - 100.0, originY - 320.0, originZ + 0.1, originX, originY, originZ, centerX, centerY, scale)
    val blvdP2 = project3D(originX - 40.0, originY - 320.0, originZ + 0.1, originX, originY, originZ, centerX, centerY, scale)
    val blvdP3 = project3D(originX - 40.0, originY + 320.0, originZ + 0.1, originX, originY, originZ, centerX, centerY, scale)
    val blvdP4 = project3D(originX - 100.0, originY + 320.0, originZ + 0.1, originX, originY, originZ, centerX, centerY, scale)

    val blvdPath = Path().apply {
        moveTo(blvdP1.x, blvdP1.y)
        lineTo(blvdP2.x, blvdP2.y)
        lineTo(blvdP3.x, blvdP3.y)
        lineTo(blvdP4.x, blvdP4.y)
        close()
    }
    drawPath(blvdPath, Color(0xFF94A3B8)) // Glazed boulevard floor
    drawPath(blvdPath, Color(0xFF64748B), style = Stroke(width = 1.5f))
}

private fun DrawScope.drawIsometricGrid(
    originX: Double, originY: Double, originZ: Double,
    centerX: Float, centerY: Float, scale: Float, color: Color
) {
    for (i in -8..8) {
        val p1 = project3D(originX + i * 40.0, originY - 320.0, originZ, originX, originY, originZ, centerX, centerY, scale)
        val p2 = project3D(originX + i * 40.0, originY + 320.0, originZ, originX, originY, originZ, centerX, centerY, scale)
        drawLine(color, p1, p2, strokeWidth = 1f)

        val p3 = project3D(originX - 320.0, originY + i * 40.0, originZ, originX, originY, originZ, centerX, centerY, scale)
        val p4 = project3D(originX + 320.0, originY + i * 40.0, originZ, originX, originY, originZ, centerX, centerY, scale)
        drawLine(color, p3, p4, strokeWidth = 1f)
    }
}

private fun DrawScope.draw3DPolygon(
    item: DrawablePolygon,
    originX: Double,
    originY: Double,
    originZ: Double,
    centerX: Float,
    centerY: Float,
    scale: Float,
    renderMode: RenderMode,
    highlightGold: Color
) {
    val poly = item.poly
    val feature = item.feature
    val isSelected = item.isSelected

    val path = Path()
    val points = poly.exteriorRing.map { p ->
        project3D(p.x, p.y, p.z, originX, originY, originZ, centerX, centerY, scale)
    }

    if (points.isEmpty()) return

    path.moveTo(points[0].x, points[0].y)
    for (i in 1 until points.size) {
        path.lineTo(points[i].x, points[i].y)
    }
    path.close()

    // Estimate Polygon Direction for Daylight Shading
    val p0 = poly.exteriorRing[0]
    val p1 = poly.exteriorRing.getOrElse(1) { p0 }
    val p2 = poly.exteriorRing.getOrElse(2) { p1 }

    val v1x = p1.x - p0.x
    val v1y = p1.y - p0.y
    val v1z = p1.z - p0.z

    val v2x = p2.x - p0.x
    val v2y = p2.y - p0.y
    val v2z = p2.z - p0.z

    var nx = v1y * v2z - v1z * v2y
    var ny = v1z * v2x - v1x * v2z
    var nz = v1x * v2y - v1y * v2x
    val len = Math.sqrt(nx * nx + ny * ny + nz * nz).coerceAtLeast(0.001)
    nx /= len
    ny /= len
    nz /= len

    val dotSun = (nx * 0.4 - ny * 0.5 + nz * 0.7)
    val lightFactor = (0.65 + 0.35 * dotSun.coerceIn(-1.0, 1.0)).toFloat()

    if (renderMode == RenderMode.REALITY_MESH || renderMode == RenderMode.HYBRID) {
        if (isSelected) {
            drawPath(path = path, color = highlightGold.copy(alpha = 0.88f))
            drawPath(path = path, color = highlightGold, style = Stroke(width = 3.5f))
        } else {
            when {
                // 1. Skywalk Bridges (Rellage / Messebrücken)
                feature.featureClass == Lod2FeatureClass.ELEVATED_BRIDGE -> {
                    val bridgeColor = when (poly.surfaceType) {
                        Lod2SurfaceType.ROOF -> Color(0xFF0284C7)
                        Lod2SurfaceType.WALL -> Color(0xFF38BDF8).copy(alpha = 0.85f)
                        else -> Color(0xFF0369A1)
                    }
                    val baseR = (bridgeColor.red * 255 * lightFactor).toInt().coerceIn(0, 255)
                    val baseG = (bridgeColor.green * 255 * lightFactor).toInt().coerceIn(0, 255)
                    val baseB = (bridgeColor.blue * 255 * lightFactor).toInt().coerceIn(0, 255)
                    drawPath(path = path, color = Color(baseR, baseG, baseB, (bridgeColor.alpha * 255).toInt()))
                    drawPath(path = path, color = Color.White, style = Stroke(width = 2.0f))
                }

                // 2. Canopies & Entrance Roofs
                feature.featureClass == Lod2FeatureClass.OVERHEAD_ROOF -> {
                    val canopyColor = Color(0xFF9333EA).copy(alpha = 0.70f)
                    drawPath(path = path, color = canopyColor)
                    drawPath(path = path, color = Color(0xFFC084FC), style = Stroke(width = 1.8f))
                }

                // 3. Exhibition Halls & Buildings (Koelnmesse Architectural Facades)
                else -> when (poly.surfaceType) {
                    Lod2SurfaceType.ROOF -> {
                        // Anthracite solar roof with daylight shading
                        val r = (30 * lightFactor + 180 * (1f - lightFactor)).toInt().coerceIn(0, 255)
                        val g = (41 * lightFactor + 190 * (1f - lightFactor)).toInt().coerceIn(0, 255)
                        val b = (59 * lightFactor + 210 * (1f - lightFactor)).toInt().coerceIn(0, 255)
                        drawPath(path = path, color = Color(r, g, b, 245))

                        // Skylight & Glass Atrium Ribbon
                        if (points.size >= 4) {
                            val atriumColor = Color(0xFF38BDF8).copy(alpha = 0.7f)
                            val pA = points[0]
                            val pB = points[1]
                            val pC = points[2]
                            val pD = points[3]
                            for (t in 1..3) {
                                val frac = t / 4f
                                val startX = pA.x + (pD.x - pA.x) * frac
                                val startY = pA.y + (pD.y - pA.y) * frac
                                val endX = pB.x + (pC.x - pB.x) * frac
                                val endY = pB.y + (pC.y - pB.y) * frac
                                drawLine(atriumColor, Offset(startX, startY), Offset(endX, endY), strokeWidth = 2.5f)
                            }
                        }

                        drawPath(path = path, color = Color(0xFF94A3B8), style = Stroke(width = 1.2f))
                    }

                    Lod2SurfaceType.WALL -> {
                        // Steel-Blue Glass Facade
                        val r = (30 * lightFactor + 120 * (1f - lightFactor)).toInt().coerceIn(0, 255)
                        val g = (58 * lightFactor + 140 * (1f - lightFactor)).toInt().coerceIn(0, 255)
                        val b = (138 * lightFactor + 180 * (1f - lightFactor)).toInt().coerceIn(0, 255)
                        drawPath(path = path, color = Color(r, g, b, 245))

                        // Horizontal Glass Floor Window Strip
                        if (points.size >= 4) {
                            val windowColor = Color(0xFF60A5FA).copy(alpha = 0.6f)
                            val pA = points[0]
                            val pB = points[1]
                            val pC = points[2]
                            val pD = points[3]
                            val mid1X = pA.x + (pB.x - pA.x) * 0.5f
                            val mid1Y = pA.y + (pB.y - pA.y) * 0.5f
                            val mid2X = pD.x + (pC.x - pD.x) * 0.5f
                            val mid2Y = pD.y + (pC.y - pD.y) * 0.5f
                            drawLine(windowColor, Offset(mid1X, mid1Y), Offset(mid2X, mid2Y), strokeWidth = 1.8f)
                        }

                        drawPath(path = path, color = Color(0xFF64748B), style = Stroke(width = 1.2f))
                    }

                    else -> {
                        val r = (100 * lightFactor).toInt().coerceIn(0, 255)
                        val g = (116 * lightFactor).toInt().coerceIn(0, 255)
                        val b = (139 * lightFactor).toInt().coerceIn(0, 255)
                        drawPath(path = path, color = Color(r, g, b, 220))
                        drawPath(path = path, color = Color(0xFF475569), style = Stroke(width = 1.2f))
                    }
                }
            }

            if (renderMode == RenderMode.HYBRID) {
                val overlayColor = when (poly.surfaceType) {
                    Lod2SurfaceType.ROOF -> Color(0xFF00E676)
                    Lod2SurfaceType.WALL -> Color(0xFF29B6F6)
                    else -> Color(0xFFFFD54F)
                }
                drawPath(path = path, color = overlayColor, style = Stroke(width = 2.0f))
            }
        }
    } else {
        // LOD2_DIAGNOSE Mode
        val (fillColor, strokeColor) = when {
            isSelected -> Pair(highlightGold.copy(alpha = 0.88f), highlightGold)

            feature.featureClass == Lod2FeatureClass.ELEVATED_BRIDGE -> when (poly.surfaceType) {
                Lod2SurfaceType.ROOF -> Pair(Color(0xFF0288D1).copy(alpha = 0.90f), Color(0xFF01579B))
                Lod2SurfaceType.OUTER_FLOOR -> Pair(Color(0xFF03A9F4).copy(alpha = 0.85f), Color(0xFF0288D1))
                else -> Pair(Color(0xFF0277BD).copy(alpha = 0.80f), Color(0xFF01579B))
            }

            feature.featureClass == Lod2FeatureClass.OVERHEAD_ROOF -> Pair(
                Color(0xFF8E24AA).copy(alpha = 0.60f), Color(0xFF4A148C)
            )

            else -> when (poly.surfaceType) {
                Lod2SurfaceType.ROOF -> Pair(Color(0xFF00897B).copy(alpha = 0.90f), Color(0xFF004D40))
                Lod2SurfaceType.WALL -> {
                    val dx = p1.x - p0.x
                    val dy = p1.y - p0.y
                    if (dx - dy > 0) Pair(Color(0xFF00695C).copy(alpha = 0.85f), Color(0xFF003333))
                    else Pair(Color(0xFF004D40).copy(alpha = 0.85f), Color(0xFF002222))
                }
                Lod2SurfaceType.GROUND -> Pair(Color(0xFF1C2D37).copy(alpha = 0.60f), Color(0xFF37474F))
                else -> Pair(Color(0xFF00796B).copy(alpha = 0.80f), Color(0xFF004D40))
            }
        }

        drawPath(path = path, color = fillColor)
        drawPath(path = path, color = strokeColor, style = Stroke(width = if (isSelected) 3.5f else 1.2f))
    }
}

private fun DrawScope.drawOsmWireframe(
    hall: OsmHallBoundary,
    originX: Double, originY: Double, originZ: Double,
    centerX: Float, centerY: Float, scale: Float
) {
    val path = Path()
    val points = hall.localPolygon2D.map { (lx, ly) ->
        project3D(originX + lx - 60.0, originY + ly - 60.0, originZ, originX, originY, originZ, centerX, centerY, scale)
    }

    if (points.isNotEmpty()) {
        path.moveTo(points[0].x, points[0].y)
        for (i in 1 until points.size) path.lineTo(points[i].x, points[i].y)
        path.close()

        drawPath(
            path = path,
            color = Color(0xFFFF5252),
            style = Stroke(width = 2.5f)
        )
    }
}

private fun DrawScope.drawWalkableHighlight(
    surface: WalkableSurface,
    originX: Double, originY: Double, originZ: Double,
    centerX: Float, centerY: Float, scale: Float
) {
    val path = Path()
    val points = surface.polygon3D.map { p ->
        project3D(p.x, p.y, p.z + 0.2, originX, originY, originZ, centerX, centerY, scale)
    }

    if (points.isNotEmpty()) {
        path.moveTo(points[0].x, points[0].y)
        for (i in 1 until points.size) path.lineTo(points[i].x, points[i].y)
        path.close()

        drawPath(
            path = path,
            color = Color(0xFF00C853).copy(alpha = 0.35f)
        )
        drawPath(
            path = path,
            color = Color(0xFF00E676),
            style = Stroke(width = 2f)
        )
    }
}

private fun DrawScope.draw3DStandBox(
    stand: ExhibitionStand,
    originX: Double, originY: Double, originZ: Double,
    centerX: Float, centerY: Float, scale: Float
) {
    val x = stand.worldX
    val y = stand.worldY
    val z = stand.worldZ + 0.5
    val dx = stand.width.coerceAtLeast(6.0)
    val dy = stand.depth.coerceAtLeast(6.0)
    val dz = 3.5

    val p1 = project3D(x - dx / 2, y - dy / 2, z, originX, originY, originZ, centerX, centerY, scale)
    val p2 = project3D(x + dx / 2, y - dy / 2, z, originX, originY, originZ, centerX, centerY, scale)
    val p3 = project3D(x + dx / 2, y + dy / 2, z, originX, originY, originZ, centerX, centerY, scale)
    val p4 = project3D(x - dx / 2, y + dy / 2, z, originX, originY, originZ, centerX, centerY, scale)

    val p1T = project3D(x - dx / 2, y - dy / 2, z + dz, originX, originY, originZ, centerX, centerY, scale)
    val p2T = project3D(x + dx / 2, y - dy / 2, z + dz, originX, originY, originZ, centerX, centerY, scale)
    val p3T = project3D(x + dx / 2, y + dy / 2, z + dz, originX, originY, originZ, centerX, centerY, scale)
    val p4T = project3D(x - dx / 2, y + dy / 2, z + dz, originX, originY, originZ, centerX, centerY, scale)

    val standColor = if (stand.isOutsideLod2Bounds) Color(0xFFFF5252) else Color(0xFFFFD700)

    // Roof of Stand
    val roofPath = Path().apply {
        moveTo(p1T.x, p1T.y)
        lineTo(p2T.x, p2T.y)
        lineTo(p3T.x, p3T.y)
        lineTo(p4T.x, p4T.y)
        close()
    }
    drawPath(roofPath, standColor.copy(alpha = 0.90f))
    drawPath(roofPath, Color.White, style = Stroke(width = 2f))

    // Walls of Stand
    val wallPath = Path().apply {
        moveTo(p1.x, p1.y)
        lineTo(p2.x, p2.y)
        lineTo(p2T.x, p2T.y)
        lineTo(p1T.x, p1T.y)
        close()
    }
    drawPath(wallPath, standColor.copy(alpha = 0.70f))
    drawPath(wallPath, Color.White, style = Stroke(width = 1.5f))

    // Stand Pin Circle on Top
    drawCircle(
        color = Color.White,
        radius = 8f * scale,
        center = p2T
    )
    drawCircle(
        color = standColor,
        radius = 6f * scale,
        center = p2T
    )
}

private fun DrawScope.drawPortalMarker(
    portal: PortalAnnotation,
    originX: Double, originY: Double, originZ: Double,
    centerX: Float, centerY: Float, scale: Float
) {
    val p = project3D(portal.position3D.x, portal.position3D.y, portal.position3D.z, originX, originY, originZ, centerX, centerY, scale)
    val color = if (portal.eventStatusOpen) Color(0xFF00C853) else Color(0xFFFF5252)

    drawCircle(color = Color.White, radius = 7f * scale, center = p)
    drawCircle(color = color, radius = 5f * scale, center = p)
}

private fun DrawScope.drawRoute3D(
    route: RouteResult,
    originX: Double, originY: Double, originZ: Double,
    centerX: Float, centerY: Float, scale: Float
) {
    val points = route.pathNodes.map { node ->
        project3D(node.position.x, node.position.y, node.position.z + 0.8, originX, originY, originZ, centerX, centerY, scale)
    }

    for (i in 0 until points.size - 1) {
        drawLine(
            color = Color(0xFFFFD700),
            start = points[i],
            end = points[i + 1],
            strokeWidth = 6f
        )
    }

    points.forEach { pt ->
        drawCircle(color = Color.White, radius = 8f * scale, center = pt)
        drawCircle(color = Color(0xFFFFD700), radius = 6f * scale, center = pt)
    }
}

private fun project3D(
    x: Double, y: Double, z: Double,
    originX: Double, originY: Double, originZ: Double,
    centerX: Float, centerY: Float, scale: Float
): Offset {
    val relX = x - originX
    val relY = y - originY
    val relZ = z - originZ

    val angleRad = Math.toRadians(30.0)
    val isoX = (relX - relY) * cos(angleRad)
    val isoY = (relX + relY) * sin(angleRad) - relZ * 1.6

    val px = (centerX + isoX * scale * 2.2).toFloat()
    val py = (centerY + isoY * scale * 2.2).toFloat()
    return Offset(px, py)
}

private fun DrawScope.drawAlkisParcels(
    parcels: List<AlkisParcel>,
    originX: Double, originY: Double, originZ: Double,
    centerX: Float, centerY: Float, scale: Float
) {
    parcels.forEach { parcel ->
        val path = Path()
        val points = parcel.polygonRing.map { p ->
            project3D(p.x, p.y, p.z + 0.1, originX, originY, originZ, centerX, centerY, scale)
        }
        if (points.isNotEmpty()) {
            path.moveTo(points[0].x, points[0].y)
            for (i in 1 until points.size) path.lineTo(points[i].x, points[i].y)
            path.close()

            drawPath(
                path = path,
                color = Color(0xFFFFB300).copy(alpha = 0.25f)
            )
            drawPath(
                path = path,
                color = Color(0xFFFF8F00),
                style = Stroke(width = 2.5f)
            )

            points.forEach { pt ->
                drawCircle(color = Color(0xFFFFD54F), radius = 3.5f * scale, center = pt)
            }
        }
    }
}

private fun DrawScope.drawOsmTransportLines(
    lines: List<OsmTransportLine>,
    originX: Double, originY: Double, originZ: Double,
    centerX: Float, centerY: Float, scale: Float
) {
    lines.forEach { line ->
        val points = line.coordinates.map { p ->
            project3D(p.x, p.y, p.z + 0.15, originX, originY, originZ, centerX, centerY, scale)
        }
        if (points.size >= 2) {
            val color = when (line.type) {
                TransportType.ROAD -> Color(0xFF546E7A)
                TransportType.RAIL_ICE -> Color(0xFFD32F2F)
                TransportType.TRAM_SUBWAY -> Color(0xFF0288D1)
                TransportType.PEDESTRIAN_BOULEVARD -> Color(0xFF8D6E63)
            }
            val strokeWidth = when (line.type) {
                TransportType.ROAD -> 8f * scale
                TransportType.RAIL_ICE -> 7f * scale
                TransportType.TRAM_SUBWAY -> 5f * scale
                TransportType.PEDESTRIAN_BOULEVARD -> 10f * scale
            }
            for (i in 0 until points.size - 1) {
                drawLine(
                    color = color,
                    start = points[i],
                    end = points[i + 1],
                    strokeWidth = strokeWidth
                )
            }
        }
    }
}

private fun DrawScope.drawOsmTransitStations(
    stations: List<OsmTransitStation>,
    originX: Double, originY: Double, originZ: Double,
    centerX: Float, centerY: Float, scale: Float
) {
    stations.forEach { st ->
        val p = project3D(st.position.x, st.position.y, st.position.z + 1.0, originX, originY, originZ, centerX, centerY, scale)
        drawCircle(color = Color.White, radius = 9f * scale, center = p)
        drawCircle(color = Color(0xFF1565C0), radius = 7f * scale, center = p)
        drawCircle(color = Color.White, radius = 3f * scale, center = p)
    }
}

private fun DrawScope.drawMesseEntranceGates(
    gates: List<MesseEntranceGate>,
    originX: Double, originY: Double, originZ: Double,
    centerX: Float, centerY: Float, scale: Float
) {
    gates.forEach { gate ->
        val p = project3D(gate.position.x, gate.position.y, gate.position.z + 1.2, originX, originY, originZ, centerX, centerY, scale)
        val gateColor = if (gate.isMainEntrance) Color(0xFF2E7D32) else Color(0xFF1565C0)

        val pBase = project3D(gate.position.x, gate.position.y, gate.position.z, originX, originY, originZ, centerX, centerY, scale)
        drawLine(color = gateColor, start = pBase, end = p, strokeWidth = 4f * scale)

        drawCircle(color = Color.White, radius = 10f * scale, center = p)
        drawCircle(color = gateColor, radius = 8f * scale, center = p)
    }
}

private fun DrawScope.drawIndoorFacilities(
    elevators: List<IndoorElevator>,
    escalators: List<IndoorEscalator>,
    originX: Double, originY: Double, originZ: Double,
    centerX: Float, centerY: Float, scale: Float
) {
    elevators.forEach { elev ->
        val p0 = project3D(elev.x, elev.y, 0.5, originX, originY, originZ, centerX, centerY, scale)
        val p1 = project3D(elev.x, elev.y, 8.0, originX, originY, originZ, centerX, centerY, scale)
        drawLine(color = Color(0xFF0288D1), start = p0, end = p1, strokeWidth = 5f * scale)
        drawCircle(color = Color.White, radius = 7f * scale, center = p1)
        drawCircle(color = Color(0xFF0288D1), radius = 5f * scale, center = p1)
    }

    escalators.forEach { esc ->
        val p0 = project3D(esc.x, esc.y, 0.2, originX, originY, originZ, centerX, centerY, scale)
        val p1 = project3D(esc.x + 10.0, esc.y + 10.0, 5.0, originX, originY, originZ, centerX, centerY, scale)
        drawLine(color = Color(0xFFE65100), start = p0, end = p1, strokeWidth = 4f * scale)
        drawCircle(color = Color(0xFFFFB74D), radius = 4f * scale, center = p0)
        drawCircle(color = Color(0xFFE65100), radius = 4f * scale, center = p1)
    }
}
