package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.model.AnchorPointPair
import com.example.repository.MesseRepository

@Composable
fun RegistrationScreen(repository: MesseRepository) {
    val anchorsMap by repository.anchors.collectAsState()
    val regResults by repository.registrationResults.collectAsState()
    val stands by repository.stands.collectAsState()

    val tealPrimary = Color(0xFF006A6A)
    val h1Anchors = anchorsMap["HALL_1"] ?: emptyList()
    val h1Result = regResults["HALL_1"]

    var newAnchorName by remember { mutableStateOf("") }
    var localXText by remember { mutableStateOf("60.0") }
    var localYText by remember { mutableStateOf("0.0") }
    var worldXText by remember { mutableStateOf("356260.0") }
    var worldYText by remember { mutableStateOf("5645100.0") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Text(
            text = "Portalanker & Hallen-Registrierung (Phase 4)",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = "Ausrichtung entkoppelter OSM-Pläne an amtlicher 3D-LoD2-Geometrie",
            style = MaterialTheme.typography.bodySmall,
            color = Color.Gray
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Matrix Result Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF161C1E))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "Transformationsmatrix (Halle 1)",
                    style = MaterialTheme.typography.titleSmall,
                    color = Color(0xFFFFD700),
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(8.dp))

                h1Result?.let { res ->
                    Text("• Translation TX: %.2fm, TY: %.2fm".format(res.tx, res.ty), color = Color.White, fontFamily = FontFamily.Monospace)
                    Text("• Rotation θ: %.3f°".format(Math.toDegrees(res.rotationRad)), color = Color.White, fontFamily = FontFamily.Monospace)
                    Text("• Fit-Typ: ${if (res.isLeastSquaresFit) "Least Squares (>= 3 Anker)" else "2-Punkt Starke Transformation"}", color = Color.White)
                    Text("• Mittlerer Restfehler (Residual): %.4fm".format(res.meanResidualError), color = Color(0xFF00C853), fontWeight = FontWeight.Bold)
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Spatial Constraint Warning Card
        val outOfBoundsStands = stands.filter { it.isOutsideLod2Bounds }
        if (outOfBoundsStands.isNotEmpty()) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFFFEBEE))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "⚠️ Spatial Constraint Warning (${outOfBoundsStands.size} Stände außerhalb LoD2)",
                        style = MaterialTheme.typography.titleSmall,
                        color = Color(0xFFD32F2F),
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    outOfBoundsStands.forEach { s ->
                        Text("• Stand ${s.standId} (${s.exhibitorName}) ragt über die amtliche Außenwand!", color = Color(0xFFB71C1C), style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
        }

        // Anchor Points List
        Text("Ankerpunkte (${h1Anchors.size})", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(8.dp))

        h1Anchors.forEach { a ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Row(
                    modifier = Modifier
                        .padding(12.dp)
                        .fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(a.name, fontWeight = FontWeight.Bold)
                        Text("Local: (%.1f, %.1f)".format(a.localX, a.localY), style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                        Text("World: (%.1f, %.1f)".format(a.worldX, a.worldY), style = MaterialTheme.typography.bodySmall, color = tealPrimary)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Add New Anchor Section
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color(0xFFF0F5F4))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Neuen Portalanker hinzufügen", fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = newAnchorName,
                    onValueChange = { newAnchorName = it },
                    label = { Text("Anker Name / Portal ID") },
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = localXText,
                        onValueChange = { localXText = it },
                        label = { Text("Local X") },
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = localYText,
                        onValueChange = { localYText = it },
                        label = { Text("Local Y") },
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = worldXText,
                        onValueChange = { worldXText = it },
                        label = { Text("World X (UTM)") },
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = worldYText,
                        onValueChange = { worldYText = it },
                        label = { Text("World Y (UTM)") },
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Button(
                    onClick = {
                        val name = newAnchorName.ifEmpty { "Anker ${h1Anchors.size + 1}" }
                        val lx = localXText.toDoubleOrNull() ?: 0.0
                        val ly = localYText.toDoubleOrNull() ?: 0.0
                        val wx = worldXText.toDoubleOrNull() ?: 356200.0
                        val wy = worldYText.toDoubleOrNull() ?: 5645100.0

                        val newA = AnchorPointPair(
                            id = "ANC_${System.currentTimeMillis()}",
                            name = name,
                            localX = lx, localY = ly,
                            worldX = wx, worldY = wy, worldZ = 42.0
                        )
                        repository.addAnchorPoint("HALL_1", newA)
                        newAnchorName = ""
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = tealPrimary)
                ) {
                    Text("Anker Speichern & Matrix Neu Berechnen")
                }
            }
        }
    }
}
