package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.model.RouteResult
import com.example.model.WalkableRole
import com.example.repository.MesseRepository
import com.example.ui.components.Viewport3D

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RoutingScreen(repository: MesseRepository) {
    val features by repository.lod2Features.collectAsState()
    val selectedFeature by repository.selectedFeature.collectAsState()
    val osmHalls by repository.osmHalls.collectAsState()
    val stands by repository.stands.collectAsState()
    val portals by repository.portals.collectAsState()
    val walkableSurfaces by repository.walkableSurfaces.collectAsState()

    var startStandId by remember { mutableStateOf("A010") }
    var endStandId by remember { mutableStateOf("B005") }
    var routeResult by remember { mutableStateOf<RouteResult?>(null) }

    var expandedStart by remember { mutableStateOf(false) }
    var expandedEnd by remember { mutableStateOf(false) }

    val tealPrimary = Color(0xFF006A6A)

    Column(modifier = Modifier.fillMaxSize()) {
        // Top Section: 3D Viewport with Walkable Surfaces and Route Highlighted
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
            Viewport3D(
                features = features,
                selectedFeature = selectedFeature,
                osmHalls = osmHalls,
                stands = stands,
                portals = portals,
                walkableSurfaces = walkableSurfaces,
                routeResult = routeResult,
                showOsmWireframe = false,
                showWalkableHighlights = true,
                showStands = true,
                filterClass = null,
                onSelectFeature = { repository.selectFeature(it) },
                modifier = Modifier.fillMaxSize()
            )
        }

        // Bottom Controls: Surface Annotation & Semantic Pathfinder
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.surface)
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            Text(
                text = "Begehbare Flächen & Semantisches Routing (Phase 5)",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Strict Routing Policy: Kein Routing auf flachen Orthofotos",
                style = MaterialTheme.typography.bodySmall,
                color = Color.Gray
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Stand Selector Row
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                // Start Stand Dropdown
                ExposedDropdownMenuBox(
                    expanded = expandedStart,
                    onExpandedChange = { expandedStart = it },
                    modifier = Modifier.weight(1f)
                ) {
                    OutlinedTextField(
                        value = "Start: $startStandId",
                        onValueChange = {},
                        readOnly = true,
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedStart) },
                        modifier = Modifier.menuAnchor(MenuAnchorType.PrimaryNotEditable)
                    )
                    ExposedDropdownMenu(
                        expanded = expandedStart,
                        onDismissRequest = { expandedStart = false }
                    ) {
                        stands.forEach { s ->
                            DropdownMenuItem(
                                text = { Text("${s.standId} (${s.exhibitorName})") },
                                onClick = {
                                    startStandId = s.standId
                                    expandedStart = false
                                }
                            )
                        }
                    }
                }

                // Target Stand Dropdown
                ExposedDropdownMenuBox(
                    expanded = expandedEnd,
                    onExpandedChange = { expandedEnd = it },
                    modifier = Modifier.weight(1f)
                ) {
                    OutlinedTextField(
                        value = "Ziel: $endStandId",
                        onValueChange = {},
                        readOnly = true,
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedEnd) },
                        modifier = Modifier.menuAnchor(MenuAnchorType.PrimaryNotEditable)
                    )
                    ExposedDropdownMenu(
                        expanded = expandedEnd,
                        onDismissRequest = { expandedEnd = false }
                    ) {
                        stands.forEach { s ->
                            DropdownMenuItem(
                                text = { Text("${s.standId} (${s.exhibitorName})") },
                                onClick = {
                                    endStandId = s.standId
                                    expandedEnd = false
                                }
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Button(
                onClick = {
                    routeResult = repository.calculateSemanticRoute(startStandId, endStandId)
                },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = tealPrimary),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("Barrierefreie 3D-Route Berechnen")
            }

            // Route Breakdown
            routeResult?.let { res ->
                Spacer(modifier = Modifier.height(12.dp))
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFCCE8E8))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = "Berechnete Route (Strecke: %.1fm)".format(res.totalDistanceMeters),
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF002020)
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        res.instructions.forEachIndexed { idx, step ->
                            Text("${idx + 1}. $step", style = MaterialTheme.typography.bodySmall, color = Color(0xFF002020))
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Event Portal Status Toggles
            Text("Portal Status (Event-Steuerung)", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(6.dp))

            portals.forEach { p ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFF0F5F4))
                ) {
                    Row(
                        modifier = Modifier
                            .padding(12.dp)
                            .fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(p.name, fontWeight = FontWeight.Bold)
                            Text("Ebene: ${p.level.label} • Typ: ${p.edgeType.label}", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = if (p.eventStatusOpen) "OFFEN" else "GESCHLOSSEN",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = if (p.eventStatusOpen) Color(0xFF00C853) else Color(0xFFFF5252)
                            )
                            Switch(
                                checked = p.eventStatusOpen,
                                onCheckedChange = { repository.togglePortalEventStatus(p.portalId) },
                                colors = SwitchDefaults.colors(checkedThumbColor = Color(0xFF00C853))
                            )
                        }
                    }
                }
            }
        }
    }
}
