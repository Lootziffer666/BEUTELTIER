package com.example.ui.screens

import android.content.Context
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.FileUpload
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.model.Lod2SurfaceType
import com.example.repository.MesseRepository
import kotlinx.coroutines.launch

@Composable
fun InventoryScreen(repository: MesseRepository) {
    val summary by repository.inventorySummary.collectAsState()
    var selectedTab by remember { mutableIntStateOf(0) }
    var isLoadingWfs by remember { mutableStateOf(false) }

    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val tealPrimary = Color(0xFF006A6A)

    // SAF File Picker Launcher for complete user GML, GeoJSON, and IFC files
    val filePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let { fileUri ->
            try {
                val content = context.contentResolver.openInputStream(fileUri)?.use { stream ->
                    stream.bufferedReader().readText()
                }
                if (!content.isNullOrEmpty()) {
                    val trimmed = content.trim()
                    when {
                        trimmed.startsWith("{") -> {
                            repository.parseGeoJson(content)
                            Toast.makeText(context, "GeoJSON erfolgreich geladen!", Toast.LENGTH_SHORT).show()
                        }
                        trimmed.contains("ISO-10303") || trimmed.contains("IFCWALL") || trimmed.contains("IFCSLAB") || trimmed.contains("HEADER;") -> {
                            repository.parseIfc(content)
                            Toast.makeText(context, "IFC / BIM Modell erfolgreich geladen!", Toast.LENGTH_SHORT).show()
                        }
                        else -> {
                            repository.parseCustomGml(content)
                            Toast.makeText(context, "CityGML erfolgreich geladen!", Toast.LENGTH_SHORT).show()
                        }
                    }
                } else {
                    Toast.makeText(context, "Datei war leer", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Toast.makeText(context, "Fehler beim Lesen: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        TabRow(
            selectedTabIndex = selectedTab,
            containerColor = MaterialTheme.colorScheme.surface,
            contentColor = tealPrimary
        ) {
            Tab(selected = selectedTab == 0, onClick = { selectedTab = 0 }, text = { Text("Inventar-Katalog") })
            Tab(selected = selectedTab == 1, onClick = { selectedTab = 1 }, text = { Text("JSON Output") })
            Tab(selected = selectedTab == 2, onClick = { selectedTab = 2 }, text = { Text("Markdown Bericht") })
        }

        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            when (selectedTab) {
                0 -> {
                    // Direct Action Controls for Real GML / WFS
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text(
                                text = "Multi-Format Geodaten Import (CityGML, GeoJSON, IFC / BIM)",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = tealPrimary
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "Importiere deine echten Geodaten & BIM-Modelle (.gml, .xml, .geojson, .ifc) direkt vom Gerät oder lade Live-Daten vom Geobasis NRW WFS 2.0 Server.",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color.Gray
                            )
                            Spacer(modifier = Modifier.height(12.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Button(
                                    onClick = { filePickerLauncher.launch("*/*") },
                                    modifier = Modifier.weight(1f),
                                    colors = ButtonDefaults.buttonColors(containerColor = tealPrimary)
                                ) {
                                    Icon(Icons.Default.FileUpload, contentDescription = null)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Datei Laden (GML/GeoJSON/IFC)", style = MaterialTheme.typography.labelMedium)
                                }

                                OutlinedButton(
                                    onClick = {
                                        scope.launch {
                                            isLoadingWfs = true
                                            val res = repository.fetchLiveWfsGeobasisNrw()
                                            isLoadingWfs = false
                                            res.onSuccess { count ->
                                                Toast.makeText(context, "Geobasis NRW WFS: $count Features geladen", Toast.LENGTH_SHORT).show()
                                            }.onFailure { err ->
                                                Toast.makeText(context, "WFS Server: ${err.message}", Toast.LENGTH_LONG).show()
                                            }
                                        }
                                    },
                                    modifier = Modifier.weight(1f),
                                    enabled = !isLoadingWfs
                                ) {
                                    if (isLoadingWfs) {
                                        CircularProgressIndicator(modifier = Modifier.height(18.dp).width(18.dp), strokeWidth = 2.dp)
                                    } else {
                                        Icon(Icons.Default.CloudDownload, contentDescription = null)
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Geobasis WFS", style = MaterialTheme.typography.labelMedium)
                                    }
                                }
                            }
                        }
                    }

                    summary?.let { s ->
                        Text("dz.nrw LoD2 Inventar-Analyse", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text("Vollständige Erfassung aller amtlichen CityGML Features", style = MaterialTheme.typography.bodySmall, color = Color.Gray)

                        Spacer(modifier = Modifier.height(16.dp))

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Card(
                                modifier = Modifier.weight(1f),
                                colors = CardDefaults.cardColors(containerColor = Color(0xFFCCE8E8))
                            ) {
                                Column(modifier = Modifier.padding(14.dp)) {
                                    Text("Gesamt Features", style = MaterialTheme.typography.labelSmall, color = Color(0xFF002020))
                                    Text("${s.totalFeatures}", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold, color = tealPrimary)
                                }
                            }

                            Card(
                                modifier = Modifier.weight(1f),
                                colors = CardDefaults.cardColors(containerColor = Color(0xFFF0F5F4))
                            ) {
                                Column(modifier = Modifier.padding(14.dp)) {
                                    Text("Ohne GroundSurface", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                                    Text("${s.featuresWithoutGroundSurfaceCount}", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
                                    Text("Verlustfrei erhalten!", style = MaterialTheme.typography.labelSmall, color = tealPrimary)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text("Feature-Klassen Breakdown", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                                Spacer(modifier = Modifier.height(8.dp))
                                Text("• bldg:Building: ${s.buildingCount}")
                                Text("• bldg:BuildingPart: ${s.buildingPartCount}")
                                Text("• Überdachungen / Canopy: ${s.roofCount}")
                                Text("• Brücken / Verbindungskörper: ${s.bridgeCount}")
                                Text("• Aufgeständerte Bauwerke: ${s.elevatedStructureCount}")
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text("Oberflächen-Katalog", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                                Spacer(modifier = Modifier.height(8.dp))
                                s.surfaceCounts.forEach { (type, count) ->
                                    Text("• ${type.displayName}: $count Surfaces")
                                }
                            }
                        }
                    }
                }

                1 -> {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF161C1E))
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                text = "data/build/lod2-inventory.json",
                                style = MaterialTheme.typography.labelMedium,
                                color = Color(0xFFFFD700),
                                fontFamily = FontFamily.Monospace
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = repository.generateLod2InventoryJson(),
                                style = MaterialTheme.typography.bodySmall,
                                color = Color.White,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }

                2 -> {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                text = repository.generateMarkdownReport(),
                                style = MaterialTheme.typography.bodyMedium,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }
        }
    }
}
