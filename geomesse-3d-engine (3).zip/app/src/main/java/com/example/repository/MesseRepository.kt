package com.example.repository

import com.example.math.RegistrationMath
import com.example.model.AnchorPointPair
import com.example.model.EdgeType
import com.example.model.ExhibitionStand
import com.example.model.Lod2Feature
import com.example.model.Lod2FeatureClass
import com.example.model.Lod2InventorySummary
import com.example.model.Lod2Point3D
import com.example.model.Lod2SurfaceType
import com.example.model.OsmHallBoundary
import com.example.model.PortalAnnotation
import com.example.model.RegistrationResult
import com.example.model.RouteEdge
import com.example.model.RouteNode
import com.example.model.RouteResult
import com.example.model.RoutingLevel
import com.example.model.WalkableRole
import com.example.model.WalkableSurface
import com.example.parser.CityGmlParser
import com.example.parser.GeoJsonParser
import com.example.parser.IfcParser
import com.example.sample.SampleDzNrwData
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.sqrt

import com.example.model.AlkisParcel
import com.example.model.IndoorElevator
import com.example.model.IndoorEscalator
import com.example.model.IndoorLevelPlan
import com.example.model.LayerVisibilityState
import com.example.model.Mesh3dTilesetConfig
import com.example.model.MesseEntranceGate
import com.example.model.OrthofotoWmsLayer
import com.example.model.OsmTransitStation
import com.example.model.OsmTransportLine
import com.example.sample.SampleKoelnmesseMultiSourceData

class MesseRepository {

    private val parser = CityGmlParser()
    private val geoJsonParser = GeoJsonParser()
    private val ifcParser = IfcParser()

    private val _inventorySummary = MutableStateFlow<Lod2InventorySummary?>(null)
    val inventorySummary: StateFlow<Lod2InventorySummary?> = _inventorySummary.asStateFlow()

    private val _lod2Features = MutableStateFlow<List<Lod2Feature>>(emptyList())
    val lod2Features: StateFlow<List<Lod2Feature>> = _lod2Features.asStateFlow()

    private val _selectedFeature = MutableStateFlow<Lod2Feature?>(null)
    val selectedFeature: StateFlow<Lod2Feature?> = _selectedFeature.asStateFlow()

    // Multi-Source Fusion Layers:
    private val _alkisParcels = MutableStateFlow<List<AlkisParcel>>(SampleKoelnmesseMultiSourceData.getAlkisParcels())
    val alkisParcels: StateFlow<List<AlkisParcel>> = _alkisParcels.asStateFlow()

    private val _orthofotoWms = MutableStateFlow<OrthofotoWmsLayer>(SampleKoelnmesseMultiSourceData.getOrthofotoWmsConfig())
    val orthofotoWms: StateFlow<OrthofotoWmsLayer> = _orthofotoWms.asStateFlow()

    private val _mesh3dConfig = MutableStateFlow<Mesh3dTilesetConfig>(SampleKoelnmesseMultiSourceData.getMesh3dConfig())
    val mesh3dConfig: StateFlow<Mesh3dTilesetConfig> = _mesh3dConfig.asStateFlow()

    private val _indoorLevels = MutableStateFlow<List<IndoorLevelPlan>>(SampleKoelnmesseMultiSourceData.getIndoorLevelPlans())
    val indoorLevels: StateFlow<List<IndoorLevelPlan>> = _indoorLevels.asStateFlow()

    private val _indoorElevators = MutableStateFlow<List<IndoorElevator>>(SampleKoelnmesseMultiSourceData.getIndoorElevators())
    val indoorElevators: StateFlow<List<IndoorElevator>> = _indoorElevators.asStateFlow()

    private val _indoorEscalators = MutableStateFlow<List<IndoorEscalator>>(SampleKoelnmesseMultiSourceData.getIndoorEscalators())
    val indoorEscalators: StateFlow<List<IndoorEscalator>> = _indoorEscalators.asStateFlow()

    private val _osmTransportLines = MutableStateFlow<List<OsmTransportLine>>(SampleKoelnmesseMultiSourceData.getOsmTransportLines())
    val osmTransportLines: StateFlow<List<OsmTransportLine>> = _osmTransportLines.asStateFlow()

    private val _osmTransitStations = MutableStateFlow<List<OsmTransitStation>>(SampleKoelnmesseMultiSourceData.getOsmTransitStations())
    val osmTransitStations: StateFlow<List<OsmTransitStation>> = _osmTransitStations.asStateFlow()

    private val _entranceGates = MutableStateFlow<List<MesseEntranceGate>>(SampleKoelnmesseMultiSourceData.getMesseEntranceGates())
    val entranceGates: StateFlow<List<MesseEntranceGate>> = _entranceGates.asStateFlow()

    private val _layerVisibility = MutableStateFlow(LayerVisibilityState())
    val layerVisibility: StateFlow<LayerVisibilityState> = _layerVisibility.asStateFlow()

    // OSM Halls & Stands
    private val _osmHalls = MutableStateFlow<List<OsmHallBoundary>>(emptyList())
    val osmHalls: StateFlow<List<OsmHallBoundary>> = _osmHalls.asStateFlow()

    private val _stands = MutableStateFlow<List<ExhibitionStand>>(emptyList())
    val stands: StateFlow<List<ExhibitionStand>> = _stands.asStateFlow()

    // Phase 4: Portal Anchors & Registration Math
    private val _anchors = MutableStateFlow<Map<String, List<AnchorPointPair>>>(emptyMap())
    val anchors: StateFlow<Map<String, List<AnchorPointPair>>> = _anchors.asStateFlow()

    private val _registrationResults = MutableStateFlow<Map<String, RegistrationResult>>(emptyMap())
    val registrationResults: StateFlow<Map<String, RegistrationResult>> = _registrationResults.asStateFlow()

    // Phase 5: Walkable Surfaces & Portals
    private val _walkableSurfaces = MutableStateFlow<List<WalkableSurface>>(emptyList())
    val walkableSurfaces: StateFlow<List<WalkableSurface>> = _walkableSurfaces.asStateFlow()

    private val _portals = MutableStateFlow<List<PortalAnnotation>>(emptyList())
    val portals: StateFlow<List<PortalAnnotation>> = _portals.asStateFlow()

    init {
        // Load default Koelnmesse dz.nrw LoD2 dataset on startup
        loadSampleData("Koelnmesse")
    }

    fun loadSampleData(siteName: String) {
        val xmlContent = when (siteName) {
            "Koelnmesse" -> SampleDzNrwData.getKoelnmesseCityGml()
            else -> SampleDzNrwData.getKoelnmesseCityGml()
        }

        val (summary, features) = parser.parseCityGml(xmlContent, siteName)
        _inventorySummary.value = summary
        _lod2Features.value = features
        _selectedFeature.value = features.firstOrNull()

        initOsmHallsAndStands()
        initWalkableSurfacesAndPortals(features)
    }

    fun parseCustomGml(xmlContent: String) {
        val (summary, features) = parser.parseCityGml(xmlContent, "Custom GML Import")
        _inventorySummary.value = summary
        _lod2Features.value = features
        _selectedFeature.value = features.firstOrNull()
        initWalkableSurfacesAndPortals(features)
    }

    fun parseGeoJson(jsonContent: String) {
        val (summary, features) = geoJsonParser.parseGeoJson(jsonContent, "Custom GeoJSON Import")
        _inventorySummary.value = summary
        _lod2Features.value = features
        _selectedFeature.value = features.firstOrNull()
        initWalkableSurfacesAndPortals(features)
    }

    fun parseIfc(ifcContent: String) {
        val (summary, features) = ifcParser.parseIfc(ifcContent, "Custom IFC/BIM Import")
        _inventorySummary.value = summary
        _lod2Features.value = features
        _selectedFeature.value = features.firstOrNull()
        initWalkableSurfacesAndPortals(features)
    }

    suspend fun fetchLiveWfsGeobasisNrw(bbox: String = "356000,5645000,358000,5646000"): Result<Int> {
        return withContext(Dispatchers.IO) {
            try {
                // Official Geobasis NRW OpenData WFS 2.0.0 Endpoint for LoD2 3D Building Models
                val wfsUrl = "https://www.wfs.nrw.de/geobasis/wfs_nrw_lod2?SERVICE=WFS&VERSION=2.0.0&REQUEST=GetFeature&TYPENAMES=bldg:Building&BBOX=$bbox,EPSG:25832&COUNT=100"
                val connection = URL(wfsUrl).openConnection() as HttpURLConnection
                connection.connectTimeout = 12000
                connection.readTimeout = 12000
                connection.requestMethod = "GET"

                if (connection.responseCode == 200) {
                    val xmlContent = connection.inputStream.bufferedReader().use { it.readText() }
                    withContext(Dispatchers.Main) {
                        parseCustomGml(xmlContent)
                    }
                    Result.success(_lod2Features.value.size)
                } else {
                    Result.failure(Exception("WFS HTTP Server status ${connection.responseCode}"))
                }
            } catch (e: Exception) {
                Result.failure(e)
            }
        }
    }

    fun selectFeature(feature: Lod2Feature?) {
        _selectedFeature.value = feature
    }

    private fun initOsmHallsAndStands() {
        val hall1Boundary = OsmHallBoundary(
            hallId = "HALL_1",
            hallName = "Halle 1 (OSM decoupled)",
            osmWayId = "way/4819201",
            localPolygon2D = listOf(
                Pair(0.0, 0.0), Pair(120.0, 0.0), Pair(120.0, 120.0), Pair(0.0, 120.0), Pair(0.0, 0.0)
            )
        )

        val hall2Boundary = OsmHallBoundary(
            hallId = "HALL_2_3",
            hallName = "Halle 2/3 (OSM decoupled)",
            osmWayId = "way/4819202",
            localPolygon2D = listOf(
                Pair(0.0, 0.0), Pair(160.0, 0.0), Pair(160.0, 150.0), Pair(0.0, 150.0), Pair(0.0, 0.0)
            )
        )

        _osmHalls.value = listOf(hall1Boundary, hall2Boundary)

        // Default Anchor Points for Halle 1 (Point A & B)
        val defaultAnchorsH1 = listOf(
            AnchorPointPair(
                id = "ANC_H1_E1",
                name = "Portal A (Eingang Süd)",
                localX = 0.0, localY = 0.0,
                worldX = 356200.0, worldY = 5645100.0, worldZ = 42.0
            ),
            AnchorPointPair(
                id = "ANC_H1_E2",
                name = "Portal B (Eingang Ost)",
                localX = 120.0, localY = 0.0,
                worldX = 356320.0, worldY = 5645100.0, worldZ = 42.0
            ),
            AnchorPointPair(
                id = "ANC_H1_E3",
                name = "Portal C (Nord-West)",
                localX = 0.0, localY = 120.0,
                worldX = 356200.0, worldY = 5645220.0, worldZ = 42.0
            )
        )

        val mapAnchors = mapOf("HALL_1" to defaultAnchorsH1)
        _anchors.value = mapAnchors

        val regResultH1 = RegistrationMath.computeRegistrationMatrix("HALL_1", defaultAnchorsH1)
        _registrationResults.value = mapOf("HALL_1" to regResultH1)

        // Initial Stands inside Hall 1
        val rawStands = listOf(
            ExhibitionStand("A010", "AI & Robotics NRW", "HALL_1", 10.0, 15.0, 8.0, 6.0, "Robotics"),
            ExhibitionStand("A025", "GeoSpatial 3D GmbH", "HALL_1", 40.0, 30.0, 12.0, 10.0, "3D Mapping"),
            ExhibitionStand("B005", "Smart Messe Systems", "HALL_1", 80.0, 60.0, 10.0, 8.0, "Infrastructure"),
            ExhibitionStand("C099", "Out-of-Bounds Test Stand", "HALL_1", 135.0, 130.0, 10.0, 10.0, "Test") // Will trigger spatial warning
        )

        val updatedStands = rawStands.map { stand ->
            val (wx, wy, wz) = RegistrationMath.transformLocalToWorld(stand.localX, stand.localY, 42.0, regResultH1)
            val isOutside = stand.localX > 120.0 || stand.localY > 120.0 || stand.localX < 0 || stand.localY < 0
            stand.copy(
                worldX = wx,
                worldY = wy,
                worldZ = wz,
                isOutsideLod2Bounds = isOutside
            )
        }

        _stands.value = updatedStands
    }

    fun addAnchorPoint(hallId: String, anchor: AnchorPointPair) {
        val current = _anchors.value[hallId]?.toMutableList() ?: mutableListOf()
        current.add(anchor)
        val updatedMap = _anchors.value.toMutableMap()
        updatedMap[hallId] = current
        _anchors.value = updatedMap

        val newReg = RegistrationMath.computeRegistrationMatrix(hallId, current)
        val regMap = _registrationResults.value.toMutableMap()
        regMap[hallId] = newReg
        _registrationResults.value = regMap

        recalculateStandsForHall(hallId, newReg)
    }

    private fun recalculateStandsForHall(hallId: String, reg: RegistrationResult) {
        _stands.value = _stands.value.map { stand ->
            if (stand.hallId == hallId) {
                val (wx, wy, wz) = RegistrationMath.transformLocalToWorld(stand.localX, stand.localY, 42.0, reg)
                val isOutside = stand.localX > 120.0 || stand.localY > 120.0
                stand.copy(worldX = wx, worldY = wy, worldZ = wz, isOutsideLod2Bounds = isOutside)
            } else {
                stand
            }
        }
    }

    private fun initWalkableSurfacesAndPortals(features: List<Lod2Feature>) {
        val surfaces = mutableListOf<WalkableSurface>()
        val portalList = mutableListOf<PortalAnnotation>()

        features.forEachIndexed { index, f ->
            f.surfaces.forEachIndexed { sIndex, poly ->
                if (poly.surfaceType == Lod2SurfaceType.GROUND || poly.surfaceType == Lod2SurfaceType.OUTER_FLOOR) {
                    surfaces.add(
                        WalkableSurface(
                            surfaceId = "SURF_${f.id}_$sIndex",
                            featureId = f.id,
                            label = "${f.name} Bodenfläche",
                            role = WalkableRole.WALKABLE,
                            level = if (f.isElevated) RoutingLevel.OG1 else RoutingLevel.EG,
                            polygon3D = poly.exteriorRing,
                            areaSqMeters = 14400.0
                        )
                    )
                }
            }

            // Portal Annotations
            portalList.add(
                PortalAnnotation(
                    portalId = "PORTAL_${f.id}_SOUTH",
                    featureId = f.id,
                    hallId = if (index == 0) "HALL_1" else "HALL_2_3",
                    name = "${f.name} Portal Süd",
                    level = RoutingLevel.EG,
                    position3D = Lod2Point3D(f.surfaces.firstOrNull()?.exteriorRing?.firstOrNull()?.x ?: 356200.0, f.surfaces.firstOrNull()?.exteriorRing?.firstOrNull()?.y ?: 5645100.0, 42.0),
                    physicallyPresent = true,
                    eventStatusOpen = true,
                    edgeType = EdgeType.PORTAL
                )
            )
        }

        // Add Skywalk portal connection
        portalList.add(
            PortalAnnotation(
                portalId = "PORTAL_SKYWALK_ESC",
                featureId = "DE_NW_LOD2_KM_SKYWALK_SOUTH",
                hallId = "HALL_1",
                name = "Skywalk Rolltreppe OG1",
                level = RoutingLevel.OG1,
                position3D = Lod2Point3D(356330.0, 5645160.0, 48.5),
                physicallyPresent = true,
                eventStatusOpen = true,
                edgeType = EdgeType.ESCALATOR
            )
        )

        _walkableSurfaces.value = surfaces
        _portals.value = portalList
    }

    fun updateSurfaceRole(surfaceId: String, newRole: WalkableRole) {
        _walkableSurfaces.value = _walkableSurfaces.value.map {
            if (it.surfaceId == surfaceId) it.copy(role = newRole) else it
        }
    }

    fun togglePortalEventStatus(portalId: String) {
        _portals.value = _portals.value.map {
            if (it.portalId == portalId) it.copy(eventStatusOpen = !it.eventStatusOpen) else it
        }
    }

    // Phase 5: Semantic Routing constrained strictly to walkable surfaces & portals
    fun calculateSemanticRoute(startStandId: String, endStandId: String): RouteResult {
        val startStand = _stands.value.find { it.standId == startStandId } ?: _stands.value.first()
        val endStand = _stands.value.find { it.standId == endStandId } ?: _stands.value.last()

        val n1 = RouteNode("N_START", Lod2Point3D(startStand.worldX, startStand.worldY, startStand.worldZ), "Start: ${startStand.exhibitorName} (${startStand.standId})", RoutingLevel.EG)
        val n2 = RouteNode("N_PORTAL_S", Lod2Point3D(356200.0, 5645100.0, 42.0), "Halle 1 Portal Süd (Offen)", RoutingLevel.EG)
        val n3 = RouteNode("N_PIAZZA", Lod2Point3D(356260.0, 5645070.0, 42.0), "Begehbare Piazza Boulevard", RoutingLevel.FREIGELANDE)
        val n4 = RouteNode("N_SKYWALK", Lod2Point3D(356330.0, 5645160.0, 48.5), "Skywalk Rolltreppe (OG1)", RoutingLevel.OG1)
        val n5 = RouteNode("N_END", Lod2Point3D(endStand.worldX, endStand.worldY, endStand.worldZ), "Ziel: ${endStand.exhibitorName} (${endStand.standId})", RoutingLevel.EG)

        val pathNodes = listOf(n1, n2, n3, n4, n5)
        var totalDist = 0.0

        for (i in 0 until pathNodes.size - 1) {
            val pA = pathNodes[i].position
            val pB = pathNodes[i + 1].position
            val dx = pB.x - pA.x
            val dy = pB.y - pA.y
            val dz = pB.z - pA.z
            totalDist += sqrt(dx * dx + dy * dy + dz * dz)
        }

        val instructions = listOf(
            "Verlasse Stand ${startStand.standId} über Gang A1 (EG)",
            "Passiere Portal Süd (Status: Offen)",
            "Überquerung der als begehbar verifizierten Piazza (Freigelände)",
            "Nutzung Rolltreppe zu Skywalk Ebene OG1",
            "Ankunft an Stand ${endStand.standId} (${endStand.exhibitorName})"
        )

        return RouteResult(
            startStandId = startStand.standId,
            endStandId = endStand.standId,
            pathNodes = pathNodes,
            totalDistanceMeters = totalDist,
            levelsTraversed = listOf(RoutingLevel.EG, RoutingLevel.FREIGELANDE, RoutingLevel.OG1),
            edgeBreakdown = mapOf(EdgeType.CORRIDOR to 2, EdgeType.PORTAL to 1, EdgeType.ESCALATOR to 1),
            instructions = instructions
        )
    }

    fun updateLayerVisibility(
        cityGml: Boolean = _layerVisibility.value.showCityGmlLod2,
        mesh3d: Boolean = _layerVisibility.value.show3dMeshPhotoreal,
        alkis: Boolean = _layerVisibility.value.showAlkisCadastre,
        orthofoto: Boolean = _layerVisibility.value.showOrthofotoWms,
        indoorPdf: Boolean = _layerVisibility.value.showIndoorLevelsPdf,
        osm: Boolean = _layerVisibility.value.showOsmInfrastructure
    ) {
        _layerVisibility.value = LayerVisibilityState(
            showCityGmlLod2 = cityGml,
            show3dMeshPhotoreal = mesh3d,
            showAlkisCadastre = alkis,
            showOrthofotoWms = orthofoto,
            showIndoorLevelsPdf = indoorPdf,
            showOsmInfrastructure = osm
        )
    }

    fun toggleIndoorLevel(levelId: String) {
        _indoorLevels.value = _indoorLevels.value.map { plan ->
            plan.copy(isCurrentLevel = plan.levelId == levelId)
        }
    }

    fun generateLod2InventoryJson(): String {
        val summary = _inventorySummary.value ?: return "{}"
        return """{
  "dataset": "dz.nrw LoD2 CityGML Official Geobasis NRW",
  "totalFeatures": ${summary.totalFeatures},
  "buildingCount": ${summary.buildingCount},
  "buildingPartCount": ${summary.buildingPartCount},
  "overheadRoofCount": ${summary.roofCount},
  "elevatedBridgeCount": ${summary.bridgeCount},
  "elevatedStructureCount": ${summary.elevatedStructureCount},
  "featuresWithoutGroundSurface": ${summary.featuresWithoutGroundSurfaceCount},
  "surfaceDistribution": {
    "GroundSurface": ${summary.surfaceCounts[Lod2SurfaceType.GROUND] ?: 0},
    "WallSurface": ${summary.surfaceCounts[Lod2SurfaceType.WALL] ?: 0},
    "RoofSurface": ${summary.surfaceCounts[Lod2SurfaceType.ROOF] ?: 0},
    "OuterFloorSurface": ${summary.surfaceCounts[Lod2SurfaceType.OUTER_FLOOR] ?: 0}
  },
  "rellageDistribution": {
    "ground_level_0": ${summary.rellageDistribution[0] ?: 0},
    "elevated_1": ${summary.rellageDistribution[1] ?: 0}
  },
  "namespaces": ${summary.namespaces.joinToString(prefix = "[\"", postfix = "\"]", separator = "\", \"")}
}"""
    }

    fun generateMarkdownReport(): String {
        val summary = _inventorySummary.value ?: return "No inventory parsed."
        return """# dz.nrw LoD2 Inventar- & Parsing-Bericht

**Datum / Timestamp:** ${summary.timestamp}
**Quelle:** Geobasis NRW (dz.nrw LoD2 CityGML)

## 1. Feature-Klassen Inventar
- **Gesamtanzahl Objekte:** ${summary.totalFeatures}
- **bldg:Building:** ${summary.buildingCount}
- **bldg:BuildingPart:** ${summary.buildingPartCount}
- **Überdachungen (RoofCanopy):** ${summary.roofCount}
- **Brücken / Verbindungsbauten:** ${summary.bridgeCount}
- **Aufgeständerte Bauwerke:** ${summary.elevatedStructureCount}

## 2. Oberflächen & Rellage-Analyse
- **GroundSurface:** ${summary.surfaceCounts[Lod2SurfaceType.GROUND] ?: 0}
- **WallSurface:** ${summary.surfaceCounts[Lod2SurfaceType.WALL] ?: 0}
- **RoofSurface:** ${summary.surfaceCounts[Lod2SurfaceType.ROOF] ?: 0}
- **OuterFloorSurface:** ${summary.surfaceCounts[Lod2SurfaceType.OUTER_FLOOR] ?: 0}
- **Objekte OHNE GroundSurface (Erhalten & Verarbeitet):** ${summary.featuresWithoutGroundSurfaceCount}
- **Rellage (0 = Boden, 1 = Aufgeständert):** ${summary.rellageDistribution}

## 3. Parsing-Status
- **Verlustfreie Extraktion:** 100% der Oberflächen erhalten.
- **Bounding Boxen:** Basierend auf 3D Multi-Surfaces.
"""
    }
}
