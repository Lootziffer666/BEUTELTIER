package com.example.math

import com.example.model.AnchorPointPair
import com.example.model.RegistrationResult
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

object RegistrationMath {

    fun computeRegistrationMatrix(
        hallId: String,
        anchors: List<AnchorPointPair>
    ): RegistrationResult {
        if (anchors.size < 2) {
            return RegistrationResult(
                hallId = hallId,
                tx = 0.0,
                ty = 0.0,
                rotationRad = 0.0,
                isValid = false,
                meanResidualError = 0.0
            )
        }

        if (anchors.size == 2) {
            val a1 = anchors[0]
            val a2 = anchors[1]

            val dxLocal = a2.localX - a1.localX
            val dyLocal = a2.localY - a1.localY
            val angleLocal = atan2(dyLocal, dxLocal)

            val dxWorld = a2.worldX - a1.worldX
            val dyWorld = a2.worldY - a1.worldY
            val angleWorld = atan2(dyWorld, dxWorld)

            val rot = angleWorld - angleLocal

            // World = R * Local + T
            val tx = a1.worldX - (a1.localX * cos(rot) - a1.localY * sin(rot))
            val ty = a1.worldY - (a1.localX * sin(rot) + a1.localY * cos(rot))

            val res1 = calculateResidual(a1, tx, ty, rot)
            val res2 = calculateResidual(a2, tx, ty, rot)

            return RegistrationResult(
                hallId = hallId,
                tx = tx,
                ty = ty,
                rotationRad = rot,
                residuals = listOf(res1, res2),
                meanResidualError = (res1 + res2) / 2.0,
                isLeastSquaresFit = false,
                isValid = true
            )
        }

        // Least Squares Fitting for N >= 3 (Centroid alignment)
        val n = anchors.size.toDouble()
        val meanLocalX = anchors.sumOf { it.localX } / n
        val meanLocalY = anchors.sumOf { it.localY } / n
        val meanWorldX = anchors.sumOf { it.worldX } / n
        val meanWorldY = anchors.sumOf { it.worldY } / n

        var num = 0.0
        var den = 0.0

        for (a in anchors) {
            val lx = a.localX - meanLocalX
            val ly = a.localY - meanLocalY
            val wx = a.worldX - meanWorldX
            val wy = a.worldY - meanWorldY

            num += lx * wy - ly * wx
            den += lx * wx + ly * wy
        }

        val rot = atan2(num, den)
        val tx = meanWorldX - (meanLocalX * cos(rot) - meanLocalY * sin(rot))
        val ty = meanWorldY - (meanLocalX * sin(rot) + meanLocalY * cos(rot))

        val residuals = anchors.map { calculateResidual(it, tx, ty, rot) }
        val meanError = residuals.average()

        return RegistrationResult(
            hallId = hallId,
            tx = tx,
            ty = ty,
            rotationRad = rot,
            residuals = residuals,
            meanResidualError = meanError,
            isLeastSquaresFit = true,
            isValid = true
        )
    }

    fun transformLocalToWorld(
        localX: Double,
        localY: Double,
        localZ: Double,
        result: RegistrationResult
    ): Triple<Double, Double, Double> {
        if (!result.isValid) return Triple(localX, localY, localZ)

        val c = cos(result.rotationRad)
        val s = sin(result.rotationRad)

        val worldX = (localX * c - localY * s) + result.tx
        val worldY = (localX * s + localY * c) + result.ty
        val worldZ = localZ

        return Triple(worldX, worldY, worldZ)
    }

    private fun calculateResidual(a: AnchorPointPair, tx: Double, ty: Double, rot: Double): Double {
        val c = cos(rot)
        val s = sin(rot)

        val predX = (a.localX * c - a.localY * s) + tx
        val predY = (a.localX * s + a.localY * c) + ty

        val dx = predX - a.worldX
        val dy = predY - a.worldY
        return sqrt(dx * dx + dy * dy)
    }
}
