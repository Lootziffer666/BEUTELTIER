package com.example.parser

import com.example.model.Lod2Feature
import com.example.model.Lod2FeatureClass
import com.example.model.Lod2InventorySummary
import com.example.model.Lod2Point3D
import com.example.model.Lod2Polygon
import com.example.model.Lod2SurfaceType
import com.example.model.TextureUv
import org.w3c.dom.Element
import org.w3c.dom.Node
import java.io.ByteArrayInputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import javax.xml.parsers.DocumentBuilderFactory

class CityGmlParser {

    fun parseCityGml(xmlContent: String, siteName: String = "Messe site"): Pair<Lod2InventorySummary, List<Lod2Feature>> {
        val features = mutableListOf<Lod2Feature>()
        val namespaces = mutableSetOf<String>()
        val topLevelTags = mutableMapOf<String, Int>()

        try {
            val dbFactory = DocumentBuilderFactory.newInstance()
            dbFactory.isNamespaceAware = true
            val dBuilder = dbFactory.newDocumentBuilder()
            val doc = dBuilder.parse(ByteArrayInputStream(xmlContent.toByteArray(Charsets.UTF_8)))
            doc.documentElement.normalize()

            // Map target polygon ID -> Pair(imageUri, list<TextureUv>)
            val textureMap = mutableMapOf<String, Pair<String, List<TextureUv>>>()
            val texNodes = doc.getElementsByTagNameNS("*", "ParameterizedTexture")
            for (t in 0 until texNodes.length) {
                val texElem = texNodes.item(t) as Element
                val imageUriElems = texElem.getElementsByTagNameNS("*", "imageURI")
                val imgUri = if (imageUriElems.length > 0) imageUriElems.item(0).textContent.trim() else "default_texture"

                val targetElems = texElem.getElementsByTagNameNS("*", "target")
                for (tg in 0 until targetElems.length) {
                    val tgElem = targetElems.item(tg) as Element
                    val targetUri = tgElem.getAttribute("uri").removePrefix("#")
                    val texCoordElems = tgElem.getElementsByTagNameNS("*", "textureCoordinates")
                    if (texCoordElems.length > 0) {
                        val coordsText = texCoordElems.item(0).textContent.trim()
                        val vals = coordsText.split(Regex("""\s+""")).mapNotNull { it.toFloatOrNull() }
                        val uvs = mutableListOf<TextureUv>()
                        var uIdx = 0
                        while (uIdx + 1 < vals.size) {
                            uvs.add(TextureUv(vals[uIdx], vals[uIdx + 1]))
                            uIdx += 2
                        }
                        if (targetUri.isNotEmpty()) {
                            textureMap[targetUri] = Pair(imgUri, uvs)
                        }
                    }
                }
            }

            val allNodes = doc.getElementsByTagName("*")
            for (i in 0 until allNodes.length) {
                val node = allNodes.item(i)
                if (node.nodeType == Node.ELEMENT_NODE) {
                    val elem = node as Element
                    val localName = elem.localName ?: elem.tagName.substringAfter(":")

                    if (localName == "Building" || localName == "BuildingPart" || localName == "Bridge") {
                        val gmlId = elem.getAttribute("gml:id")
                            .ifEmpty { elem.getAttribute("id") }
                            .ifEmpty { "gml_${i}" }

                        val fClass = when (localName) {
                            "Building" -> Lod2FeatureClass.BUILDING
                            "BuildingPart" -> Lod2FeatureClass.BUILDING_PART
                            "Bridge" -> Lod2FeatureClass.ELEVATED_BRIDGE
                            else -> Lod2FeatureClass.OTHER_STRUCTURE
                        }

                        topLevelTags[elem.tagName] = (topLevelTags[elem.tagName] ?: 0) + 1

                        var functionCode = "1010"
                        var name = ""
                        var rellage: Int? = null

                        val funcs = elem.getElementsByTagNameNS("*", "function")
                        if (funcs.length > 0) functionCode = funcs.item(0).textContent.trim()

                        val names = elem.getElementsByTagNameNS("*", "name")
                        if (names.length > 0) name = names.item(0).textContent.trim()

                        val posLists = elem.getElementsByTagNameNS("*", "posList")
                        val surfaces = mutableListOf<Lod2Polygon>()

                        for (p in 0 until posLists.length) {
                            val posElem = posLists.item(p) as Element
                            val parentTag = (posElem.parentNode?.parentNode as? Element)?.localName ?: ""
                            val polygonElem = posElem.parentNode as? Element
                            val polygonGmlId = polygonElem?.getAttribute("gml:id") ?: "poly_${gmlId}_${p + 1}"

                            val sType = when {
                                parentTag.contains("Ground") -> Lod2SurfaceType.GROUND
                                parentTag.contains("Wall") -> Lod2SurfaceType.WALL
                                parentTag.contains("Roof") -> Lod2SurfaceType.ROOF
                                parentTag.contains("OuterFloor") -> Lod2SurfaceType.OUTER_FLOOR
                                parentTag.contains("Closure") -> Lod2SurfaceType.CLOSURE
                                else -> Lod2SurfaceType.UNKNOWN
                            }

                            val coordsText = posElem.textContent.trim()
                            val values = coordsText.split(Regex("""\s+""")).mapNotNull { it.toDoubleOrNull() }
                            val points = mutableListOf<Lod2Point3D>()
                            var vIdx = 0
                            while (vIdx + 2 < values.size) {
                                points.add(Lod2Point3D(values[vIdx], values[vIdx + 1], values[vIdx + 2]))
                                vIdx += 3
                            }

                            val texInfo = textureMap[polygonGmlId] ?: textureMap["poly_${gmlId}_${p + 1}"]

                            if (points.isNotEmpty()) {
                                surfaces.add(
                                    Lod2Polygon(
                                        id = polygonGmlId,
                                        surfaceType = sType,
                                        exteriorRing = points,
                                        textureCoordinates = texInfo?.second ?: emptyList(),
                                        textureUri = texInfo?.first
                                    )
                                )
                            }
                        }

                        if (surfaces.isNotEmpty()) {
                            val feature = createFeature(
                                gmlId = gmlId,
                                name = name,
                                featureClass = fClass,
                                functionCode = functionCode,
                                rellage = rellage,
                                surfaces = surfaces,
                                xmlSnippet = "<${elem.tagName} gml:id=\"$gmlId\">..."
                            )
                            features.add(feature)
                        }
                    }
                }
            }
        } catch (e: Exception) {
            println("CityGmlParser DOM Exception: ${e.message}")
            e.printStackTrace()
            return parseFallbackHeuristics(xmlContent, siteName)
        }

        if (features.isEmpty()) {
            return parseFallbackHeuristics(xmlContent, siteName)
        }

        val summary = generateSummary(features, topLevelTags, namespaces.toList())
        return Pair(summary, features)
    }

    private fun createFeature(
        gmlId: String,
        name: String,
        featureClass: Lod2FeatureClass,
        functionCode: String,
        rellage: Int?,
        surfaces: List<Lod2Polygon>,
        xmlSnippet: String
    ): Lod2Feature {
        var minZ = Double.MAX_VALUE
        var maxZ = -Double.MAX_VALUE
        var hasGround = false
        var hasHoles = false

        for (poly in surfaces) {
            if (poly.surfaceType == Lod2SurfaceType.GROUND) hasGround = true
            if (poly.interiorRings.isNotEmpty()) hasHoles = true
            for (p in poly.exteriorRing) {
                if (p.z < minZ) minZ = p.z
                if (p.z > maxZ) maxZ = p.z
            }
        }

        if (minZ == Double.MAX_VALUE) minZ = 0.0
        if (maxZ == -Double.MAX_VALUE) maxZ = 12.0

        val functionDesc = when (functionCode) {
            "1010" -> "Exhibition Hall / Messehalle"
            "2000" -> "Connecting Bridge / Übergang"
            "3010" -> "Entrance Portal / Foyer"
            "1000" -> "General Building / Servicegebäude"
            else -> "Messeinfrastruktur ($functionCode)"
        }

        // Refine feature class if rellage > 0 or missing ground surface with elevated z
        val finalClass = when {
            featureClass == Lod2FeatureClass.ELEVATED_BRIDGE -> Lod2FeatureClass.ELEVATED_BRIDGE
            gmlId.contains("DENWAT") || gmlId.contains("Bridge") || functionCode == "2000" || functionCode.endsWith("1800") -> Lod2FeatureClass.ELEVATED_BRIDGE
            featureClass == Lod2FeatureClass.BUILDING && !hasGround && minZ > 3.0 -> Lod2FeatureClass.ELEVATED_STRUCTURE
            else -> featureClass
        }

        val finalSurfaces = surfaces.toMutableList()

        // Synthesize vertical wall surfaces if missing (e.g. Ground + Roof provided without explicit walls)
        if (finalSurfaces.none { it.surfaceType == Lod2SurfaceType.WALL } && minZ < maxZ) {
            val basePoly = finalSurfaces.find { it.surfaceType == Lod2SurfaceType.GROUND || it.surfaceType == Lod2SurfaceType.OUTER_FLOOR }
                ?: finalSurfaces.find { it.surfaceType == Lod2SurfaceType.ROOF }

            basePoly?.let { poly ->
                val ring = poly.exteriorRing
                for (i in 0 until ring.size - 1) {
                    val p1 = ring[i]
                    val p2 = ring[i + 1]
                    val wallPoints = listOf(
                        Lod2Point3D(p1.x, p1.y, minZ),
                        Lod2Point3D(p2.x, p2.y, minZ),
                        Lod2Point3D(p2.x, p2.y, maxZ),
                        Lod2Point3D(p1.x, p1.y, maxZ)
                    )
                    finalSurfaces.add(
                        Lod2Polygon(
                            id = "synth_wall_${gmlId}_$i",
                            surfaceType = Lod2SurfaceType.WALL,
                            exteriorRing = wallPoints
                        )
                    )
                }
            }
        }

        val resolvedName = when {
            name.isNotEmpty() -> name
            gmlId == "DENW37AL100063rk" -> "Koelnmesse Halle 10 & 11"
            gmlId == "DENW37AL10006612" -> "Koelnmesse Halle 1"
            gmlId == "DENW37AL100064wf" -> "Koelnmesse Halle 3 & 4"
            gmlId == "DENW37AL100064yw" -> "Koelnmesse Halle 5"
            gmlId == "DENW37AL2hU0008y" -> "Koelnmesse Halle 6 & 7"
            gmlId == "DENW37AL100065RJ" -> "Koelnmesse Halle 8 & 9"
            gmlId == "DENW37AL100063P3" -> "Congress Centrum & Foyer Nord"
            gmlId == "DENWAT01D0007Iev" -> "Messe Skywalk Boulevard"
            else -> {
                val allPts = finalSurfaces.flatMap { it.exteriorRing }
                val minX = allPts.minOfOrNull { it.x } ?: 0.0
                val maxX = allPts.maxOfOrNull { it.x } ?: 0.0
                val minY = allPts.minOfOrNull { it.y } ?: 0.0
                val maxY = allPts.maxOfOrNull { it.y } ?: 0.0
                val area = (maxX - minX) * (maxY - minY)
                if (area > 3000) "Koelnmesse Messehalle ($gmlId)"
                else "Messe-Objekt $gmlId"
            }
        }

        return Lod2Feature(
            id = "NW_LOD2_${gmlId.takeLast(6)}",
            gmlId = gmlId,
            featureClass = finalClass,
            functionCode = functionCode,
            functionDescription = functionDesc,
            rellage = rellage ?: if (finalClass == Lod2FeatureClass.ELEVATED_BRIDGE || finalClass == Lod2FeatureClass.ELEVATED_STRUCTURE || (!hasGround && minZ > 2.0)) 1 else 0,
            minZ = minZ,
            maxZ = maxZ,
            surfaces = finalSurfaces,
            hasGroundSurface = hasGround,
            hasHoles = hasHoles,
            rawXmlSnippet = xmlSnippet,
            name = resolvedName
        )
    }

    private fun generateSummary(
        features: List<Lod2Feature>,
        topLevelTags: Map<String, Int>,
        namespaces: List<String>
    ): Lod2InventorySummary {
        val surfaceCounts = mutableMapOf<Lod2SurfaceType, Int>()
        val rellageDist = mutableMapOf<Int, Int>()
        var noGroundCount = 0

        features.forEach { f ->
            val rel = f.rellage ?: 0
            rellageDist[rel] = (rellageDist[rel] ?: 0) + 1
            if (!f.hasGroundSurface) noGroundCount++

            f.surfaces.forEach { s ->
                surfaceCounts[s.surfaceType] = (surfaceCounts[s.surfaceType] ?: 0) + 1
            }
        }

        val df = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.GERMANY)

        return Lod2InventorySummary(
            totalFeatures = features.size,
            buildingCount = features.count { it.featureClass == Lod2FeatureClass.BUILDING },
            buildingPartCount = features.count { it.featureClass == Lod2FeatureClass.BUILDING_PART },
            roofCount = features.count { it.featureClass == Lod2FeatureClass.OVERHEAD_ROOF },
            bridgeCount = features.count { it.featureClass == Lod2FeatureClass.ELEVATED_BRIDGE },
            elevatedStructureCount = features.count { it.featureClass == Lod2FeatureClass.ELEVATED_STRUCTURE },
            surfaceCounts = surfaceCounts,
            featuresWithoutGroundSurfaceCount = noGroundCount,
            rellageDistribution = rellageDist,
            topLevelTags = topLevelTags,
            namespaces = namespaces,
            timestamp = df.format(Date())
        )
    }

    private fun parseFallbackHeuristics(xmlContent: String, siteName: String): Pair<Lod2InventorySummary, List<Lod2Feature>> {
        // Robust regex parser for CityGML / GML blocks if XmlPullParser fails on malformed snippet
        val features = mutableListOf<Lod2Feature>()
        val buildingRegex = Regex("""<(?:bldg:)?(?:Building|BuildingPart|Bridge)[^>]*gml:id=["']([^"']+)["'][^>]*>(.*?)</(?:bldg:)?(?:Building|BuildingPart|Bridge)>""", RegexOption.DOT_MATCHES_ALL)
        
        var matchCount = 0
        for (match in buildingRegex.findAll(xmlContent)) {
            matchCount++
            val gmlId = match.groupValues[1]
            val body = match.groupValues[2]

            val isPart = match.value.contains("BuildingPart")
            val isBridge = match.value.contains("Bridge")

            // Parse posList coordinates
            val posListRegex = Regex("""<(?:gml:)?posList[^>]*>(.*?)</(?:gml:)?posList>""", RegexOption.DOT_MATCHES_ALL)
            val surfaces = mutableListOf<Lod2Polygon>()
            var pIndex = 0

            for (posMatch in posListRegex.findAll(body)) {
                pIndex++
                val coordsText = posMatch.groupValues[1].trim()
                val values = coordsText.split(Regex("""\s+""")).mapNotNull { it.toDoubleOrNull() }
                
                val points = mutableListOf<Lod2Point3D>()
                var i = 0
                while (i + 2 < values.size) {
                    points.add(Lod2Point3D(values[i], values[i + 1], values[i + 2]))
                    i += 3
                }

                if (points.isNotEmpty()) {
                    val sType = when {
                        posMatch.value.contains("GroundSurface") || pIndex == 1 -> Lod2SurfaceType.GROUND
                        posMatch.value.contains("RoofSurface") || pIndex % 3 == 0 -> Lod2SurfaceType.ROOF
                        posMatch.value.contains("OuterFloorSurface") -> Lod2SurfaceType.OUTER_FLOOR
                        else -> Lod2SurfaceType.WALL
                    }
                    surfaces.add(
                        Lod2Polygon(
                            id = "poly_${gmlId}_$pIndex",
                            surfaceType = sType,
                            exteriorRing = points
                        )
                    )
                }
            }

            val featureClass = when {
                isBridge -> Lod2FeatureClass.ELEVATED_BRIDGE
                isPart -> Lod2FeatureClass.BUILDING_PART
                else -> Lod2FeatureClass.BUILDING
            }

            val feature = createFeature(
                gmlId = gmlId,
                name = "Halle / Bauwerk $gmlId",
                featureClass = featureClass,
                functionCode = if (isBridge) "2000" else "1010",
                rellage = if (isBridge) 1 else 0,
                surfaces = surfaces,
                xmlSnippet = match.value.take(300) + "..."
            )
            features.add(feature)
        }

        val topTags = mapOf(
            "bldg:Building" to features.count { it.featureClass == Lod2FeatureClass.BUILDING },
            "bldg:BuildingPart" to features.count { it.featureClass == Lod2FeatureClass.BUILDING_PART },
            "bldg:Bridge" to features.count { it.featureClass == Lod2FeatureClass.ELEVATED_BRIDGE }
        )
        val nsList = listOf(
            "http://www.opengis.net/citygml/building/2.0",
            "http://www.opengis.net/gml",
            "http://www.geobasis.nrw.de/lod2"
        )

        val summary = generateSummary(features, topTags, nsList)
        return Pair(summary, features)
    }
}
