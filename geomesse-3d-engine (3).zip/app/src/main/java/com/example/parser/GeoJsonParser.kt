package com.example.parser

import com.example.model.Lod2Feature
import com.example.model.Lod2FeatureClass
import com.example.model.Lod2InventorySummary
import com.example.model.Lod2Point3D
import com.example.model.Lod2Polygon
import com.example.model.Lod2SurfaceType
import org.json.JSONObject

class GeoJsonParser {

    fun parseGeoJson(jsonContent: String, datasetTitle: String = "GeoJSON Import"): Pair<Lod2InventorySummary, List<Lod2Feature>> {
        val features = mutableListOf<Lod2Feature>()

        try {
            val root = JSONObject(jsonContent)
            val jsonFeatures = if (root.has("features")) {
                root.getJSONArray("features")
            } else if (root.optString("type") == "Feature") {
                org.json.JSONArray().put(root)
            } else {
                org.json.JSONArray()
            }

            for (i in 0 until jsonFeatures.length()) {
                val fObj = jsonFeatures.getJSONObject(i)
                val props = fObj.optJSONObject("properties") ?: JSONObject()
                val geom = fObj.optJSONObject("geometry") ?: continue

                val id = fObj.optString("id", props.optString("id", "geojson_bldg_${i + 1}"))
                val name = props.optString("name", props.optString("building", "Gebäude ${i + 1}"))
                val height = props.optDouble("height", props.optDouble("ele", props.optDouble("building:levels", 3.0) * 3.5))
                val groundElevation = props.optDouble("ground_elevation", props.optDouble("min_height", 0.0))

                val geomType = geom.optString("type")
                val polygons = mutableListOf<Lod2Polygon>()

                if (geomType == "Polygon") {
                    val coordsArray = geom.getJSONArray("coordinates")
                    if (coordsArray.length() > 0) {
                        val exterior = coordsArray.getJSONArray(0)
                        val points2d = mutableListOf<Lod2Point3D>()
                        for (p in 0 until exterior.length()) {
                            val pt = exterior.getJSONArray(p)
                            val x = pt.getDouble(0)
                            val y = pt.getDouble(1)
                            val z = if (pt.length() > 2) pt.getDouble(2) else groundElevation
                            points2d.add(Lod2Point3D(x, y, z))
                        }
                        polygons.addAll(extrudePolygonToLod2(id, points2d, height))
                    }
                } else if (geomType == "MultiPolygon") {
                    val multiCoords = geom.getJSONArray("coordinates")
                    for (m in 0 until multiCoords.length()) {
                        val coordsArray = multiCoords.getJSONArray(m)
                        if (coordsArray.length() > 0) {
                            val exterior = coordsArray.getJSONArray(0)
                            val points2d = mutableListOf<Lod2Point3D>()
                            for (p in 0 until exterior.length()) {
                                val pt = exterior.getJSONArray(p)
                                val x = pt.getDouble(0)
                                val y = pt.getDouble(1)
                                val z = if (pt.length() > 2) pt.getDouble(2) else groundElevation
                                points2d.add(Lod2Point3D(x, y, z))
                            }
                            polygons.addAll(extrudePolygonToLod2("${id}_part_$m", points2d, height))
                        }
                    }
                }

                if (polygons.isNotEmpty()) {
                    val minZ = polygons.flatMap { it.exteriorRing }.minOfOrNull { it.z } ?: 0.0
                    val maxZ = polygons.flatMap { it.exteriorRing }.maxOfOrNull { it.z } ?: height
                    val hasGround = polygons.any { it.surfaceType == Lod2SurfaceType.GROUND }

                    features.add(
                        Lod2Feature(
                            id = id,
                            gmlId = id,
                            featureClass = Lod2FeatureClass.BUILDING,
                            functionCode = "3001",
                            functionDescription = props.optString("building", "Messehalle / Gebäude"),
                            rellage = 0,
                            minZ = minZ,
                            maxZ = maxZ,
                            surfaces = polygons,
                            hasGroundSurface = hasGround,
                            hasHoles = false,
                            name = name
                        )
                    )
                }
            }

        } catch (e: Exception) {
            e.printStackTrace()
        }

        val surfaceTypeCounts = mutableMapOf<Lod2SurfaceType, Int>()
        for (f in features) {
            for (s in f.surfaces) {
                surfaceTypeCounts[s.surfaceType] = (surfaceTypeCounts[s.surfaceType] ?: 0) + 1
            }
        }

        val summary = Lod2InventorySummary(
            totalFeatures = features.size,
            buildingCount = features.size,
            buildingPartCount = 0,
            roofCount = 0,
            bridgeCount = 0,
            elevatedStructureCount = 0,
            surfaceCounts = surfaceTypeCounts,
            featuresWithoutGroundSurfaceCount = features.count { !it.hasGroundSurface },
            rellageDistribution = mapOf(0 to features.size),
            topLevelTags = mapOf("geojson:FeatureCollection" to features.size),
            namespaces = listOf("http://geojson.org/geojson-spec.html"),
            timestamp = "GeoJSON / GIS Import"
        )

        return Pair(summary, features)
    }

    private fun extrudePolygonToLod2(baseId: String, baseRing: List<Lod2Point3D>, height: Double): List<Lod2Polygon> {
        val polygons = mutableListOf<Lod2Polygon>()
        if (baseRing.size < 3) return polygons

        val baseZ = baseRing.first().z
        val roofZ = baseZ + height

        // 1. Ground Surface
        polygons.add(
            Lod2Polygon(
                id = "${baseId}_ground",
                surfaceType = Lod2SurfaceType.GROUND,
                exteriorRing = baseRing
            )
        )

        // 2. Roof Surface
        val roofRing = baseRing.map { Lod2Point3D(it.x, it.y, roofZ) }
        polygons.add(
            Lod2Polygon(
                id = "${baseId}_roof",
                surfaceType = Lod2SurfaceType.ROOF,
                exteriorRing = roofRing
            )
        )

        // 3. Wall Surfaces
        for (idx in 0 until baseRing.size - 1) {
            val p1 = baseRing[idx]
            val p2 = baseRing[idx + 1]

            val wallRing = listOf(
                Lod2Point3D(p1.x, p1.y, p1.z),
                Lod2Point3D(p2.x, p2.y, p2.z),
                Lod2Point3D(p2.x, p2.y, roofZ),
                Lod2Point3D(p1.x, p1.y, roofZ)
            )

            polygons.add(
                Lod2Polygon(
                    id = "${baseId}_wall_$idx",
                    surfaceType = Lod2SurfaceType.WALL,
                    exteriorRing = wallRing
                )
            )
        }

        return polygons
    }
}
