import { CityGMLBuilding } from '../types/koelnmesse';

export function parseCityGMLText(xmlText: string): CityGMLBuilding[] {
  const buildings: CityGMLBuilding[] = [];
  
  try {
    const parser = new DOMParser();
    const xmlDoc = parser.parseFromString(xmlText, "text/xml");
    
    // Look for building elements (bldg:Building or Building)
    const buildingNodes = Array.from(xmlDoc.querySelectorAll("Building, bldg\\:Building"));
    
    if (buildingNodes.length === 0) {
      // Fallback regex parsing if querySelector doesn't catch namespace
      return parseCityGMLRegex(xmlText);
    }

    buildingNodes.forEach((node, idx) => {
      const gmlId = node.getAttribute("gml:id") || node.getAttribute("id") || `bldg-${idx + 1}`;
      
      // Get height
      const heightNode = node.querySelector("measuredHeight, bldg\\:measuredHeight, Height, bldg\\:Height");
      let height = heightNode ? parseFloat(heightNode.textContent || '15') : 18;
      if (isNaN(height) || height <= 0) height = 15;

      // Extract posList coordinates
      const posListNodes = Array.from(node.querySelectorAll("posList, gml\\:posList, coordinates, gml\\:coordinates"));
      let footprint: [number, number][] = [];

      for (const posNode of posListNodes) {
        const text = posNode.textContent || '';
        const coords = text.trim().split(/\s+/).map(Number).filter(n => !isNaN(n));
        
        if (coords.length >= 6) {
          // Coords are usually X Y Z X Y Z... or E N H E N H...
          const points: [number, number][] = [];
          for (let i = 0; i < coords.length; i += 3) {
            points.push([coords[i], coords[i + 1]]);
          }
          if (points.length >= 3) {
            footprint = points;
            break;
          }
        }
      }

      if (footprint.length >= 3) {
        buildings.push({
          gmlId,
          name: `CityGML Gebaude ${gmlId}`,
          height,
          footprint,
          measuredHeight: height,
          lod: 'LoD2'
        });
      }
    });

  } catch (err) {
    console.warn("DOMParser failed, using fallback regex for CityGML:", err);
    return parseCityGMLRegex(xmlText);
  }

  return buildings;
}

function parseCityGMLRegex(xmlText: string): CityGMLBuilding[] {
  const buildings: CityGMLBuilding[] = [];
  const bldgRegex = /<bldg:Building[^>]*gml:id=["']([^"']+)["'][^>]*>([\s\S]*?)<\/bldg:Building>/gi;
  let match;
  let count = 0;

  while ((match = bldgRegex.exec(xmlText)) !== null) {
    count++;
    const gmlId = match[1] || `LoD2-NRW-${count}`;
    const body = match[2];

    const hMatch = body.match(/<bldg:measuredHeight[^>]*>([\d.]+)<\/bldg:measuredHeight>/i);
    const height = hMatch ? parseFloat(hMatch[1]) : 16;

    const posMatch = body.match(/<gml:posList[^>]*>([\s\S]*?)<\/gml:posList>/i);
    let footprint: [number, number][] = [];

    if (posMatch) {
      const nums = posMatch[1].trim().split(/\s+/).map(Number).filter(n => !isNaN(n));
      const points: [number, number][] = [];
      for (let i = 0; i < nums.length; i += 3) {
        points.push([nums[i], nums[i + 1]]);
      }
      if (points.length >= 3) {
        footprint = points;
      }
    }

    if (footprint.length >= 3) {
      buildings.push({
        gmlId,
        name: `NRW LoD2 Gebäude ${gmlId}`,
        height,
        footprint,
        measuredHeight: height,
        lod: 'LoD2'
      });
    }
  }

  return buildings;
}

// Generate demo NRW LoD2 buildings if no file is uploaded yet
export function getDemoNRWCityGMLBuildings(): CityGMLBuilding[] {
  return [
    {
      gmlId: 'LoD2_357_5645_1_NW_b1',
      name: 'Messehalle 6 (NRW Amtlicher Datensatz LoD2)',
      height: 22,
      measuredHeight: 22,
      lod: 'LoD2',
      footprint: [
        [-190, -170], [-70, -170], [-70, -70], [-190, -70]
      ]
    },
    {
      gmlId: 'LoD2_357_5646_1_NW_b2',
      name: 'Messehalle 7 & Nordeingang (LoD2 NRW)',
      height: 24,
      measuredHeight: 24,
      lod: 'LoD2',
      footprint: [
        [-190, -60], [-70, -60], [-70, 40], [-190, 40]
      ]
    },
    {
      gmlId: 'LoD2_358_5645_1_NW_b3',
      name: 'Messehalle 8 (LoD2 NRW Nord-Ost)',
      height: 22,
      measuredHeight: 22,
      lod: 'LoD2',
      footprint: [
        [70, -170], [190, -170], [190, -70], [70, -70]
      ]
    },
    {
      gmlId: 'LoD2_358_5646_1_NW_b4',
      name: 'Halle 11 Congress-Centrum (LoD2 NRW Ost)',
      height: 32,
      measuredHeight: 32,
      lod: 'LoD2',
      footprint: [
        [220, 30], [320, 30], [320, 150], [220, 150]
      ]
    }
  ];
}
