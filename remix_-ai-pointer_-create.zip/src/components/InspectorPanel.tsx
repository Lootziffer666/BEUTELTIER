import React from 'react';
import { SelectedElement, MaterialPreset } from '../types/koelnmesse';
import { Layers, Palette, X, Sparkles, Sliders, Check } from 'lucide-react';

interface InspectorPanelProps {
  selectedElement: SelectedElement | null;
  materialPresets: MaterialPreset[];
  onApplyMaterial: (elementId: string, materialPresetId: string) => void;
  onClose: () => void;
}

export const InspectorPanel: React.FC<InspectorPanelProps> = ({
  selectedElement,
  materialPresets,
  onApplyMaterial,
  onClose,
}) => {
  if (!selectedElement) return null;

  return (
    <div className="absolute bottom-6 left-6 z-20 w-80 sm:w-96 bg-slate-900/95 backdrop-blur-xl border border-slate-700/80 rounded-3xl p-5 shadow-2xl text-slate-100 animate-in fade-in slide-in-from-bottom-5">
      {/* Header */}
      <div className="flex items-center justify-between pb-3 border-b border-slate-800">
        <div className="flex items-center gap-2.5">
          <div className="p-2 bg-indigo-500/20 text-indigo-400 rounded-xl">
            <Layers className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-bold text-sm text-slate-100">{selectedElement.name}</h3>
            <p className="text-[11px] text-slate-400 capitalize">
              Bauteil: <span className="text-indigo-400 font-semibold">{selectedElement.surfaceType}</span> {selectedElement.hallName && `• ${selectedElement.hallName}`}
            </p>
          </div>
        </div>

        <button 
          onClick={onClose}
          className="p-1.5 rounded-full hover:bg-slate-800 text-slate-400 hover:text-slate-200 transition cursor-pointer"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Surface Details & Quick Controls */}
      <div className="mt-3.5 space-y-3">
        <div className="flex items-center justify-between text-xs bg-slate-950 p-2.5 rounded-xl border border-slate-800">
          <span className="text-slate-400 flex items-center gap-1.5">
            <Palette className="w-3.5 h-3.5 text-indigo-400" />
            Aktuelles Material
          </span>
          <div className="flex items-center gap-2 font-mono text-[11px]">
            <span 
              className="w-3.5 h-3.5 rounded-full border border-slate-600 shadow-inner" 
              style={{ backgroundColor: selectedElement.color }} 
            />
            {selectedElement.materialPresetId}
          </div>
        </div>

        {/* Material Presets Grid */}
        <div>
          <label className="block text-xs font-semibold text-slate-300 mb-2 flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            Material & Textur austauschen
          </label>

          <div className="grid grid-cols-2 gap-2 max-h-48 overflow-y-auto pr-1 custom-scrollbar">
            {materialPresets.map((preset) => {
              const isCurrent = selectedElement.materialPresetId === preset.id;
              return (
                <button
                  key={preset.id}
                  onClick={() => onApplyMaterial(selectedElement.id, preset.id)}
                  className={`p-2.5 rounded-xl text-left border transition cursor-pointer flex flex-col justify-between relative group ${
                    isCurrent 
                      ? 'bg-indigo-950/80 border-indigo-500 text-white shadow-md' 
                      : 'bg-slate-950/50 border-slate-800 text-slate-300 hover:border-slate-700 hover:bg-slate-800/60'
                  }`}
                >
                  <div className="flex items-center justify-between w-full">
                    <span 
                      className="w-4 h-4 rounded-full border border-slate-600 shadow" 
                      style={{ backgroundColor: preset.color }}
                    />
                    {isCurrent && <Check className="w-3.5 h-3.5 text-indigo-400" />}
                  </div>

                  <span className="text-[11px] font-medium mt-2 line-clamp-2 leading-tight">
                    {preset.name}
                  </span>
                </button>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
