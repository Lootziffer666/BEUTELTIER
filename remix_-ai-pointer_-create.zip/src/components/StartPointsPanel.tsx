import React, { useState } from 'react';
import { StartPoint } from '../types/koelnmesse';
import { MapPin, Compass, Search, ChevronRight, Navigation, Sparkles } from 'lucide-react';

interface StartPointsPanelProps {
  startPoints: StartPoint[];
  selectedStartPoint: StartPoint;
  onSelectStartPoint: (point: StartPoint) => void;
}

export const StartPointsPanel: React.FC<StartPointsPanelProps> = ({
  startPoints,
  selectedStartPoint,
  onSelectStartPoint,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [activeCategory, setActiveCategory] = useState<string>('All');

  const categories = ['All', 'Entrance', 'Hall', 'Passage'];

  const filteredPoints = startPoints.filter(point => {
    const matchesSearch = point.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      point.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (point.hallNumber && point.hallNumber.includes(searchTerm));
    const matchesCategory = activeCategory === 'All' || point.category === activeCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="flex flex-col h-full bg-slate-900/90 text-slate-100 p-4 border-l border-slate-800 backdrop-blur-md overflow-hidden">
      {/* Panel Header */}
      <div className="flex items-center justify-between pb-3 border-b border-slate-800">
        <div className="flex items-center gap-2">
          <div className="p-2 bg-sky-500/20 text-sky-400 rounded-xl">
            <Compass className="w-5 h-5" />
          </div>
          <div>
            <h2 className="font-bold text-base text-slate-100">Startpunkte & Quick-Jump</h2>
            <p className="text-xs text-slate-400">Direkt-Navigation Koelnmesse</p>
          </div>
        </div>
        <span className="text-xs px-2.5 py-1 bg-sky-950 text-sky-400 rounded-full font-medium border border-sky-800/50">
          {filteredPoints.length} Orte
        </span>
      </div>

      {/* Nordeingang Default Highlight Card */}
      <div className="mt-3 p-3.5 bg-gradient-to-r from-sky-900/50 to-indigo-900/50 rounded-2xl border border-sky-700/50 relative overflow-hidden">
        <div className="flex justify-between items-start">
          <div className="flex items-center gap-2 text-sky-300 font-semibold text-xs">
            <Sparkles className="w-4 h-4 text-amber-400" />
            Standard-Startpunkt
          </div>
          <span className="text-[10px] font-mono bg-sky-950/80 text-sky-300 px-2 py-0.5 rounded-full border border-sky-700/50">
            Nordeingang
          </span>
        </div>
        <p className="text-sm font-bold text-white mt-1">Nordeingang (Messeplatz Nord)</p>
        <p className="text-xs text-slate-300 mt-1 line-clamp-2">
          Direkter Zugang Bahnhof Köln Messe/Deutz Nord mit Blick auf den Haupt-Boulevard.
        </p>
        <button 
          onClick={() => {
            const nord = startPoints.find(p => p.id === 'nordeingang-haupt');
            if (nord) onSelectStartPoint(nord);
          }}
          className="mt-2.5 w-full py-2 px-3 bg-sky-500 hover:bg-sky-400 text-slate-950 font-bold text-xs rounded-xl flex items-center justify-center gap-2 transition cursor-pointer active:scale-95 shadow-lg shadow-sky-500/20"
        >
          <Navigation className="w-3.5 h-3.5" />
          Zum Nordeingang springen
        </button>
      </div>

      {/* Search Input */}
      <div className="relative mt-3">
        <Search className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
        <input 
          type="text" 
          value={searchTerm}
          onChange={e => setSearchTerm(e.target.value)}
          placeholder="Halle, Nordeingang, Boulevard..."
          className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-9 pr-3 py-2 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-sky-500 transition"
        />
      </div>

      {/* Category Filter Chips */}
      <div className="flex gap-1.5 mt-2.5 overflow-x-auto pb-1 no-scrollbar">
        {categories.map(cat => (
          <button
            key={cat}
            onClick={() => setActiveCategory(cat)}
            className={`px-3 py-1 rounded-full text-xs font-medium whitespace-nowrap transition cursor-pointer ${
              activeCategory === cat 
                ? 'bg-sky-500 text-slate-950 font-bold' 
                : 'bg-slate-800/80 text-slate-400 hover:text-slate-200 hover:bg-slate-800'
            }`}
          >
            {cat === 'All' ? 'Alle' : cat === 'Entrance' ? 'Eingänge' : cat === 'Hall' ? 'Hallen' : 'Passagen'}
          </button>
        ))}
      </div>

      {/* Start Points List */}
      <div className="flex-1 mt-3 space-y-2 overflow-y-auto pr-1 custom-scrollbar">
        {filteredPoints.map(point => {
          const isSelected = selectedStartPoint.id === point.id;
          return (
            <button
              key={point.id}
              onClick={() => onSelectStartPoint(point)}
              className={`w-full text-left p-3 rounded-xl transition border cursor-pointer relative group flex items-start gap-3 ${
                isSelected 
                  ? 'bg-sky-950/80 border-sky-500/80 shadow-md shadow-sky-950' 
                  : 'bg-slate-950/40 border-slate-800/80 hover:border-slate-700 hover:bg-slate-800/50'
              }`}
            >
              <div className={`p-2 rounded-lg mt-0.5 ${isSelected ? 'bg-sky-500 text-slate-950' : 'bg-slate-800 text-slate-400 group-hover:text-sky-400'}`}>
                <MapPin className="w-4 h-4" />
              </div>

              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between">
                  <h3 className={`font-semibold text-xs truncate ${isSelected ? 'text-sky-300' : 'text-slate-200'}`}>
                    {point.name}
                  </h3>
                  {point.level && (
                    <span className="text-[10px] bg-slate-800 px-1.5 py-0.5 rounded text-slate-400 font-mono">
                      {point.level}
                    </span>
                  )}
                </div>

                <p className="text-[11px] text-slate-400 mt-1 line-clamp-2 leading-relaxed">
                  {point.description}
                </p>
              </div>

              <ChevronRight className={`w-4 h-4 self-center transition-transform ${isSelected ? 'text-sky-400 translate-x-0.5' : 'text-slate-600 opacity-0 group-hover:opacity-100'}`} />
            </button>
          );
        })}
      </div>
    </div>
  );
};
