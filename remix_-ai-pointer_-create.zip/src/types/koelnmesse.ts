export type SurfaceType = 'wall' | 'floor' | 'ceiling' | 'pillar' | 'stand' | 'door' | 'glass' | 'facade';

export interface StartPoint {
  id: string;
  name: string;
  category: 'Entrance' | 'Hall' | 'Passage' | 'Outdoor' | 'Congress';
  position: [number, number, number];
  target: [number, number, number];
  description: string;
  hallNumber?: string;
  level?: string;
}

export interface HallData {
  id: string;
  name: string;
  hallNumber: string;
  position: [number, number, number]; // center X, Y (height/2), Z
  size: [number, number, number]; // width, height, depth
  levels: number;
  color: string;
  description: string;
  hasPassageTo?: string[];
  features?: {
    pillars?: boolean;
    galleries?: boolean;
    glassRoof?: boolean;
  };
}

export interface MaterialPreset {
  id: string;
  name: string;
  color: string;
  roughness: number;
  metalness: number;
  pattern?: 'concrete' | 'carpet_blue' | 'carpet_red' | 'wood' | 'metal' | 'glass' | 'tiles' | 'led_screen' | 'exhibition_panel';
  category: 'floor' | 'wall' | 'structure' | 'special';
}

export interface SelectedElement {
  id: string;
  name: string;
  surfaceType: SurfaceType;
  hallId?: string;
  hallName?: string;
  color: string;
  roughness: number;
  metalness: number;
  materialPresetId: string;
  position: [number, number, number];
  size?: [number, number, number];
}

export interface CityGMLBuilding {
  gmlId: string;
  name: string;
  height: number;
  footprint: [number, number][]; // X, Z coordinates
  measuredHeight?: number;
  lod: 'LoD1' | 'LoD2' | 'LoD3';
  roofType?: string;
}

export interface InteriorPhoto {
  id: string;
  name: string;
  dataUrl: string;
  hallId: string;
  timestamp: string;
  cameraHeight: number; // meters
  projectionScale: number;
  opacity: number;
  blendMode: 'normal' | 'multiply' | 'screen' | 'overlay';
}

export type NavigationMode = 'walk' | 'fly' | 'orbit';
export type ViewTab = '3d' | 'citygml' | 'photos' | 'materials' | 'startpoints';
