package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ElementType
import com.example.data.model.PhotoMarker
import com.example.data.model.StructuralPrimitive
import com.example.ui.theme.*
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun FloorPlan2D(
    primitives: List<StructuralPrimitive>,
    photoMarkers: List<PhotoMarker>,
    selectedMarker: PhotoMarker?,
    selectedPrimitive: StructuralPrimitive?,
    selectedElementTypeToPlace: ElementType?,
    isPlacementModeActive: Boolean,
    pendingYawAngle: Float,
    onMarkerSelect: (PhotoMarker?) -> Unit,
    onPrimitiveSelect: (StructuralPrimitive?) -> Unit,
    onPlacePhotoMarker: (Float, Float) -> Unit,
    onPlacePrimitive: (Float, Float, ElementType) -> Unit,
    onUpdateYawAngle: (Float) -> Unit,
    onTogglePlacement: (ElementType?) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .background(DarkSurface)
            .border(1.dp, DarkOutline, RoundedCornerShape(24.dp))
            .padding(16.dp)
            .testTag("floor_plan_2d_container")
    ) {
        // Toolbar for selecting element to place
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "2D Grundriss & Kamera-Plazierung",
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.onSurface
            )

            // Clear active placement selection button if active
            if (isPlacementModeActive) {
                TextButton(
                    onClick = { onTogglePlacement(null) },
                    contentPadding = PaddingValues(horizontal = 8.dp)
                ) {
                    Text("Abbrechen", color = OrangeAccent, fontSize = 12.sp)
                }
            }
        }

        // Element Placement Chips Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            // Photo Camera Placement button
            FilterChip(
                selected = selectedElementTypeToPlace == null && isPlacementModeActive,
                onClick = {
                    if (selectedElementTypeToPlace == null && isPlacementModeActive) {
                        onTogglePlacement(null)
                    } else {
                        onTogglePlacement(null) // Camera placement mode
                    }
                },
                label = { Text("Foto-Pin", fontSize = 11.sp) },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.PhotoCamera,
                        contentDescription = "Foto-Pin",
                        tint = OrangeAccent,
                        modifier = Modifier.size(14.dp)
                    )
                },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = OrangeAccent.copy(alpha = 0.2f),
                    selectedLabelColor = OrangeAccent
                ),
                shape = RoundedCornerShape(50),
                modifier = Modifier.testTag("place_photo_chip")
            )

            // Structural Primitives Chips
            ElementType.entries.take(4).forEach { type ->
                val isSelected = selectedElementTypeToPlace == type
                FilterChip(
                    selected = isSelected,
                    onClick = { onTogglePlacement(if (isSelected) null else type) },
                    label = { Text(type.label, fontSize = 11.sp) },
                    shape = RoundedCornerShape(50),
                    modifier = Modifier.testTag("place_type_chip_${type.name}")
                )
            }
        }

        // 2D Floor Plan Canvas
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(280.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(DarkBackground)
                .border(1.dp, DarkOutline, RoundedCornerShape(16.dp))
        ) {
            Canvas(
                modifier = Modifier
                    .fillMaxSize()
                    .pointerInput(selectedElementTypeToPlace, isPlacementModeActive) {
                        detectTapGestures { offset ->
                            val mapX = (offset.x / size.width) * 100f
                            val mapY = (offset.y / size.height) * 100f

                            if (selectedElementTypeToPlace != null) {
                                onPlacePrimitive(mapX, mapY, selectedElementTypeToPlace)
                            } else {
                                // Check if user tapped an existing photo marker
                                val tappedMarker = photoMarkers.find { marker ->
                                    val mx = (marker.posX / 100f) * size.width
                                    val my = (marker.posY / 100f) * size.height
                                    val dist = (offset.x - mx) * (offset.x - mx) + (offset.y - my) * (offset.y - my)
                                    dist < 400f // 20px radius
                                }

                                if (tappedMarker != null) {
                                    onMarkerSelect(tappedMarker)
                                } else {
                                    onPlacePhotoMarker(mapX, mapY)
                                }
                            }
                        }
                    }
            ) {
                val w = size.width
                val h = size.height

                // Draw Grid Lines
                val gridCols = 10
                val gridRows = 8
                for (i in 1 until gridCols) {
                    val gx = (i.toFloat() / gridCols) * w
                    drawLine(DarkOutline.copy(alpha = 0.3f), Offset(gx, 0f), Offset(gx, h), strokeWidth = 1f)
                }
                for (j in 1 until gridRows) {
                    val gy = (j.toFloat() / gridRows) * h
                    drawLine(DarkOutline.copy(alpha = 0.3f), Offset(0f, gy), Offset(w, gy), strokeWidth = 1f)
                }

                // Draw Outer Blueprint Boundaries
                drawRoundRect(
                    color = PrimaryBlue.copy(alpha = 0.08f),
                    topLeft = Offset(w * 0.04f, h * 0.04f),
                    size = Size(w * 0.92f, h * 0.92f),
                    cornerRadius = CornerRadius(12f, 12f)
                )
                drawRoundRect(
                    color = PrimaryBlue.copy(alpha = 0.35f),
                    topLeft = Offset(w * 0.04f, h * 0.04f),
                    size = Size(w * 0.92f, h * 0.92f),
                    cornerRadius = CornerRadius(12f, 12f),
                    style = Stroke(1.5f)
                )

                // Draw Structural Primitives 2D footprints & Labels
                primitives.forEach { prim ->
                    val px = (prim.x / 100f) * w
                    val py = (prim.y / 100f) * h
                    val pw = (prim.width / 100f) * w
                    val pl = (prim.length / 100f) * h

                    val elemColor = when (prim.type) {
                        ElementType.WALL -> ElementWall
                        ElementType.FLOOR -> ElementFloor
                        ElementType.CEILING -> ElementCeiling
                        ElementType.DOOR -> ElementDoor
                        ElementType.WINDOW -> ElementWindow
                        ElementType.STAIRS -> ElementStairs
                        ElementType.COLUMN -> ElementColumn
                    }

                    val isSelected = prim.id == selectedPrimitive?.id

                    drawRect(
                        color = if (isSelected) PrimaryBlue.copy(alpha = 0.8f) else elemColor.copy(alpha = 0.65f),
                        topLeft = Offset(px - pw / 2f, py - pl / 2f),
                        size = Size(pw.coerceAtLeast(8f), pl.coerceAtLeast(8f))
                    )
                    drawRect(
                        color = if (isSelected) Color.Yellow else Color.White.copy(alpha = 0.8f),
                        topLeft = Offset(px - pw / 2f, py - pl / 2f),
                        size = Size(pw.coerceAtLeast(8f), pl.coerceAtLeast(8f)),
                        style = Stroke(if (isSelected) 2.5f else 1.2f)
                    )

                    // Draw Primitive Text Label on 2D Map
                    if (prim.statusNote.isNotBlank()) {
                        drawContext.canvas.nativeCanvas.apply {
                            val paint = android.graphics.Paint().apply {
                                color = android.graphics.Color.WHITE
                                textSize = if (pw > 30f) 22f else 18f
                                isFakeBoldText = true
                                textAlign = android.graphics.Paint.Align.CENTER
                                setShadowLayer(3f, 0f, 0f, android.graphics.Color.BLACK)
                            }
                            // Clean label text (shortened for map overlay)
                            val cleanLabel = prim.statusNote.split(" • ").firstOrNull() ?: prim.statusNote
                            drawText(cleanLabel, px, py + 5f, paint)
                        }
                    }
                }

                // Draw Photo Markers & Direction FOV Cones on 2D Plan
                photoMarkers.forEach { marker ->
                    val mx = (marker.posX / 100f) * w
                    val my = (marker.posY / 100f) * h
                    val isSel = marker.id == selectedMarker?.id

                    val radYaw = Math.toRadians(marker.yawDegrees.toDouble()).toFloat()
                    val fovRad = Math.toRadians((marker.fovDegrees / 2f).toDouble()).toFloat()
                    val coneDist = 45f

                    val leftX = mx + sin(radYaw - fovRad) * coneDist
                    val leftY = my - cos(radYaw - fovRad) * coneDist

                    val rightX = mx + sin(radYaw + fovRad) * coneDist
                    val rightY = my - cos(radYaw + fovRad) * coneDist

                    val conePath = Path().apply {
                        moveTo(mx, my)
                        lineTo(leftX, leftY)
                        lineTo(rightX, rightY)
                        close()
                    }

                    drawPath(conePath, color = OrangeAccent.copy(alpha = 0.3f))
                    drawPath(conePath, color = OrangeAccent, style = Stroke(1.5f))

                    // Center camera pin
                    drawCircle(
                        color = if (isSel) PrimaryBlue else OrangeAccent,
                        radius = if (isSel) 10f else 7f,
                        center = Offset(mx, my)
                    )
                    if (isSel) {
                        drawCircle(
                            color = Color.White,
                            radius = 14f,
                            center = Offset(mx, my),
                            style = Stroke(2f)
                        )
                    }
                }
            }

            // Direction Yaw Angle Adjustment Ring Slider for selected photo marker
            if (selectedMarker != null) {
                Row(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(8.dp)
                        .clip(RoundedCornerShape(50))
                        .background(DarkSurface.copy(alpha = 0.9f))
                        .border(1.dp, DarkOutline, RoundedCornerShape(50))
                        .padding(horizontal = 10.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "Blickrichtung: ${selectedMarker.yawDegrees.toInt()}°",
                        style = MaterialTheme.typography.labelSmall,
                        color = OrangeAccent,
                        fontSize = 11.sp
                    )
                    Slider(
                        value = selectedMarker.yawDegrees,
                        onValueChange = onUpdateYawAngle,
                        valueRange = 0f..360f,
                        modifier = Modifier.width(100.dp),
                        colors = SliderDefaults.colors(
                            thumbColor = OrangeAccent,
                            activeTrackColor = OrangeAccent
                        )
                    )
                }
            }
        }
    }
}
