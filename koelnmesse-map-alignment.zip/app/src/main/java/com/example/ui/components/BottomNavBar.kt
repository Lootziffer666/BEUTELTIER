package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

data class NavTabItem(
    val title: String,
    val icon: ImageVector,
    val testTag: String
)

val NavTabs = listOf(
    NavTabItem("Hallen 2D", Icons.Default.Dashboard, "nav_tab_2d"),
    NavTabItem("3D Align", Icons.Default.AutoFixHigh, "nav_tab_3d"),
    NavTabItem("Foto KI", Icons.Default.CloudUpload, "nav_tab_ai"),
    NavTabItem("Export", Icons.Default.FileDownload, "nav_tab_export")
)

@Composable
fun BottomNavBar(
    selectedTab: Int,
    onTabSelected: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    NavigationBar(
        modifier = modifier
            .fillMaxWidth()
            .background(DarkSurface)
            .border(1.dp, DarkOutline),
        containerColor = DarkSurface,
        tonalElevation = 8.dp
    ) {
        NavTabs.forEachIndexed { index, item ->
            val isSelected = selectedTab == index
            NavigationBarItem(
                selected = isSelected,
                onClick = { onTabSelected(index) },
                icon = {
                    Icon(
                        imageVector = item.icon,
                        contentDescription = item.title
                    )
                },
                label = {
                    Text(
                        text = item.title,
                        fontSize = 10.sp
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = PrimaryBlue,
                    selectedTextColor = PrimaryBlue,
                    indicatorColor = PrimaryContainerBlue,
                    unselectedIconColor = OnSurfaceSubtext,
                    unselectedTextColor = OnSurfaceSubtext
                ),
                modifier = Modifier.testTag(item.testTag)
            )
        }
    }
}
