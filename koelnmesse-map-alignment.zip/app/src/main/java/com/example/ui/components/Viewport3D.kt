package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.RotateRight
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ElementType
import com.example.data.model.FloorLevel
import com.example.data.model.PhotoMarker
import com.example.data.model.StructuralPrimitive
import com.example.ui.theme.*
import kotlin.math.cos
import kotlin.math.sin

data class Point3D(val x: Float, val y: Float, val z: Float)
data class Point2D(val x: Float, val y: Float)

@Composable
fun Viewport3D(
    primitives: List<StructuralPrimitive>,
    photoMarkers: List<PhotoMarker>,
    selectedPrimitive: StructuralPrimitive?,
    selectedMarker: PhotoMarker?,
    floors: List<FloorLevel> = emptyList(),
    selectedFloorId: Int = 0,
    orbitYaw: Float,
    orbitPitch: Float,
    zoomScale: Float,
    deviationCm: Float,
    onFloorSelect: (Int) -> Unit = {},
    onOrbitChange: (Float, Float) -> Unit,
    onZoomChange: (Float) -> Unit,
    onPrimitiveSelect: (StructuralPrimitive?) -> Unit,
    onAutoCorrect: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .background(DarkSurface)
            .border(1.dp, DarkOutline, RoundedCornerShape(24.dp))
            .pointerInput(Unit) {
                detectTransformGestures { _, pan, zoom, _ ->
                    if (zoom != 1f) {
                        onZoomChange(zoom)
                    }
                    if (pan != Offset.Zero) {
                        onOrbitChange(pan.x * 0.4f, -pan.y * 0.4f)
                    }
                }
            }
            .testTag("viewport_3d_card")
    ) {
        // Top Bar inside 3D Viewport: Floor/Hall Switcher & Info
        Column(
            modifier = Modifier
                .align(Alignment.TopStart)
                .fillMaxWidth()
                .padding(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Active Geometry Badge
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(50))
                        .background(DarkBackground.copy(alpha = 0.85f))
                        .border(1.dp, DarkOutline, RoundedCornerShape(50))
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(PrimaryBlue)
                    )
                    Text(
                        text = "3D MAP (KOELNMESSE)",
                        style = MaterialTheme.typography.labelSmall,
                        color = PrimaryBlue,
                        fontSize = 10.sp
                    )
                }

                // Deviation stats pill
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(50))
                        .background(PrimaryContainerBlue.copy(alpha = 0.9f))
                        .border(1.dp, PrimaryBlue.copy(alpha = 0.5f), RoundedCornerShape(50))
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = "Abweichung",
                        tint = PrimaryBlue,
                        modifier = Modifier.size(13.dp)
                    )
                    Text(
                        text = "${String.format("%.1f", deviationCm)} cm",
                        style = MaterialTheme.typography.labelMedium,
                        color = PrimaryBlue,
                        fontSize = 11.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // 3D Quick Floor Switcher Overlay Tabs
            if (floors.isNotEmpty()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(DarkBackground.copy(alpha = 0.9f))
                        .border(1.dp, DarkOutline, RoundedCornerShape(12.dp))
                        .padding(3.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    floors.forEach { floor ->
                        val isSelected = floor.id == selectedFloorId
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSelected) PrimaryContainerBlue else Color.Transparent)
                                .clickable { onFloorSelect(floor.id) }
                                .padding(vertical = 5.dp)
                                .testTag("3d_floor_tab_${floor.id}"),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = floor.name,
                                style = MaterialTheme.typography.labelSmall,
                                color = if (isSelected) PrimaryBlue else OnSurfaceSubtext,
                                fontSize = 11.sp
                            )
                        }
                    }
                }
            }
        }

        // 3D Canvas Rendering
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .padding(top = 80.dp, bottom = 48.dp, start = 16.dp, end = 16.dp)
        ) {
            val centerX = size.width / 2f
            val centerY = size.height / 2f + 30f
            val radYaw = Math.toRadians(orbitYaw.toDouble()).toFloat()
            val radPitch = Math.toRadians(orbitPitch.toDouble()).toFloat()

            // --- 1. DRAW DYNAMIC 3D FLOOR SLAB DEPENDING ON SELECTED FLOOR ---
            val scaleFactor = 2.8f
            val floorMinX = (5f - 50f) * scaleFactor
            val floorMaxX = (95f - 50f) * scaleFactor
            val floorMinY = (5f - 50f) * scaleFactor
            val floorMaxY = (95f - 50f) * scaleFactor

            val slab0 = project3D(Point3D(floorMinX, floorMinY, -0.2f), radYaw, radPitch, zoomScale, centerX, centerY)
            val slab1 = project3D(Point3D(floorMaxX, floorMinY, -0.2f), radYaw, radPitch, zoomScale, centerX, centerY)
            val slab2 = project3D(Point3D(floorMaxX, floorMaxY, -0.2f), radYaw, radPitch, zoomScale, centerX, centerY)
            val slab3 = project3D(Point3D(floorMinX, floorMaxY, -0.2f), radYaw, radPitch, zoomScale, centerX, centerY)

            val floorPath = Path().apply {
                moveTo(slab0.x, slab0.y)
                lineTo(slab1.x, slab1.y)
                lineTo(slab2.x, slab2.y)
                lineTo(slab3.x, slab3.y)
                close()
            }

            val (slabFillColor, slabBorderColor) = when (selectedFloorId) {
                2 -> Color(0xFF064E3B) to Color(0xFF10B981) // Green for Freigelände
                0 -> Color(0xFF0F172A) to PrimaryBlue       // Dark asphalt/blue for Masterplan
                else -> Color(0xFF1E293B) to PrimaryBlue    // Blue-grey for Halle 11
            }

            drawPath(floorPath, color = slabFillColor.copy(alpha = 0.95f))
            drawPath(floorPath, color = slabBorderColor, style = Stroke(2.5f))

            // Draw 10m Grid Lines on Floor
            var gx = floorMinX
            while (gx <= floorMaxX) {
                val gp1 = project3D(Point3D(gx, floorMinY, 0f), radYaw, radPitch, zoomScale, centerX, centerY)
                val gp2 = project3D(Point3D(gx, floorMaxY, 0f), radYaw, radPitch, zoomScale, centerX, centerY)
                drawLine(Color(0xFF334155).copy(alpha = 0.4f), Offset(gp1.x, gp1.y), Offset(gp2.x, gp2.y), strokeWidth = 1f)
                gx += 25f
            }

            var gy = floorMinY
            while (gy <= floorMaxY) {
                val gp1 = project3D(Point3D(floorMinX, gy, 0f), radYaw, radPitch, zoomScale, centerX, centerY)
                val gp2 = project3D(Point3D(floorMaxX, gy, 0f), radYaw, radPitch, zoomScale, centerX, centerY)
                drawLine(Color(0xFF334155).copy(alpha = 0.4f), Offset(gp1.x, gp1.y), Offset(gp2.x, gp2.y), strokeWidth = 1f)
                gy += 25f
            }

            // --- 2. DRAW 3D PRIMITIVES WITH PAINTER'S ALGORITHM DEPTH SORTING ---
            val sortedPrimitives = primitives.sortedByDescending { prim ->
                val sf = 3.2f
                val pcx = (prim.x - 50f) * sf
                val pcy = (prim.y - 50f) * sf
                val pcz = (prim.z + prim.height / 2f) * sf
                val x1 = pcx * cos(radYaw) - pcy * sin(radYaw)
                val y1 = pcx * sin(radYaw) + pcy * cos(radYaw)
                y1 * cos(radPitch) - pcz * sin(radPitch)
            }

            sortedPrimitives.forEach { prim ->
                draw3DPrimitiveBlock(
                    primitive = prim,
                    radYaw = radYaw,
                    radPitch = radPitch,
                    zoomScale = zoomScale,
                    centerX = centerX,
                    centerY = centerY,
                    isSelected = prim.id == selectedPrimitive?.id
                )
            }

            // Draw 3D Photo Markers & View Frustums
            photoMarkers.forEach { marker ->
                draw3DCameraMarker(
                    marker = marker,
                    radYaw = radYaw,
                    radPitch = radPitch,
                    zoomScale = zoomScale,
                    centerX = centerX,
                    centerY = centerY,
                    isSelected = marker.id == selectedMarker?.id
                )
            }
        }

        // Floating 3D Controls hint & Auto-Correct
        Row(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp),
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(DarkBackground.copy(alpha = 0.8f))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.RotateRight,
                    contentDescription = "Drehen",
                    tint = OnSurfaceSubtext,
                    modifier = Modifier.size(16.dp)
                )
                Text(
                    text = "Gesten: Drehen & Zoomen",
                    style = MaterialTheme.typography.bodySmall,
                    color = OnSurfaceSubtext,
                    fontSize = 10.sp
                )
            }

            Button(
                onClick = onAutoCorrect,
                colors = ButtonDefaults.buttonColors(
                    containerColor = PrimaryContainerBlue,
                    contentColor = PrimaryBlue
                ),
                shape = RoundedCornerShape(50),
                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                modifier = Modifier.testTag("auto_correct_button")
            ) {
                Text("Auto-Korrektur", fontSize = 12.sp)
            }
        }
    }
}

// Projection helper
fun project3D(
    p: Point3D,
    radYaw: Float,
    radPitch: Float,
    zoom: Float,
    centerX: Float,
    centerY: Float
): Point2D {
    // 1. Yaw rotation around Z axis
    val x1 = p.x * cos(radYaw) - p.y * sin(radYaw)
    val y1 = p.x * sin(radYaw) + p.y * cos(radYaw)
    val z1 = p.z

    // 2. Pitch rotation around X axis
    val y2 = y1 * cos(radPitch) - z1 * sin(radPitch)
    val z2 = y1 * sin(radPitch) + z1 * cos(radPitch)

    // Perspective projection
    val focal = 350f * zoom
    val scale = focal / (focal + y2 + 150f)
    val screenX = centerX + x1 * scale
    val screenY = centerY - z2 * scale

    return Point2D(screenX, screenY)
}

fun DrawScope.draw3DPrimitiveBlock(
    primitive: StructuralPrimitive,
    radYaw: Float,
    radPitch: Float,
    zoomScale: Float,
    centerX: Float,
    centerY: Float,
    isSelected: Boolean
) {
    // Scale factor to convert 0..100 hall meters to 3D canvas space
    val scaleFactor = 3.2f

    // Convert map coordinates to centered 3D origin
    val cx = (primitive.x - 50f) * scaleFactor
    val cy = (primitive.y - 50f) * scaleFactor
    val cz = primitive.z * scaleFactor

    val halfW = (primitive.width / 2f) * scaleFactor
    val halfL = (primitive.length / 2f) * scaleFactor
    val h = (primitive.height * scaleFactor).coerceAtLeast(6f)

    val baseColor = when (primitive.type) {
        ElementType.WALL -> ElementWall
        ElementType.FLOOR -> ElementFloor
        ElementType.CEILING -> ElementCeiling
        ElementType.DOOR -> ElementDoor
        ElementType.WINDOW -> ElementWindow
        ElementType.STAIRS -> ElementStairs
        ElementType.COLUMN -> ElementColumn
    }

    // 8 vertices of box
    val v0 = Point3D(cx - halfW, cy - halfL, cz)
    val v1 = Point3D(cx + halfW, cy - halfL, cz)
    val v2 = Point3D(cx + halfW, cy + halfL, cz)
    val v3 = Point3D(cx - halfW, cy + halfL, cz)

    val v4 = Point3D(cx - halfW, cy - halfL, cz + h)
    val v5 = Point3D(cx + halfW, cy - halfL, cz + h)
    val v6 = Point3D(cx + halfW, cy + halfL, cz + h)
    val v7 = Point3D(cx - halfW, cy + halfL, cz + h)

    val p0 = project3D(v0, radYaw, radPitch, zoomScale, centerX, centerY)
    val p1 = project3D(v1, radYaw, radPitch, zoomScale, centerX, centerY)
    val p2 = project3D(v2, radYaw, radPitch, zoomScale, centerX, centerY)
    val p3 = project3D(v3, radYaw, radPitch, zoomScale, centerX, centerY)

    val p4 = project3D(v4, radYaw, radPitch, zoomScale, centerX, centerY)
    val p5 = project3D(v5, radYaw, radPitch, zoomScale, centerX, centerY)
    val p6 = project3D(v6, radYaw, radPitch, zoomScale, centerX, centerY)
    val p7 = project3D(v7, radYaw, radPitch, zoomScale, centerX, centerY)

    val strokeColor = if (isSelected) PrimaryBlue else Color.White.copy(alpha = 0.6f)
    val strokeWidth = if (isSelected) 3f else 1.5f

    // Draw Front Face (p0, p1, p5, p4)
    val pathFront = Path().apply {
        moveTo(p0.x, p0.y)
        lineTo(p1.x, p1.y)
        lineTo(p5.x, p5.y)
        lineTo(p4.x, p4.y)
        close()
    }
    drawPath(pathFront, color = baseColor.copy(alpha = 0.5f))
    drawPath(pathFront, color = strokeColor, style = Stroke(strokeWidth))

    // Draw Top Face (p4, p5, p6, p7)
    val pathTop = Path().apply {
        moveTo(p4.x, p4.y)
        lineTo(p5.x, p5.y)
        lineTo(p6.x, p6.y)
        lineTo(p7.x, p7.y)
        close()
    }
    drawPath(pathTop, color = baseColor.copy(alpha = 0.7f))
    drawPath(pathTop, color = strokeColor, style = Stroke(strokeWidth))

    // Draw Right Face (p1, p2, p6, p5)
    val pathRight = Path().apply {
        moveTo(p1.x, p1.y)
        lineTo(p2.x, p2.y)
        lineTo(p6.x, p6.y)
        lineTo(p5.x, p5.y)
        close()
    }
    drawPath(pathRight, color = baseColor.copy(alpha = 0.4f))
    drawPath(pathRight, color = strokeColor, style = Stroke(strokeWidth))

    // Draw 3D Floating Text Label above block
    if (primitive.statusNote.isNotBlank()) {
        val labelText = primitive.statusNote.split(" • ").firstOrNull() ?: primitive.statusNote
        val topCenterX = (p4.x + p6.x) / 2f
        val topCenterY = (p4.y + p6.y) / 2f - 6f

        drawContext.canvas.nativeCanvas.apply {
            val paint = android.graphics.Paint().apply {
                color = android.graphics.Color.WHITE
                textSize = if (halfW > 15f) 18f else 14f
                isFakeBoldText = true
                textAlign = android.graphics.Paint.Align.CENTER
                setShadowLayer(4f, 0f, 0f, android.graphics.Color.BLACK)
            }
            drawText(labelText, topCenterX, topCenterY, paint)
        }
    }
}

fun DrawScope.draw3DCameraMarker(
    marker: PhotoMarker,
    radYaw: Float,
    radPitch: Float,
    zoomScale: Float,
    centerX: Float,
    centerY: Float,
    isSelected: Boolean
) {
    val scaleFactor = 3.2f
    val cx = (marker.posX - 50f) * scaleFactor
    val cy = (marker.posY - 40f) * scaleFactor
    val cz = marker.posZ * scaleFactor

    val pos2D = project3D(Point3D(cx, cy, cz), radYaw, radPitch, zoomScale, centerX, centerY)

    // Direction cone
    val radCamYaw = Math.toRadians(marker.yawDegrees.toDouble()).toFloat()
    val coneLength = 12f
    val fovRad = Math.toRadians((marker.fovDegrees / 2f).toDouble()).toFloat()

    val dirX = sin(radCamYaw) * coneLength
    val dirY = cos(radCamYaw) * coneLength

    val leftX = sin(radCamYaw - fovRad) * coneLength
    val leftY = cos(radCamYaw - fovRad) * coneLength

    val rightX = sin(radCamYaw + fovRad) * coneLength
    val rightY = cos(radCamYaw + fovRad) * coneLength

    val tip2D = project3D(Point3D(cx + dirX, cy + dirY, cz), radYaw, radPitch, zoomScale, centerX, centerY)
    val left2D = project3D(Point3D(cx + leftX, cy + leftY, cz), radYaw, radPitch, zoomScale, centerX, centerY)
    val right2D = project3D(Point3D(cx + rightX, cy + rightY, cz), radYaw, radPitch, zoomScale, centerX, centerY)

    // Cone frustum
    val conePath = Path().apply {
        moveTo(pos2D.x, pos2D.y)
        lineTo(left2D.x, left2D.y)
        lineTo(right2D.x, right2D.y)
        close()
    }
    drawPath(conePath, color = OrangeAccent.copy(alpha = 0.25f))
    drawPath(conePath, color = OrangeAccent, style = Stroke(1.5f))

    // Camera Pin Dot
    drawCircle(
        color = if (isSelected) PrimaryBlue else OrangeAccent,
        radius = if (isSelected) 8f else 6f,
        center = Offset(pos2D.x, pos2D.y)
    )
}
