package com.example.ui.viewmodel

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.room.Room
import com.example.data.db.MapDatabase
import com.example.data.model.ElementType
import com.example.data.model.FloorLevel
import com.example.data.model.PhotoMarker
import com.example.data.model.StructuralPrimitive
import com.example.data.repository.MapRepository
import com.example.service.ExtractedGeometryResult
import com.example.service.GeminiArchitectureExtractor
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class MapUiState(
    val selectedFloorId: Int = 1, // Etage 1 by default
    val floors: List<FloorLevel> = emptyList(),
    val photoMarkers: List<PhotoMarker> = emptyList(),
    val primitives: List<StructuralPrimitive> = emptyList(),
    val selectedMarker: PhotoMarker? = null,
    val selectedPrimitive: StructuralPrimitive? = null,
    val selectedElementTypeToPlace: ElementType? = null,
    val isPlacementModeActive: Boolean = false,
    val pendingYawAngle: Float = 45f,
    val isAnalyzingPhoto: Boolean = false,
    val lastAnalysisResult: ExtractedGeometryResult? = null,
    val orbitYaw: Float = 35f,
    val orbitPitch: Float = 30f,
    val zoomScale: Float = 1f,
    val deviationCm: Float = 14.2f,
    val isWireframeOnly: Boolean = false,
    val activeTab: Int = 1 // 0 = Halls/2D, 1 = 3D Align/Editor, 2 = AI Photo Extract, 3 = Export/Profile
)

class MapViewModel(application: Application) : AndroidViewModel(application) {

    private val db = Room.databaseBuilder(
        application,
        MapDatabase::class.java,
        "koelnmesse_map_db"
    ).build()

    private val repository = MapRepository(db.mapDao())
    private val geminiExtractor = GeminiArchitectureExtractor(application)

    private val _uiState = MutableStateFlow(MapUiState())
    val uiState: StateFlow<MapUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            repository.initializeDefaultDataIfEmpty()
        }

        viewModelScope.launch {
            repository.floors.collect { floorList ->
                _uiState.update { it.copy(floors = floorList) }
            }
        }

        viewModelScope.launch {
            _uiState.map { it.selectedFloorId }
                .distinctUntilChanged()
                .flatMapLatest { floorId -> repository.getPhotoMarkersForFloor(floorId) }
                .collect { markers ->
                    _uiState.update { state ->
                        val currentSelected = state.selectedMarker
                        val updatedSelected = markers.find { it.id == currentSelected?.id } ?: markers.firstOrNull()
                        state.copy(photoMarkers = markers, selectedMarker = updatedSelected)
                    }
                }
        }

        viewModelScope.launch {
            _uiState.map { it.selectedFloorId }
                .distinctUntilChanged()
                .flatMapLatest { floorId -> repository.getPrimitivesForFloor(floorId) }
                .collect { prims ->
                    _uiState.update { it.copy(primitives = prims) }
                }
        }
    }

    fun selectFloor(floorId: Int) {
        _uiState.update { it.copy(selectedFloorId = floorId, selectedMarker = null, selectedPrimitive = null) }
    }

    fun selectTab(tabIndex: Int) {
        _uiState.update { it.copy(activeTab = tabIndex) }
    }

    fun selectPhotoMarker(marker: PhotoMarker?) {
        _uiState.update { it.copy(selectedMarker = marker, pendingYawAngle = marker?.yawDegrees ?: 45f) }
    }

    fun selectPrimitive(primitive: StructuralPrimitive?) {
        _uiState.update { it.copy(selectedPrimitive = primitive) }
    }

    fun togglePlacementMode(elementType: ElementType?) {
        _uiState.update {
            it.copy(
                selectedElementTypeToPlace = elementType,
                isPlacementModeActive = elementType != null
            )
        }
    }

    fun updatePendingYaw(yaw: Float) {
        _uiState.update { it.copy(pendingYawAngle = yaw) }
        val currentMarker = _uiState.value.selectedMarker
        if (currentMarker != null) {
            val updated = currentMarker.copy(yawDegrees = yaw)
            viewModelScope.launch {
                repository.addPhotoMarker(updated)
            }
        }
    }

    fun addPhotoMarkerAt(posX: Float, posY: Float, photoUri: String = "", fileName: String = "Photo_Mark.jpg") {
        viewModelScope.launch {
            val newMarker = PhotoMarker(
                floorId = _uiState.value.selectedFloorId,
                posX = posX,
                posY = posY,
                yawDegrees = _uiState.value.pendingYawAngle,
                photoUri = photoUri,
                fileName = if (photoUri.isNotEmpty()) "CAMERA_PHOTO_${System.currentTimeMillis() % 10000}.jpg" else fileName,
                hallSection = "Hall ${_uiState.value.selectedFloorId + 11}.2 Zone",
                focalLengthInfo = "24mm • Alignment Photo"
            )
            val id = repository.addPhotoMarker(newMarker)
            val created = newMarker.copy(id = id)
            _uiState.update { it.copy(selectedMarker = created, isPlacementModeActive = false, selectedElementTypeToPlace = null) }
        }
    }

    fun addPrimitiveAt(posX: Float, posY: Float, type: ElementType) {
        viewModelScope.launch {
            val newPrimitive = StructuralPrimitive(
                floorId = _uiState.value.selectedFloorId,
                type = type,
                x = posX,
                y = posY,
                z = 0f,
                width = if (type == ElementType.WALL) 10f else if (type == ElementType.COLUMN) 1.5f else 4f,
                length = if (type == ElementType.WALL) 0.4f else if (type == ElementType.COLUMN) 1.5f else 3f,
                height = if (type == ElementType.FLOOR || type == ElementType.CEILING) 0.2f else 5f,
                rotationYaw = _uiState.value.pendingYawAngle,
                isFromPhotoAi = false,
                statusNote = "Manuell platziert: ${type.label}"
            )
            val id = repository.addPrimitive(newPrimitive)
            val created = newPrimitive.copy(id = id)
            _uiState.update { it.copy(selectedPrimitive = created, isPlacementModeActive = false, selectedElementTypeToPlace = null) }
        }
    }

    fun updatePrimitive(primitive: StructuralPrimitive) {
        viewModelScope.launch {
            repository.addPrimitive(primitive)
            _uiState.update { it.copy(selectedPrimitive = primitive) }
        }
    }

    fun updateSelectedPrimitiveType(type: ElementType) {
        val selected = _uiState.value.selectedPrimitive ?: return
        val updated = selected.copy(type = type)
        updatePrimitive(updated)
    }

    fun updateSelectedPrimitiveDimensions(width: Float, length: Float, height: Float) {
        val selected = _uiState.value.selectedPrimitive ?: return
        val updated = selected.copy(width = width, length = length, height = height)
        updatePrimitive(updated)
    }

    fun updateSelectedPrimitivePosition(x: Float, y: Float, z: Float) {
        val selected = _uiState.value.selectedPrimitive ?: return
        val updated = selected.copy(x = x.coerceIn(0f, 100f), y = y.coerceIn(0f, 100f), z = z)
        updatePrimitive(updated)
    }

    fun updateSelectedPrimitiveYaw(yaw: Float) {
        val selected = _uiState.value.selectedPrimitive ?: return
        val updated = selected.copy(rotationYaw = yaw)
        updatePrimitive(updated)
    }

    fun duplicateSelectedPrimitive() {
        val selected = _uiState.value.selectedPrimitive ?: return
        viewModelScope.launch {
            val copy = selected.copy(
                id = 0,
                x = (selected.x + 3f).coerceIn(5f, 95f),
                y = (selected.y + 3f).coerceIn(5f, 95f),
                statusNote = "Kopie von ${selected.type.label}"
            )
            val newId = repository.addPrimitive(copy)
            _uiState.update { it.copy(selectedPrimitive = copy.copy(id = newId)) }
        }
    }

    fun importLod2MeshAssets() {
        viewModelScope.launch {
            val floorId = _uiState.value.selectedFloorId
            repository.loadLod2AssetsIntoDatabase(getApplication<Application>(), floorId)
        }
    }

    fun reloadStandardHallStructure() {
        viewModelScope.launch {
            val floorId = _uiState.value.selectedFloorId
            repository.reloadStandardHallStructure(floorId)
        }
    }

    fun deleteSelectedPrimitive() {
        val selected = _uiState.value.selectedPrimitive ?: return
        viewModelScope.launch {
            repository.deletePrimitive(selected)
            _uiState.update { it.copy(selectedPrimitive = null) }
        }
    }

    fun deleteSelectedMarker() {
        val selected = _uiState.value.selectedMarker ?: return
        viewModelScope.launch {
            repository.deletePhotoMarker(selected)
            _uiState.update { it.copy(selectedMarker = null) }
        }
    }

    fun updateOrbit(deltaYaw: Float, deltaPitch: Float) {
        _uiState.update {
            val newYaw = (it.orbitYaw + deltaYaw) % 360f
            val newPitch = (it.orbitPitch + deltaPitch).coerceIn(10f, 85f)
            it.copy(orbitYaw = newYaw, orbitPitch = newPitch)
        }
    }

    fun updateZoom(zoomFactor: Float) {
        _uiState.update {
            val newZoom = (it.zoomScale * zoomFactor).coerceIn(0.5f, 3.0f)
            it.copy(zoomScale = newZoom)
        }
    }

    fun autoCorrectAlignment() {
        viewModelScope.launch {
            val currentDev = _uiState.value.deviationCm
            val correctedDev = (currentDev * 0.3f).coerceAtLeast(1.8f)
            _uiState.update { it.copy(deviationCm = correctedDev) }
        }
    }

    fun analyzePhotoForArchitecture(photoUri: Uri?) {
        viewModelScope.launch {
            _uiState.update { it.copy(isAnalyzingPhoto = true) }
            val currentFloor = _uiState.value.selectedFloorId
            val marker = _uiState.value.selectedMarker
            val baseX = marker?.posX ?: 40f
            val baseY = marker?.posY ?: 40f

            val result = geminiExtractor.analyzePhotoAndExtractArchitecture(photoUri, currentFloor, baseX, baseY)
            _uiState.update {
                it.copy(
                    isAnalyzingPhoto = false,
                    lastAnalysisResult = result
                )
            }
        }
    }

    fun acceptExtractedPrimitives() {
        val result = _uiState.value.lastAnalysisResult ?: return
        viewModelScope.launch {
            repository.addPrimitives(result.extractedElements)
            _uiState.update {
                it.copy(
                    lastAnalysisResult = null,
                    deviationCm = result.deviationCm,
                    activeTab = 1 // Switch back to 3D alignment view
                )
            }
        }
    }
}
