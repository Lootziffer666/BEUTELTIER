package com.example.ui.components

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.Upload
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.PhotoMarker
import com.example.ui.theme.*

@Composable
fun PhotoReferenceCard(
    selectedMarker: PhotoMarker?,
    isAnalyzing: Boolean,
    onAnalyzePhoto: (Uri?) -> Unit,
    modifier: Modifier = Modifier
) {
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            onAnalyzePhoto(uri)
        }
    }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(160.dp)
            .clip(RoundedCornerShape(24.dp))
            .background(DarkSurface)
            .border(1.dp, DarkOutline, RoundedCornerShape(24.dp))
            .testTag("photo_reference_card")
    ) {
        // Photo Image or Simulated Mesh Overlay
        if (selectedMarker?.photoUri?.isNotEmpty() == true) {
            AsyncImage(
                model = selectedMarker.photoUri,
                contentDescription = "Foto Referenz",
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        } else {
            // Simulated mesh pattern placeholder
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(DarkBackground.copy(alpha = 0.5f)),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = Icons.Default.PhotoCamera,
                    contentDescription = "Referenzfoto",
                    tint = OnSurfaceSubtext,
                    modifier = Modifier.size(28.dp)
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = selectedMarker?.fileName ?: "IMG_2024_08_24_KOELN_HALL11.jpg",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurface,
                    fontSize = 13.sp
                )
                Text(
                    text = selectedMarker?.focalLengthInfo ?: "Brennweite: 24mm • ${selectedMarker?.hallSection ?: "Halle 11 Nord"}",
                    style = MaterialTheme.typography.bodySmall,
                    color = OnSurfaceSubtext,
                    fontSize = 11.sp
                )
            }
        }

        // Photo Source Badge
        Row(
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(12.dp)
                .clip(RoundedCornerShape(50))
                .background(DarkBackground.copy(alpha = 0.85f))
                .border(1.dp, DarkOutline, RoundedCornerShape(50))
                .padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Icon(
                imageVector = Icons.Default.PhotoCamera,
                contentDescription = "Photo Source",
                tint = OrangeAccent,
                modifier = Modifier.size(12.dp)
            )
            Text(
                text = "FOTO-QUELLE",
                style = MaterialTheme.typography.labelSmall,
                color = OrangeAccent,
                fontSize = 10.sp
            )
        }

        // AI Architecture Extraction Button
        Row(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedButton(
                onClick = { photoPickerLauncher.launch("image/*") },
                shape = RoundedCornerShape(50),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.onSurface),
                border = ButtonDefaults.outlinedButtonBorder.copy(brush = androidx.compose.ui.graphics.SolidColor(DarkOutline)),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                modifier = Modifier.testTag("upload_photo_button")
            ) {
                Icon(Icons.Default.Upload, contentDescription = "Foto laden", modifier = Modifier.size(14.dp))
                Spacer(Modifier.width(4.dp))
                Text("Foto wählen", fontSize = 11.sp)
            }

            Button(
                onClick = { onAnalyzePhoto(null) },
                enabled = !isAnalyzing,
                shape = RoundedCornerShape(50),
                colors = ButtonDefaults.buttonColors(
                    containerColor = PrimaryContainerBlue,
                    contentColor = PrimaryBlue
                ),
                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                modifier = Modifier.testTag("extract_architecture_button")
            ) {
                if (isAnalyzing) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(14.dp),
                        color = PrimaryBlue,
                        strokeWidth = 2.dp
                    )
                    Spacer(Modifier.width(6.dp))
                    Text("Analysiere...", fontSize = 11.sp)
                } else {
                    Icon(Icons.Default.AutoAwesome, contentDescription = "KI Extrakt", modifier = Modifier.size(14.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("Architektur ableiten", fontSize = 11.sp)
                }
            }
        }
    }
}
