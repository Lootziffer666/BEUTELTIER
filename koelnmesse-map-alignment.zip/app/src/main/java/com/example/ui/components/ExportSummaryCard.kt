package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.ViewInAr
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.PhotoMarker
import com.example.data.model.StructuralPrimitive
import com.example.ui.theme.*

@Composable
fun ExportSummaryCard(
    primitives: List<StructuralPrimitive>,
    photoMarkers: List<PhotoMarker>,
    deviationCm: Float,
    modifier: Modifier = Modifier
) {
    val clipboardManager = LocalClipboardManager.current
    var isCopied by remember { mutableStateOf(false) }

    val jsonExport = remember(primitives, photoMarkers) {
        """
        {
          "project": "Koelnmesse Gamescom 3D Refiner",
          "hall": "Halle 11 (2 Etagen)",
          "deviationCm": $deviationCm,
          "photoMarkersCount": ${photoMarkers.size},
          "primitivesCount": ${primitives.size},
          "primitives": [
            ${primitives.joinToString(",\n            ") { prim ->
                "{\"id\": ${prim.id}, \"floorId\": ${prim.floorId}, \"type\": \"${prim.type.name}\", \"x\": ${prim.x}, \"y\": ${prim.y}, \"z\": ${prim.z}, \"width\": ${prim.width}, \"height\": ${prim.height}, \"source\": \"${if (prim.isFromPhotoAi) "KI_EXTRAKT" else "MANUELL"}\"}"
            }}
          ]
        }
        """.trimIndent()
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .background(DarkSurface)
            .border(1.dp, DarkOutline, RoundedCornerShape(24.dp))
            .padding(16.dp)
            .testTag("export_summary_card")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.ViewInAr,
                    contentDescription = "Mesh Export",
                    tint = PrimaryBlue,
                    modifier = Modifier.size(20.dp)
                )
                Text(
                    text = "3D Modell Export & JSON Mesh",
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }

            Button(
                onClick = {
                    clipboardManager.setText(AnnotatedString(jsonExport))
                    isCopied = true
                },
                shape = RoundedCornerShape(50),
                colors = ButtonDefaults.buttonColors(
                    containerColor = PrimaryContainerBlue,
                    contentColor = PrimaryBlue
                ),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                modifier = Modifier.testTag("copy_json_export_button")
            ) {
                Icon(
                    imageVector = if (isCopied) Icons.Default.Download else Icons.Default.ContentCopy,
                    contentDescription = "Kopieren",
                    modifier = Modifier.size(14.dp)
                )
                Spacer(Modifier.width(4.dp))
                Text(if (isCopied) "Kopiert!" else "JSON Kopieren", fontSize = 11.sp)
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Session Statistics
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            StatBox(
                title = "Platzierte Fotos",
                value = "${photoMarkers.size}",
                modifier = Modifier.weight(1f)
            )
            StatBox(
                title = "3D Bausteine",
                value = "${primitives.size}",
                modifier = Modifier.weight(1f)
            )
            StatBox(
                title = "Präzision",
                value = "${String.format("%.1f", deviationCm)} cm",
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Code Box Preview
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(120.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(DarkBackground)
                .border(1.dp, DarkOutline, RoundedCornerShape(12.dp))
                .padding(10.dp)
        ) {
            Text(
                text = jsonExport,
                style = MaterialTheme.typography.bodySmall,
                color = OnSurfaceSubtext,
                fontSize = 10.sp
            )
        }
    }
}

@Composable
fun StatBox(title: String, value: String, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(DarkBackground)
            .border(1.dp, DarkOutline, RoundedCornerShape(12.dp))
            .padding(10.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = value,
                style = MaterialTheme.typography.titleMedium,
                color = PrimaryBlue,
                fontSize = 16.sp
            )
            Text(
                text = title,
                style = MaterialTheme.typography.bodySmall,
                color = OnSurfaceSubtext,
                fontSize = 10.sp
            )
        }
    }
}
