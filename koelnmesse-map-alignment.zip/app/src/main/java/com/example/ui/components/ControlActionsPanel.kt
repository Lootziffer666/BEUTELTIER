package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ElementType
import com.example.data.model.StructuralPrimitive
import com.example.ui.theme.*

@Composable
fun ControlActionsPanel(
    selectedPrimitive: StructuralPrimitive?,
    onDeletePrimitive: () -> Unit,
    onBakeTexture: () -> Unit,
    onPlaneDetection: () -> Unit,
    onExportMesh: () -> Unit,
    onImportLod2Assets: (() -> Unit)? = null,
    onReloadStandardHallRooms: (() -> Unit)? = null,
    onDuplicatePrimitive: (() -> Unit)? = null,
    onUpdatePrimitivePosition: ((Float, Float, Float) -> Unit)? = null,
    onUpdatePrimitiveDimensions: ((Float, Float, Float) -> Unit)? = null,
    onUpdatePrimitiveYaw: ((Float) -> Unit)? = null,
    onUpdatePrimitiveType: ((ElementType) -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .background(DarkSurface)
            .border(1.dp, DarkOutline, RoundedCornerShape(24.dp))
            .padding(16.dp)
            .testTag("control_actions_panel")
    ) {
        // Selected primitive details banner & interactive editor controls
        if (selectedPrimitive != null) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(DarkBackground)
                    .border(1.dp, DarkOutline, RoundedCornerShape(16.dp))
                    .padding(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Ausgewählt: ${selectedPrimitive.type.label} (ID #${selectedPrimitive.id})",
                            style = MaterialTheme.typography.titleSmall,
                            color = PrimaryBlue,
                            fontSize = 13.sp
                        )
                        Text(
                            text = "Pos: (${selectedPrimitive.x.toInt()}m, ${selectedPrimitive.y.toInt()}m, ${selectedPrimitive.z.toInt()}m) • Size: ${selectedPrimitive.width.toInt()}m × ${selectedPrimitive.length.toInt()}m × ${selectedPrimitive.height.toInt()}m",
                            style = MaterialTheme.typography.bodySmall,
                            color = OnSurfaceSubtext,
                            fontSize = 10.sp
                        )
                    }
                    Row {
                        if (onDuplicatePrimitive != null) {
                            IconButton(
                                onClick = onDuplicatePrimitive,
                                modifier = Modifier.testTag("duplicate_primitive_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.ContentCopy,
                                    contentDescription = "Duplizieren",
                                    tint = PrimaryBlue,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                        IconButton(
                            onClick = onDeletePrimitive,
                            modifier = Modifier.testTag("delete_primitive_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Delete,
                                contentDescription = "Löschen",
                                tint = MaterialTheme.colorScheme.error,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Interactive Element Type Selector Buttons
                Text(
                    text = "Elementtyp ändern:",
                    style = MaterialTheme.typography.labelSmall,
                    color = OnSurfaceSubtext,
                    fontSize = 10.sp
                )
                Spacer(modifier = Modifier.height(4.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    ElementType.entries.forEach { type ->
                        val isSel = selectedPrimitive.type == type
                        FilterChip(
                            selected = isSel,
                            onClick = { onUpdatePrimitiveType?.invoke(type) },
                            label = { Text(type.label, fontSize = 9.sp) },
                            modifier = Modifier.height(28.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Quick Move Position Sliders / Adjustment Controls
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("X: ${selectedPrimitive.x.toInt()}m", color = OnSurfaceSubtext, fontSize = 10.sp)
                    Slider(
                        value = selectedPrimitive.x,
                        onValueChange = { newX ->
                            onUpdatePrimitivePosition?.invoke(newX, selectedPrimitive.y, selectedPrimitive.z)
                        },
                        valueRange = 0f..100f,
                        modifier = Modifier.weight(1f)
                    )

                    Text("Y: ${selectedPrimitive.y.toInt()}m", color = OnSurfaceSubtext, fontSize = 10.sp)
                    Slider(
                        value = selectedPrimitive.y,
                        onValueChange = { newY ->
                            onUpdatePrimitivePosition?.invoke(selectedPrimitive.x, newY, selectedPrimitive.z)
                        },
                        valueRange = 0f..100f,
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Breite: ${selectedPrimitive.width.toInt()}m", color = OnSurfaceSubtext, fontSize = 10.sp)
                    Slider(
                        value = selectedPrimitive.width,
                        onValueChange = { newW ->
                            onUpdatePrimitiveDimensions?.invoke(newW, selectedPrimitive.length, selectedPrimitive.height)
                        },
                        valueRange = 1f..50f,
                        modifier = Modifier.weight(1f)
                    )

                    Text("Höhe: ${selectedPrimitive.height.toInt()}m", color = OnSurfaceSubtext, fontSize = 10.sp)
                    Slider(
                        value = selectedPrimitive.height,
                        onValueChange = { newH ->
                            onUpdatePrimitiveDimensions?.invoke(selectedPrimitive.width, selectedPrimitive.length, newH)
                        },
                        valueRange = 1f..20f,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // Action Grid Buttons
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            ActionTile(
                icon = Icons.Default.MeetingRoom,
                title = "Standard-Layout",
                onClick = { onReloadStandardHallRooms?.invoke() },
                modifier = Modifier
                    .weight(1f)
                    .testTag("action_reload_hall_rooms")
            )
            ActionTile(
                icon = Icons.Default.CloudDownload,
                title = "LoD2 GML",
                onClick = { onImportLod2Assets?.invoke() },
                modifier = Modifier
                    .weight(1f)
                    .testTag("action_import_lod2_assets")
            )
            ActionTile(
                icon = Icons.Default.Texture,
                title = "Textur Backen",
                onClick = onBakeTexture,
                modifier = Modifier
                    .weight(1f)
                    .testTag("action_bake_texture")
            )
            ActionTile(
                icon = Icons.Default.Architecture,
                title = "Ebenen",
                onClick = onPlaneDetection,
                modifier = Modifier
                    .weight(1f)
                    .testTag("action_plane_detection")
            )
            ActionTile(
                icon = Icons.Default.Share,
                title = "Mesh Export",
                onClick = onExportMesh,
                modifier = Modifier
                    .weight(1f)
                    .testTag("action_export_mesh")
            )
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Structural Legend Bar
        Text(
            text = "3D Legende (Flächen & Architektur)",
            style = MaterialTheme.typography.labelMedium,
            color = OnSurfaceSubtext,
            fontSize = 11.sp,
            modifier = Modifier.padding(bottom = 8.dp)
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            LegendItem("Wand", ElementWall)
            LegendItem("Boden", ElementFloor)
            LegendItem("Decke", ElementCeiling)
            LegendItem("Tür", ElementDoor)
            LegendItem("Fenster", ElementWindow)
            LegendItem("Treppe", ElementStairs)
            LegendItem("Säule", ElementColumn)
        }
    }
}

@Composable
fun LegendItem(label: String, color: androidx.compose.ui.graphics.Color) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Box(
            modifier = Modifier
                .size(10.dp)
                .clip(CircleShape)
                .background(color)
        )
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall,
            color = OnSurfaceText,
            fontSize = 10.sp
        )
    }
}

@Composable
fun ActionTile(
    icon: ImageVector,
    title: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(DarkBackground)
            .border(1.dp, DarkOutline, RoundedCornerShape(16.dp))
            .clickable { onClick() }
            .padding(vertical = 12.dp, horizontal = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = PrimaryBlue,
                modifier = Modifier
                    .size(20.dp)
                    .padding(bottom = 2.dp)
            )
            Text(
                text = title,
                style = MaterialTheme.typography.labelSmall,
                color = OnSurfaceSubtext,
                fontSize = 9.sp
            )
        }
    }
}
