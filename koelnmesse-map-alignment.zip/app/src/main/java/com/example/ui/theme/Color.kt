package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val DarkBackground = Color(0xFF1A1C1E)
val DarkSurface = Color(0xFF2D3033)
val DarkOutline = Color(0xFF43474E)
val PrimaryBlue = Color(0xFFD0E4FF)
val PrimaryContainerBlue = Color(0xFF004A77)
val OnPrimaryBlue = Color(0xFF003254)
val OnSurfaceText = Color(0xFFE2E2E6)
val OnSurfaceSubtext = Color(0xFFC2C7CF)
val OrangeAccent = Color(0xFFFB8C00)

// Structural Element Legend Colors
val ElementWall = Color(0xFF90A4AE)
val ElementFloor = Color(0xFF37474F)
val ElementCeiling = Color(0xFF546E7A)
val ElementDoor = Color(0xFF66BB6A)
val ElementWindow = Color(0xFF26C6DA)
val ElementStairs = Color(0xFFFFA726)
val ElementColumn = Color(0xFFAB47BC)
