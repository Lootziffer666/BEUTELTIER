package com.example.data.db

import androidx.room.*
import com.example.data.model.ElementType
import com.example.data.model.FloorLevel
import com.example.data.model.PhotoMarker
import com.example.data.model.StructuralPrimitive
import kotlinx.coroutines.flow.Flow

class Converters {
    @TypeConverter
    fun fromElementType(type: ElementType): String = type.name

    @TypeConverter
    fun toElementType(value: String): ElementType = try {
        ElementType.valueOf(value)
    } catch (e: Exception) {
        ElementType.WALL
    }
}

@Dao
interface MapDao {
    @Query("SELECT * FROM floor_levels ORDER BY id ASC")
    fun getAllFloors(): Flow<List<FloorLevel>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFloor(floor: FloorLevel)

    @Query("SELECT * FROM photo_markers WHERE floorId = :floorId ORDER BY id DESC")
    fun getPhotoMarkersForFloor(floorId: Int): Flow<List<PhotoMarker>>

    @Query("SELECT * FROM photo_markers ORDER BY id DESC")
    fun getAllPhotoMarkers(): Flow<List<PhotoMarker>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPhotoMarker(marker: PhotoMarker): Long

    @Delete
    suspend fun deletePhotoMarker(marker: PhotoMarker)

    @Query("SELECT * FROM structural_primitives WHERE floorId = :floorId")
    fun getPrimitivesForFloor(floorId: Int): Flow<List<StructuralPrimitive>>

    @Query("SELECT * FROM structural_primitives")
    fun getAllPrimitives(): Flow<List<StructuralPrimitive>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPrimitive(primitive: StructuralPrimitive): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPrimitives(primitives: List<StructuralPrimitive>)

    @Delete
    suspend fun deletePrimitive(primitive: StructuralPrimitive)

    @Query("DELETE FROM structural_primitives WHERE floorId = :floorId")
    suspend fun clearPrimitivesForFloor(floorId: Int)
}

@Database(
    entities = [FloorLevel::class, PhotoMarker::class, StructuralPrimitive::class],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class MapDatabase : RoomDatabase() {
    abstract fun mapDao(): MapDao
}
