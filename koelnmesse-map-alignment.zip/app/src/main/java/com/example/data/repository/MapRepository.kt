package com.example.data.repository

import android.content.Context
import com.example.data.db.MapDao
import com.example.data.model.ElementType
import com.example.data.model.FloorLevel
import com.example.data.model.PhotoMarker
import com.example.data.model.StructuralPrimitive
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first

class MapRepository(private val mapDao: MapDao) {

    val floors: Flow<List<FloorLevel>> = mapDao.getAllFloors()
    val allPhotoMarkers: Flow<List<PhotoMarker>> = mapDao.getAllPhotoMarkers()
    val allPrimitives: Flow<List<StructuralPrimitive>> = mapDao.getAllPrimitives()

    fun getPhotoMarkersForFloor(floorId: Int): Flow<List<PhotoMarker>> =
        mapDao.getPhotoMarkersForFloor(floorId)

    fun getPrimitivesForFloor(floorId: Int): Flow<List<StructuralPrimitive>> =
        mapDao.getPrimitivesForFloor(floorId)

    suspend fun addPhotoMarker(marker: PhotoMarker): Long = mapDao.insertPhotoMarker(marker)

    suspend fun deletePhotoMarker(marker: PhotoMarker) = mapDao.deletePhotoMarker(marker)

    suspend fun addPrimitive(primitive: StructuralPrimitive): Long = mapDao.insertPrimitive(primitive)

    suspend fun addPrimitives(primitives: List<StructuralPrimitive>) = mapDao.insertPrimitives(primitives)

    suspend fun deletePrimitive(primitive: StructuralPrimitive) = mapDao.deletePrimitive(primitive)

    suspend fun loadLod2AssetsIntoDatabase(context: Context, floorId: Int): Int {
        val loader = com.example.service.Lod2AssetLoader(context)
        val primitives = loader.loadLod2PrimitivesFromAssets(floorId)
        if (primitives.isNotEmpty()) {
            mapDao.insertPrimitives(primitives)
        }
        return primitives.size
    }

    suspend fun reloadStandardHallStructure(floorId: Int) {
        mapDao.clearPrimitivesForFloor(floorId)
        val primitives = when (floorId) {
            0 -> getKoelnmesseMasterplanPrimitives()
            1 -> getHalle11RealPrimitives()
            2 -> getOutdoorCentralParkPrimitives()
            else -> getHalle11RealPrimitives()
        }
        mapDao.insertPrimitives(primitives)
    }

    fun getKoelnmesseMasterplanPrimitives(): List<StructuralPrimitive> {
        val floorId = 0
        return listOf(
            // --- KOELNMESSE MAIN HALLS 1 to 11 (Geographic OpenStreetMap Alignment) ---
            // NORTH ROW (y = 18)
            StructuralPrimitive(floorId = floorId, type = ElementType.WALL, x = 18f, y = 18f, z = 0f, width = 18f, length = 16f, height = 7f, statusNote = "Halle 8 • Entertainment Zone"),
            StructuralPrimitive(floorId = floorId, type = ElementType.WALL, x = 45f, y = 18f, z = 0f, width = 22f, length = 16f, height = 7f, statusNote = "Halle 9 • Main Exhibition"),
            StructuralPrimitive(floorId = floorId, type = ElementType.WALL, x = 76f, y = 20f, z = 0f, width = 22f, length = 20f, height = 8f, statusNote = "Halle 10 • Indie Area & Merchandise"),

            // WEST SIDE (x = 18)
            StructuralPrimitive(floorId = floorId, type = ElementType.WALL, x = 18f, y = 40f, z = 0f, width = 18f, length = 16f, height = 7f, statusNote = "Halle 7 • Gamescom Hall"),
            StructuralPrimitive(floorId = floorId, type = ElementType.WALL, x = 18f, y = 62f, z = 0f, width = 18f, length = 16f, height = 7f, statusNote = "Halle 6 • Gamescom Hall"),

            // SOUTH WEST CORNER (Eingang Süd)
            StructuralPrimitive(floorId = floorId, type = ElementType.WALL, x = 20f, y = 84f, z = 0f, width = 20f, length = 18f, height = 8f, statusNote = "Halle 11 • Eingang Süd & Signing Area"),

            // SOUTH ROW (y = 84)
            StructuralPrimitive(floorId = floorId, type = ElementType.WALL, x = 44f, y = 84f, z = 0f, width = 18f, length = 16f, height = 7f, statusNote = "Halle 3 • Messehalle Süd"),
            StructuralPrimitive(floorId = floorId, type = ElementType.WALL, x = 65f, y = 84f, z = 0f, width = 16f, length = 16f, height = 7f, statusNote = "Halle 2 • Messehalle Süd"),
            StructuralPrimitive(floorId = floorId, type = ElementType.WALL, x = 85f, y = 84f, z = 0f, width = 16f, length = 16f, height = 7f, statusNote = "Halle 1 • Eventhalle"),

            // EAST SIDE (x = 78)
            StructuralPrimitive(floorId = floorId, type = ElementType.WALL, x = 78f, y = 43f, z = 0f, width = 18f, length = 14f, height = 7f, statusNote = "Halle 5 • Messehalle Ost"),
            StructuralPrimitive(floorId = floorId, type = ElementType.WALL, x = 78f, y = 62f, z = 0f, width = 18f, length = 14f, height = 7f, statusNote = "Halle 4 • Messehalle Ost"),

            // MAIN CONNECTING BOULEVARD
            StructuralPrimitive(floorId = floorId, type = ElementType.FLOOR, x = 32f, y = 51f, z = 0.2f, width = 6f, length = 46f, height = 3.5f, statusNote = "Messeplatz Central Boulevard"),

            // OUTDOOR / AUSSENBEREICHE
            StructuralPrimitive(floorId = floorId, type = ElementType.FLOOR, x = 52f, y = 45f, z = 0f, width = 24f, length = 20f, height = 0.2f, statusNote = "Freigelände • Central Park Gamescom"),
            StructuralPrimitive(floorId = floorId, type = ElementType.STAIRS, x = 52f, y = 37f, z = 0f, width = 10f, length = 6f, height = 2.5f, statusNote = "Outdoor Event Stage"),
            StructuralPrimitive(floorId = floorId, type = ElementType.FLOOR, x = 52f, y = 62f, z = 0f, width = 20f, length = 10f, height = 0.2f, statusNote = "Freigelände • Outdoor Piazza"),
            StructuralPrimitive(floorId = floorId, type = ElementType.FLOOR, x = 20f, y = 96f, z = 0f, width = 20f, length = 6f, height = 0.2f, statusNote = "Vorplatz Eingang Süd")
        )
    }

    fun getHalle11RealPrimitives(): List<StructuralPrimitive> {
        val floorId = 1
        return listOf(
            // Outer envelope walls Halle 11
            StructuralPrimitive(floorId = floorId, type = ElementType.WALL, x = 50f, y = 10f, z = 0f, width = 80f, length = 0.8f, height = 7f, statusNote = "Nordwand Halle 11 (Durchgang Halle 10)"),
            StructuralPrimitive(floorId = floorId, type = ElementType.WALL, x = 50f, y = 80f, z = 0f, width = 80f, length = 0.8f, height = 7f, statusNote = "Südwand Halle 11 (Eingang Süd)"),
            StructuralPrimitive(floorId = floorId, type = ElementType.WALL, x = 10f, y = 45f, z = 0f, width = 0.8f, length = 70f, height = 7f, statusNote = "Westwand Halle 11"),
            StructuralPrimitive(floorId = floorId, type = ElementType.WALL, x = 90f, y = 45f, z = 0f, width = 0.8f, length = 70f, height = 7f, statusNote = "Ostwand Halle 11"),

            // --- EINGANG SÜD & DREHKREUZ-EINLASS (TURNSTILES) ---
            StructuralPrimitive(floorId = floorId, type = ElementType.DOOR, x = 50f, y = 80f, z = 0f, width = 20f, length = 1.2f, height = 4.5f, statusNote = "Haupteingang Süd • Einlass"),
            StructuralPrimitive(floorId = floorId, type = ElementType.WALL, x = 50f, y = 72f, z = 0f, width = 45f, length = 0.8f, height = 3.0f, statusNote = "Drehkreuz & Ticket-Kontrollschleuse"),
            StructuralPrimitive(floorId = floorId, type = ElementType.COLUMN, x = 80f, y = 72f, z = 0f, width = 4f, length = 3f, height = 3.5f, statusNote = "Info & Security Desk Süd"),

            // --- SIGNING AREA & SOCIAL CC (GAMESCOM SIGNING ZONE) ---
            StructuralPrimitive(floorId = floorId, type = ElementType.FLOOR, x = 35f, y = 40f, z = 0.1f, width = 38f, length = 35f, height = 0.3f, statusNote = "Gamescom Signing Area & Social CC Zone"),
            StructuralPrimitive(floorId = floorId, type = ElementType.COLUMN, x = 20f, y = 28f, z = 0f, width = 2f, length = 2f, height = 6f, statusNote = "Signing Line Abgrenzung C1"),
            StructuralPrimitive(floorId = floorId, type = ElementType.COLUMN, x = 45f, y = 28f, z = 0f, width = 2f, length = 2f, height = 6f, statusNote = "Signing Line Abgrenzung C2"),
            StructuralPrimitive(floorId = floorId, type = ElementType.COLUMN, x = 20f, y = 52f, z = 0f, width = 2f, length = 2f, height = 6f, statusNote = "Signing Line Abgrenzung C3"),
            StructuralPrimitive(floorId = floorId, type = ElementType.COLUMN, x = 45f, y = 52f, z = 0f, width = 2f, length = 2f, height = 6f, statusNote = "Signing Line Abgrenzung C4"),

            // --- BOULEVARD PASSAGE & ROLLTREPPEN ---
            StructuralPrimitive(floorId = floorId, type = ElementType.DOOR, x = 50f, y = 10f, z = 0f, width = 16f, length = 1.2f, height = 5f, statusNote = "Nord-Durchgang zum Boulevard & Halle 10"),
            StructuralPrimitive(floorId = floorId, type = ElementType.STAIRS, x = 75f, y = 45f, z = 0f, width = 8f, length = 16f, height = 6.5f, statusNote = "Rolltreppe zu Halle 11.1 / 11.3")
        )
    }

    fun getOutdoorCentralParkPrimitives(): List<StructuralPrimitive> {
        val floorId = 2
        return listOf(
            // Central Park Green Lawn Ground
            StructuralPrimitive(floorId = floorId, type = ElementType.FLOOR, x = 50f, y = 45f, z = 0f, width = 80f, length = 60f, height = 0.2f, statusNote = "Central Park Freigelände P1/P2"),
            // Foodtruck & Catering Meile
            StructuralPrimitive(floorId = floorId, type = ElementType.COLUMN, x = 25f, y = 30f, z = 0f, width = 16f, length = 8f, height = 3.5f, statusNote = "Foodtruck Street & Drinks"),
            // Red Bull Outdoor Stage & Stunt Zone
            StructuralPrimitive(floorId = floorId, type = ElementType.STAIRS, x = 72f, y = 30f, z = 0f, width = 18f, length = 12f, height = 4.0f, statusNote = "Gamescom Outdoor Show-Bühne"),
            // Outdoor Chill & Rest Pavilion
            StructuralPrimitive(floorId = floorId, type = ElementType.FLOOR, x = 50f, y = 65f, z = 0.2f, width = 30f, length = 14f, height = 3.0f, statusNote = "Outdoor Lounge & Sitzbereich"),
            // Direct Walkway to Halle 6/7
            StructuralPrimitive(floorId = floorId, type = ElementType.DOOR, x = 12f, y = 45f, z = 0f, width = 2f, length = 12f, height = 4f, statusNote = "Zugang Halle 6 / Halle 7"),
            // Direct Walkway to Halle 10
            StructuralPrimitive(floorId = floorId, type = ElementType.DOOR, x = 88f, y = 45f, z = 0f, width = 2f, length = 12f, height = 4f, statusNote = "Zugang Halle 10")
        )
    }

    suspend fun initializeDefaultDataIfEmpty() {
        val floor0 = FloorLevel(0, "Messegelände", "Koelnmesse Masterplan • Hallen 1–11 & Außenbereiche")
        val floor1 = FloorLevel(1, "Halle 11", "Halle 11 • Eingang Süd & Signing Area / Social CC")
        val floor2 = FloorLevel(2, "Freigelände", "Central Park & Outdoor Event Plaza")
        mapDao.insertFloor(floor0)
        mapDao.insertFloor(floor1)
        mapDao.insertFloor(floor2)

        val markers = allPhotoMarkers.first()
        if (markers.isEmpty()) {
            val sampleMarker1 = PhotoMarker(
                floorId = 1,
                posX = 50f,
                posY = 75f,
                posZ = 1.6f,
                yawDegrees = 0f,
                fileName = "IMG_2024_08_24_EINGANG_SUED.jpg",
                hallSection = "Halle 11 • Eingang Süd Einlass",
                focalLengthInfo = "24mm • Wide Angle"
            )
            val sampleMarker2 = PhotoMarker(
                floorId = 1,
                posX = 35f,
                posY = 40f,
                posZ = 1.6f,
                yawDegrees = 90f,
                fileName = "IMG_2024_08_24_SIGNING_AREA.jpg",
                hallSection = "Halle 11 • Signing Area & Social CC",
                focalLengthInfo = "18mm • Ultrawide"
            )
            mapDao.insertPhotoMarker(sampleMarker1)
            mapDao.insertPhotoMarker(sampleMarker2)
        }

        // Always reload clean, non-overlapping structure for all 3 areas
        reloadStandardHallStructure(0)
        reloadStandardHallStructure(1)
        reloadStandardHallStructure(2)
    }
}
