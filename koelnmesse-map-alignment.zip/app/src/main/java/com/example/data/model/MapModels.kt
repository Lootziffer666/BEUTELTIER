package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class ElementType(val label: String, val iconName: String) {
    WALL("Wand", "border_outer"),
    FLOOR("Boden", "texture"),
    CEILING("Decke", "grid_view"),
    DOOR("Tür", "sensor_door"),
    WINDOW("Fenster", "window"),
    STAIRS("Treppe/Rolltreppe", "stairs"),
    COLUMN("Säule", "view_column")
}

@Entity(tableName = "floor_levels")
data class FloorLevel(
    @PrimaryKey val id: Int, // 0 = Etage 0 (Halle 11.1), 1 = Etage 1 (Halle 11.2)
    val name: String,
    val subtitle: String,
    val widthMeters: Float = 120f,
    val heightMeters: Float = 80f,
    val floorHeightMeters: Float = 6.5f
)

@Entity(tableName = "photo_markers")
data class PhotoMarker(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val floorId: Int, // 0 or 1
    val posX: Float, // Map X coordinates (meters)
    val posY: Float, // Map Y coordinates (meters)
    val posZ: Float = 1.6f, // Eye height
    val yawDegrees: Float = 0f, // Direction angle (0 = North, 90 = East, etc)
    val pitchDegrees: Float = 0f,
    val fovDegrees: Float = 70f,
    val photoUri: String = "",
    val fileName: String = "",
    val hallSection: String = "Hall 11.2 • Gamescom Section",
    val focalLengthInfo: String = "24mm • Wide Angle",
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "structural_primitives")
data class StructuralPrimitive(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val floorId: Int,
    val type: ElementType,
    val x: Float,
    val y: Float,
    val z: Float = 0f,
    val width: Float = 2f,
    val length: Float = 0.3f,
    val height: Float = 3f,
    val rotationYaw: Float = 0f,
    val isFromPhotoAi: Boolean = false,
    val statusNote: String = "Manual Alignment"
)
