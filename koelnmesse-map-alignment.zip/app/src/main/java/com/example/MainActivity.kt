package com.example

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.*
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.KoelnmesseTheme
import com.example.ui.viewmodel.MapViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: MapViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            KoelnmesseTheme {
                val uiState by viewModel.uiState.collectAsStateWithLifecycle()
                val snackbarHostState = remember { SnackbarHostState() }
                val context = LocalContext.current

                // Show AI extracted blocks dialog if present
                if (uiState.lastAnalysisResult != null) {
                    ArchitectureAiDialog(
                        result = uiState.lastAnalysisResult!!,
                        onAccept = {
                            viewModel.acceptExtractedPrimitives()
                            Toast.makeText(context, "3D Architektur-Bausteine in Karte eingefügt!", Toast.LENGTH_SHORT).show()
                        },
                        onDismiss = {
                            viewModel.acceptExtractedPrimitives()
                        }
                    )
                }

                Scaffold(
                    topBar = {
                        TopHeader(
                            floors = uiState.floors,
                            selectedFloorId = uiState.selectedFloorId,
                            onFloorSelected = { viewModel.selectFloor(it) }
                        )
                    },
                    bottomBar = {
                        BottomNavBar(
                            selectedTab = uiState.activeTab,
                            onTabSelected = { viewModel.selectTab(it) }
                        )
                    },
                    snackbarHost = { SnackbarHost(snackbarHostState) },
                    containerColor = DarkBackground,
                    contentWindowInsets = WindowInsets.safeDrawing
                ) { innerPadding ->
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                            .background(DarkBackground)
                            .verticalScroll(rememberScrollState())
                            .padding(horizontal = 16.dp, vertical = 8.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        when (uiState.activeTab) {
                            0 -> { // Hallen 2D Editor
                                FloorPlan2D(
                                    primitives = uiState.primitives,
                                    photoMarkers = uiState.photoMarkers,
                                    selectedMarker = uiState.selectedMarker,
                                    selectedPrimitive = uiState.selectedPrimitive,
                                    selectedElementTypeToPlace = uiState.selectedElementTypeToPlace,
                                    isPlacementModeActive = uiState.isPlacementModeActive,
                                    pendingYawAngle = uiState.pendingYawAngle,
                                    onMarkerSelect = { viewModel.selectPhotoMarker(it) },
                                    onPrimitiveSelect = { viewModel.selectPrimitive(it) },
                                    onPlacePhotoMarker = { x, y -> viewModel.addPhotoMarkerAt(x, y) },
                                    onPlacePrimitive = { x, y, type -> viewModel.addPrimitiveAt(x, y, type) },
                                    onUpdateYawAngle = { viewModel.updatePendingYaw(it) },
                                    onTogglePlacement = { viewModel.togglePlacementMode(it) }
                                )

                                ControlActionsPanel(
                                    selectedPrimitive = uiState.selectedPrimitive,
                                    onDeletePrimitive = { viewModel.deleteSelectedPrimitive() },
                                    onBakeTexture = {
                                        Toast.makeText(context, "Baking UV Textures for Hall ${uiState.selectedFloorId + 11}...", Toast.LENGTH_SHORT).show()
                                    },
                                    onPlaneDetection = {
                                        Toast.makeText(context, "Ebenen-Erkennung aktiv...", Toast.LENGTH_SHORT).show()
                                    },
                                    onExportMesh = { viewModel.selectTab(3) },
                                    onImportLod2Assets = {
                                        viewModel.importLod2MeshAssets()
                                        Toast.makeText(context, "NRW LoD2 GML Assets geladen!", Toast.LENGTH_SHORT).show()
                                    },
                                    onReloadStandardHallRooms = {
                                        viewModel.reloadStandardHallStructure()
                                        Toast.makeText(context, "Standard-Layout geladen!", Toast.LENGTH_SHORT).show()
                                    },
                                    onDuplicatePrimitive = { viewModel.duplicateSelectedPrimitive() },
                                    onUpdatePrimitivePosition = { x, y, z -> viewModel.updateSelectedPrimitivePosition(x, y, z) },
                                    onUpdatePrimitiveDimensions = { w, l, h -> viewModel.updateSelectedPrimitiveDimensions(w, l, h) },
                                    onUpdatePrimitiveYaw = { yaw -> viewModel.updateSelectedPrimitiveYaw(yaw) },
                                    onUpdatePrimitiveType = { type -> viewModel.updateSelectedPrimitiveType(type) }
                                )
                            }
                            1 -> { // 3D Align Viewport
                                Viewport3D(
                                    primitives = uiState.primitives,
                                    photoMarkers = uiState.photoMarkers,
                                    selectedPrimitive = uiState.selectedPrimitive,
                                    selectedMarker = uiState.selectedMarker,
                                    floors = uiState.floors,
                                    selectedFloorId = uiState.selectedFloorId,
                                    orbitYaw = uiState.orbitYaw,
                                    orbitPitch = uiState.orbitPitch,
                                    zoomScale = uiState.zoomScale,
                                    deviationCm = uiState.deviationCm,
                                    onFloorSelect = { viewModel.selectFloor(it) },
                                    onOrbitChange = { dyaw, dpitch -> viewModel.updateOrbit(dyaw, dpitch) },
                                    onZoomChange = { zoom -> viewModel.updateZoom(zoom) },
                                    onPrimitiveSelect = { viewModel.selectPrimitive(it) },
                                    onAutoCorrect = {
                                        viewModel.autoCorrectAlignment()
                                        Toast.makeText(context, "Geometrie ausgerichtet! Neue Abweichung berechnet.", Toast.LENGTH_SHORT).show()
                                    },
                                    modifier = Modifier.height(340.dp)
                                )

                                PhotoReferenceCard(
                                    selectedMarker = uiState.selectedMarker,
                                    isAnalyzing = uiState.isAnalyzingPhoto,
                                    onAnalyzePhoto = { uri -> viewModel.analyzePhotoForArchitecture(uri) }
                                )

                                ControlActionsPanel(
                                    selectedPrimitive = uiState.selectedPrimitive,
                                    onDeletePrimitive = { viewModel.deleteSelectedPrimitive() },
                                    onBakeTexture = {
                                        Toast.makeText(context, "Textur-Backen gestartet...", Toast.LENGTH_SHORT).show()
                                    },
                                    onPlaneDetection = {
                                        Toast.makeText(context, "Flächen-Erkennung läuft...", Toast.LENGTH_SHORT).show()
                                    },
                                    onExportMesh = { viewModel.selectTab(3) },
                                    onImportLod2Assets = {
                                        viewModel.importLod2MeshAssets()
                                        Toast.makeText(context, "NRW LoD2 GML Assets geladen!", Toast.LENGTH_SHORT).show()
                                    },
                                    onReloadStandardHallRooms = {
                                        viewModel.reloadStandardHallStructure()
                                        Toast.makeText(context, "Standard-Layout geladen!", Toast.LENGTH_SHORT).show()
                                    },
                                    onDuplicatePrimitive = { viewModel.duplicateSelectedPrimitive() },
                                    onUpdatePrimitivePosition = { x, y, z -> viewModel.updateSelectedPrimitivePosition(x, y, z) },
                                    onUpdatePrimitiveDimensions = { w, l, h -> viewModel.updateSelectedPrimitiveDimensions(w, l, h) },
                                    onUpdatePrimitiveYaw = { yaw -> viewModel.updateSelectedPrimitiveYaw(yaw) },
                                    onUpdatePrimitiveType = { type -> viewModel.updateSelectedPrimitiveType(type) }
                                )
                            }
                            2 -> { // Photo AI Architecture Extractor
                                PhotoReferenceCard(
                                    selectedMarker = uiState.selectedMarker,
                                    isAnalyzing = uiState.isAnalyzingPhoto,
                                    onAnalyzePhoto = { uri -> viewModel.analyzePhotoForArchitecture(uri) }
                                )

                                FloorPlan2D(
                                    primitives = uiState.primitives,
                                    photoMarkers = uiState.photoMarkers,
                                    selectedMarker = uiState.selectedMarker,
                                    selectedPrimitive = uiState.selectedPrimitive,
                                    selectedElementTypeToPlace = uiState.selectedElementTypeToPlace,
                                    isPlacementModeActive = uiState.isPlacementModeActive,
                                    pendingYawAngle = uiState.pendingYawAngle,
                                    onMarkerSelect = { viewModel.selectPhotoMarker(it) },
                                    onPrimitiveSelect = { viewModel.selectPrimitive(it) },
                                    onPlacePhotoMarker = { x, y -> viewModel.addPhotoMarkerAt(x, y) },
                                    onPlacePrimitive = { x, y, type -> viewModel.addPrimitiveAt(x, y, type) },
                                    onUpdateYawAngle = { viewModel.updatePendingYaw(it) },
                                    onTogglePlacement = { viewModel.togglePlacementMode(it) }
                                )
                            }
                            3 -> { // Export & Session Stats
                                ExportSummaryCard(
                                    primitives = uiState.primitives,
                                    photoMarkers = uiState.photoMarkers,
                                    deviationCm = uiState.deviationCm
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
