package com.example.service

import android.content.Context
import com.example.data.model.ElementType
import com.example.data.model.StructuralPrimitive
import org.json.JSONArray
import java.io.InputStreamReader

class Lod2AssetLoader(private val context: Context) {

    fun loadLod2PrimitivesFromAssets(targetFloorId: Int): List<StructuralPrimitive> {
        val primitives = mutableListOf<StructuralPrimitive>()
        try {
            val inputStream = context.assets.open("lod2/koelnmesse_3d_mesh.json")
            val reader = InputStreamReader(inputStream)
            val jsonText = reader.readText()
            reader.close()

            val jsonArray = JSONArray(jsonText)
            val count = jsonArray.length()

            // Map UTM bounds to Hall coordinate grid (10m to 90m)
            var minUtmX = Float.MAX_VALUE
            var maxUtmX = Float.MIN_VALUE
            var minUtmY = Float.MAX_VALUE
            var maxUtmY = Float.MIN_VALUE

            for (i in 0 until count) {
                val obj = jsonArray.getJSONObject(i)
                val utm = obj.getJSONArray("utm_center")
                val utmX = utm.getDouble(0).toFloat()
                val utmY = utm.getDouble(1).toFloat()
                if (utmX < minUtmX) minUtmX = utmX
                if (utmX > maxUtmX) maxUtmX = utmX
                if (utmY < minUtmY) minUtmY = utmY
                if (utmY > maxUtmY) maxUtmY = utmY
            }

            val rangeX = if (maxUtmX > minUtmX) maxUtmX - minUtmX else 1f
            val rangeY = if (maxUtmY > minUtmY) maxUtmY - minUtmY else 1f

            for (i in 0 until count) {
                val obj = jsonArray.getJSONObject(i)
                val idStr = obj.optString("id", "LOD2_$i")
                val utm = obj.getJSONArray("utm_center")
                val bbox = obj.getJSONArray("bbox_size")

                val utmX = utm.getDouble(0).toFloat()
                val utmY = utm.getDouble(1).toFloat()
                val utmZ = utm.getDouble(2).toFloat()

                val widthM = bbox.getDouble(0).toFloat().coerceAtLeast(0.5f)
                val lengthM = bbox.getDouble(1).toFloat().coerceAtLeast(0.5f)
                val heightM = bbox.getDouble(2).toFloat().coerceAtLeast(0.5f)

                // Normalize X, Y to 2D Hall canvas coordinates (10m..90m space)
                val normalizedX = 10f + ((utmX - minUtmX) / rangeX) * 80f
                val normalizedY = 10f + ((utmY - minUtmY) / rangeY) * 80f
                val normalizedZ = if (targetFloorId == 1) 0f else -5f

                // Determine ElementType from 3D aspect ratio & height
                val elementType = when {
                    heightM < 1.0f -> ElementType.FLOOR
                    widthM < 2.5f && lengthM < 2.5f && heightM > 3.0f -> ElementType.COLUMN
                    widthM > 12.0f || lengthM > 12.0f -> ElementType.WALL
                    heightM in 3.0f..6.0f && widthM in 2.0f..6.0f -> ElementType.DOOR
                    widthM in 1.0f..4.0f && lengthM > 4.0f && heightM > 3.0f -> ElementType.STAIRS
                    else -> ElementType.WALL
                }

                // Filter for major structural elements to keep hall editor clean & structured
                if (widthM >= 4.0f || lengthM >= 4.0f || heightM >= 3.5f) {
                    primitives.add(
                        StructuralPrimitive(
                            floorId = targetFloorId,
                            type = elementType,
                            x = normalizedX,
                            y = normalizedY,
                            z = normalizedZ,
                            width = widthM.coerceIn(1.5f, 35f),
                            length = lengthM.coerceIn(1.5f, 35f),
                            height = heightM.coerceIn(2.5f, 10f),
                            rotationYaw = 0f, // Align to hall grid
                            isFromPhotoAi = true,
                            statusNote = "NRW LoD2 GML Asset ($idStr)"
                        )
                    )
                }
                if (primitives.size >= 25) break
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return primitives
    }
}
